import os
import json
import shutil
import numpy as np
from tqdm import tqdm

# 类别映射表（基于 raw_name）
# nc: 150  # number of classes
# names: ["wall","building","sky","floor","tree","ceiling","road","bed","windowpane","grass","cabinet","sidewalk","person","earth","door","table","mountain","plant","curtain","chair","car","water","painting","sofa","shelf","house","sea","mirror","rug","field","armchair","seat","fence","desk","rock","wardrobe","lamp","bathtub","railing","cushion","base","box","column","signboard","chest","counter","sand","sink","skyscraper","fireplace","refrigerator","grandstand","path","stairs","runway","case","pool","pillow","screen","stairway","river","bridge","bookcase","blind","coffee","toilet","flower","book","hill","bench","countertop","stove","palm","kitchen","computer","swivel","boat","bar","arcade","hovel","bus","towel","light","truck","tower","chandelier","awning","streetlight","booth","television","airplane","dirt","apparel","pole","land","bannister","escalator","ottoman","bottle","buffet","poster","stage","van","ship","fountain","conveyer","canopy","washer","plaything","swimming","stool","barrel","basket","waterfall","tent","bag","minibike","cradle","oven","ball","food","step","tank","trade","microwave","pot","animal","bicycle","lake","dishwasher","screen","blanket","sculpture","hood","sconce","vase","traffic","tray","ashcan","fan","pier","crt","plate","monitor","bulletin","shower","radiator","glass","clock","flag"]
# raw_class_list = [
#     "building", "person", "car", "tree", "road", "sky", "grass", "sign", "window", "door",
#     "fence", "pole", "bridge", "truck", "train", "river", "mountain", "bus", "boat", "bench",
#     "lamp", "tower", "animal", "airplane", "bicycle", "chair", "sofa", "table", "bed", "cabinet",
#     "computer", "television", "stair", "floor", "wall", "roof", "ceiling", "plant", "curtain",
#     "book", "shelf", "mirror", "keyboard", "bag", "clock", "screen", "plate", "cup", "bottle",
#     "bathtub", "sink", "toilet", "refrigerator", "microwave", "oven", "dishwasher", "washer",
#     "dryer", "painting", "vase", "fan", "speaker", "remote", "mouse", "telephone", "trash bin",
#     "towel", "clothes", "helmet", "glasses", "backpack", "shoe", "hat", "scarf", "glove",
#     "skateboard", "surfboard", "basketball", "tennis racket", "golf club", "umbrella", "pillow",
#     "blanket", "wallet", "watch", "newspaper", "notebook", "pen", "pencil", "broom", "mop",
#     "ladder", "toolbox", "key", "lock", "fire hydrant", "stop sign", "traffic light", "crosswalk"
# ]
raw_class_list = [
    "person", "car", "tree", "road", "grass", "sign", "window", "door",
    "bridge", "truck", "train", "river", "mountain", "bus", "boat", "tower",
    "animal", "airplane", "bicycle", "chair", "sofa", "table", "bed", 
    "computer", "television",
    "book", "keyboard", "bag", "clock", "plate", "cup", "bottle",
    "sink", "toilet", "refrigerator", "microwave", "oven", "umbrella", "pillow",
    "fire hydrant", "stop sign", "traffic light", "crosswalk"
] #42 classes

# 自动构建映射
CLASS_MAPPING = {name: idx for idx, name in enumerate(raw_class_list)}

# 傅里叶特征计算函数
def compute_coefficients_interp(xy, terms=12, interp=True, return_list=False):
    x = np.array(xy[0::2])
    y = np.array(xy[1::2])
    if interp:
        x = np.concatenate([x, [x[0]]], dtype=np.float32)
        y = np.concatenate([y, [y[0]]], dtype=np.float32)
        ori = np.linspace(0, 1, x.shape[0], endpoint=True)
        gap = np.linspace(0, 1, terms * 2, endpoint=False)
        x = np.interp(gap, ori, x)
        y = np.interp(gap, ori, y)
    N = len(x)
    t = np.linspace(0, 2 * np.pi, N, endpoint=False)
    a0 = 1. / N * sum(x)
    c0 = 1. / N * sum(y)
    an, bn, cn, dn = [np.zeros(1 + terms) for _ in range(4)]
    for k in range(1, (N // 2) + 1):
        if k > terms:
            break
        an[k] = 2. / N * sum(x * np.cos(k * t))
        bn[k] = 2. / N * sum(x * np.sin(k * t))
        cn[k] = 2. / N * sum(y * np.cos(k * t))
        dn[k] = 2. / N * sum(y * np.sin(k * t))

    if return_list:
        list_coef = [a0, c0]
        for k in range(1, an.shape[0]):
            list_coef.append(an[k])
            list_coef.append(bn[k])
            list_coef.append(cn[k])
            list_coef.append(dn[k])
        return list_coef
    an[0] = a0
    cn[0] = c0
    return (an, bn, cn, dn), (x, y)

def polygon_to_yolo(polygon, img_w, img_h):
    x = polygon['x']
    y = polygon['y']
    if not x or not y:
        return None
    x_min, x_max = min(x), max(x)
    y_min, y_max = min(y), max(y)
    x_center = (x_min + x_max) / 2.0 / img_w
    y_center = (y_min + y_max) / 2.0 / img_h
    width = (x_max - x_min) / img_w
    height = (y_max - y_min) / img_h
    return x_center, y_center, width, height

import cv2
def process_one(json_path, output_image_dir, output_label_dir, ft_terms=12, min_nodes=6,hull=1):
    with open(json_path, 'r', encoding='latin1') as f:
        data = json.load(f)
    ann = data.get('annotation', {})
    filename = ann['filename']
    image_h,image_w = ann['imsize'][:2]
    objects = ann.get('object', [])

    yolo_lines = []
    ft_lines = []
    for obj in objects:
        raw_name = obj.get('raw_name')
        if raw_name in CLASS_MAPPING:
            polygon = obj.get('polygon')
            if polygon and len(polygon['x']) >= min_nodes:
                x = polygon['x']
                y = polygon['y']
                assert len(x) >= min_nodes  # 点太少，不计算傅立叶
                if hull:
                    # 构造 (N, 1, 2) 的轮廓点
                    pts = np.array(list(zip(x, y)), dtype=np.int32).reshape(-1, 1, 2)
                    pts = cv2.convexHull(pts).reshape(-1, 2)
                    # 将 pts 再拆分成 x, y 列表
                    x = pts[:, 0].tolist()
                    y = pts[:, 1].tolist()

                bbox = polygon_to_yolo({'x': x, 'y': y}, image_w, image_h)
                if bbox:
                    class_id = CLASS_MAPPING[raw_name]
                    yolo_lines.append(f"{class_id} {bbox[0]:.6f} {bbox[1]:.6f} {bbox[2]:.6f} {bbox[3]:.6f}")

                    # 计算傅立叶系数
                    xy_flat = []
                    for xx, yy in zip(x, y):
                        xy_flat.append(xx / image_w)
                        xy_flat.append(yy / image_h)
                    ft_coeffs = compute_coefficients_interp(xy_flat, terms=ft_terms, return_list=True)
                    ft_line = f"{class_id} " + " ".join(f"{v:.6f}" for v in ft_coeffs)
                    ft_lines.append(ft_line)

    if yolo_lines:
        # 复制图片
        img_src_path = os.path.join(os.path.dirname(json_path), filename)
        img_dst_path = os.path.join(output_image_dir, filename)
        if not os.path.exists(img_dst_path):
            shutil.copyfile(img_src_path, img_dst_path)

        # 写YOLO标签
        label_filename = filename.replace('.jpg', '.txt')
        label_dst_path = os.path.join(output_label_dir, label_filename)
        with open(label_dst_path, 'w') as f:
            f.write("\n".join(yolo_lines))

        # 写傅立叶标签
        ft_filename = filename.replace('.jpg', '.ft')
        ft_dst_path = os.path.join(output_label_dir, ft_filename)
        with open(ft_dst_path, 'w') as f:
            f.write("\n".join(ft_lines))

def batch_convert_ade_to_yolo_multi(input_dirs, output_root, hull):
    for split_name, ade_dir in input_dirs.items():
        print(f"📂 开始转换 {split_name} 集：{ade_dir}")
        output_image_dir = os.path.join(output_root, split_name, 'images')
        output_label_dir = os.path.join(output_root, split_name, 'labels')
        os.makedirs(output_image_dir, exist_ok=True)
        os.makedirs(output_label_dir, exist_ok=True)

         # 收集所有 json 文件，方便 tqdm 统计总数
        json_files = []
        for root, _, files in os.walk(ade_dir):
            for file in files:
                if file.endswith('.json'):
                    json_files.append(os.path.join(root, file))

        # 用 tqdm 包装循环
        for json_path in tqdm(json_files, desc=f"{split_name} 转换进度"):
            process_one(json_path, output_image_dir, output_label_dir, hull=hull)
        
        # 写入文件，每行一个字符串
        with open(os.path.join(os.path.join(output_root, split_name, 'names.txt')), "w") as f:
            for item in raw_class_list:  # 如果是原顺序，改为 raw_class_list
                f.write(item + "\n")

        print(f"✅ {split_name} 集转换完成，保存路径: {os.path.join(output_root, split_name)}")

if __name__ == "__main__":
    data_path = r'E:\datas\ADE20K_2021_17_01'
    ADE_TRAIN_DIR = os.path.join(data_path,"images/ADE/training")
    ADE_VAL_DIR = os.path.join(data_path,"images/ADE/validation")
    YOLO_OUTPUT_DIR = os.path.join(data_path,"ade20k_yolo_output6")
    input_dirs = {
        'train': ADE_TRAIN_DIR,
        'val': ADE_VAL_DIR
    }
    batch_convert_ade_to_yolo_multi(input_dirs, YOLO_OUTPUT_DIR, hull=1)
