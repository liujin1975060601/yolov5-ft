import os

# 原始标签文件夹
input_dir = 'K:/datas/infared/labels-0'
# 新标签保存文件夹
output_dir = 'K:/datas/infared/labels'
os.makedirs(output_dir, exist_ok=True)

# 判断是否为车辆标签
def is_car(filename):
    parts = filename.split('_')
    return len(parts) == 2 and all(p.isdigit() for p in parts)

# 判断是否为飞机标签
def is_plane(filename):
    return (
        '飞机' in filename
        or 'plane' in filename.lower()
        or 'uav' in filename.lower()
        or len(filename.split('_')) == 1 and (filename.isdigit() or '(' in filename or ')' in filename)
    )

# 扫描并处理所有 .txt 文件
for filename in os.listdir(input_dir):
    if not filename.endswith('.txt'):
        continue

    name_without_ext = os.path.splitext(filename)[0]

    input_path = os.path.join(input_dir, filename)
    output_path = os.path.join(output_dir, filename)

    if is_car(name_without_ext):
        target_class = '0'
    elif is_plane(name_without_ext):
        target_class = '1'
    else:
        print(f'跳过未知类别文件: {filename}')
        continue

    # 读取和修改标签
    with open(input_path, 'r') as f:
        lines = f.readlines()

    new_lines = []
    for line in lines:
        parts = line.strip().split()
        if len(parts) == 5:
            # 替换 cls 为目标类别
            parts[0] = target_class
            new_lines.append(' '.join(parts))

    # 写入到新文件夹
    with open(output_path, 'w') as f:
        f.write('\n'.join(new_lines))

    # print(f'已处理: {filename} -> 类别 {target_class}')
