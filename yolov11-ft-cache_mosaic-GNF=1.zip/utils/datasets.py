# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Wuqiang Li∗, Huan Li, Biyin Zhang, Yaorong Cen, Zhenfeng Shao",
#     title   = "Group-Normalized Fourier Detection for Arbitrary-Shaped Objects",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }

import glob
import hashlib
import json
import logging
import os
import random
import shutil
import time
from itertools import repeat
from multiprocessing.pool import ThreadPool, Pool
from pathlib import Path
from threading import Thread

import cv2
import numpy as np
import torch
import torch.nn.functional as F
import yaml
from PIL import Image, ExifTags
from torch.utils.data import Dataset
from tqdm import tqdm

from utils.augmentations import augment_hsv, copy_paste, letterbox, mixup, random_perspective, box_candidates_ioa
from utils.general import check_requirements, check_file, check_dataset, xywh2xyxy, xywhn2xyxy, xyxy2xywhn, \
    xyn2xy, segments2boxes, clean_str, ftnorm2ft, ft2ftnorm

from tools.plotbox import show_ft,fft_area,fft_areas,reverse_ffts

from utils.torch_utils import torch_distributed_zero_first
from torch.utils.data import Subset # 导入 Subset 类
from utils.plots import Annotator, colors
from copy import deepcopy
from image.image_split import CutImages

# Parameters
HELP_URL = 'https://github.com/ultralytics/yolov5/wiki/Train-Custom-Data'
IMG_FORMATS = ['bmp', 'jpg', 'jpeg', 'png', 'tif', 'tiff', 'dng', 'webp', 'mpo', 'bsq']  # acceptable image suffixes
VID_FORMATS = ['mov', 'avi', 'mp4', 'mpg', 'mpeg', 'm4v', 'wmv', 'mkv']  # acceptable video suffixes
NUM_THREADS = min(8, os.cpu_count())  # number of multiprocessing threads

# Get orientation exif tag
for orientation in ExifTags.TAGS.keys():
    if ExifTags.TAGS[orientation] == 'Orientation':
        break


def get_hash(paths):
    # Returns a single hash value of a list of paths (files or dirs)
    size = sum(os.path.getsize(p) for p in paths if os.path.exists(p))  # sizes
    h = hashlib.md5(str(size).encode())  # hash sizes
    h.update(''.join(paths).encode())  # hash paths
    return h.hexdigest()  # return hash


def exif_size(img):
    # Returns exif-corrected PIL size
    s = img.size  # (width, height)
    try:
        rotation = dict(img._getexif().items())[orientation]
        if rotation == 6:  # rotation 270
            s = (s[1], s[0])
        elif rotation == 8:  # rotation 90
            s = (s[1], s[0])
    except:
        pass

    return s


def exif_transpose(image):
    """
    Transpose a PIL image accordingly if it has an EXIF Orientation tag.
    From https://github.com/python-pillow/Pillow/blob/master/src/PIL/ImageOps.py

    :param image: The image to transpose.
    :return: An image.
    """
    exif = image.getexif()
    orientation = exif.get(0x0112, 1)  # default 1
    if orientation > 1:
        method = {2: Image.FLIP_LEFT_RIGHT,
                  3: Image.ROTATE_180,
                  4: Image.FLIP_TOP_BOTTOM,
                  5: Image.TRANSPOSE,
                  6: Image.ROTATE_270,
                  7: Image.TRANSVERSE,
                  8: Image.ROTATE_90,
                  }.get(orientation)
        if method is not None:
            image = image.transpose(method)
            del exif[0x0112]
            image.info["exif"] = exif.tobytes()
    return image


def create_dataloader(path, imgsz, batch_size, stride, single_cls=False, hyp=None, augment=False, cache=False, pad=0.0,
                      rect=False, rank=-1, workers=8, image_weights=False, quad=False, prefix='', shuffle=True,
                      save_dir='',debug_samples=0,sample_count=0, ft_coef=0, hist=None, mask_line=None,hull=1,cache_mosaic=512):
    # Make sure only the first process in DDP process the dataset first, and the following others can use the cache
    if(save_dir==''):
        debug_samples = 0
    
    with torch_distributed_zero_first(rank):
        dataset = LoadImagesAndLabels(path, imgsz, batch_size,
                                      augment=augment,  # augment images
                                      hyp=hyp,  # augmentation hyperparameters
                                      rect=rect,  # rectangular training
                                      cache_images=cache,
                                      single_cls=single_cls,
                                      stride=int(stride),
                                      pad=pad,
                                      image_weights=image_weights,
                                      prefix=prefix,
                                      save_dir=save_dir,
                                      debug_samples=debug_samples,
                                      ft_coef=ft_coef,
                                      hist=hist,
                                      mask_line=mask_line,
                                      hull = hull,
                                      cache_mosaic=cache_mosaic)
    
    if(sample_count>0):
        if(sample_count < len(dataset)):
            dataset = SubsetRich(dataset, torch.randperm(sample_count)) #torch.randperm(len(dataset))[:sample_count]
        else:
            print(f'\033[91m{sample_count} vs {len(dataset)}.\033[0m')

    batch_size = min(batch_size, len(dataset))
    nw = min([os.cpu_count(), batch_size if batch_size > 1 else 0, workers])  # number of workers
    sampler = torch.utils.data.distributed.DistributedSampler(dataset) if rank != -1 else None
    loader = torch.utils.data.DataLoader if image_weights else InfiniteDataLoader
    # Use torch.utils.data.DataLoader() if dataset.properties will update during training else InfiniteDataLoader()
    dataloader = loader(dataset,
                        batch_size=batch_size,
                        num_workers=nw,
                        shuffle = shuffle and sampler is None,
                        sampler=sampler,
                        pin_memory=True,
                        collate_fn=LoadImagesAndLabels.collate_fn4 if quad else LoadImagesAndLabels.collate_fn,
                        generator = torch.Generator().manual_seed(6148914691236517205)
                        )
    return dataloader, dataset

def create_bigimg_dataloader(image, imgsz, batch_size, subsize=512, over_lap=640,xyoff=[0,0], resize=0, big_warp=1, swaprgb=0, bkcolor=(114,114,114)):
    dataset = BigImageDataset(image, imgsz, subsize, over_lap, xyoff=xyoff, resize=resize, big_warp=big_warp, swaprgb=swaprgb, bkcolor=bkcolor)
    batch_size = min(batch_size, len(dataset))
    return torch.utils.data.DataLoader(dataset, batch_size=batch_size)

class InfiniteDataLoader(torch.utils.data.dataloader.DataLoader):
    """ Dataloader that reuses workers

    Uses same syntax as vanilla DataLoader
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        object.__setattr__(self, 'batch_sampler', _RepeatSampler(self.batch_sampler))
        self.iterator = super().__iter__()

    def __len__(self):
        return len(self.batch_sampler.sampler)

    def __iter__(self):
        for i in range(len(self)):
            yield next(self.iterator)


class _RepeatSampler(object):
    """ Sampler that repeats forever

    Args:
        sampler (Sampler)
    """

    def __init__(self, sampler):
        self.sampler = sampler

    def __iter__(self):
        while True:
            yield from iter(self.sampler)


class LoadImages:  # for inference
    def __init__(self, path, img_size=640, stride=32, auto=True):
        p = str(Path(path).absolute())  # os-agnostic absolute path
        if '*' in p:
            files = sorted(glob.glob(p, recursive=True))  # glob
        elif os.path.isdir(p):
            files = sorted(glob.glob(os.path.join(p, '*.*')))  # dir
        elif os.path.isfile(p):
            files = [p]  # files
        else:
            raise Exception(f'ERROR: {p} does not exist')

        images = [x for x in files if x.split('.')[-1].lower() in IMG_FORMATS]
        videos = [x for x in files if x.split('.')[-1].lower() in VID_FORMATS]
        ni, nv = len(images), len(videos)

        self.img_size = img_size
        self.stride = stride
        self.files = images + videos
        self.nf = ni + nv  # number of files
        self.video_flag = [False] * ni + [True] * nv
        self.mode = 'image'
        self.auto = auto
        if any(videos):
            self.new_video(videos[0])  # new video
        else:
            self.cap = None
        assert self.nf > 0, f'No images or videos found in {p}. ' \
                            f'Supported formats are:\nimages: {IMG_FORMATS}\nvideos: {VID_FORMATS}'

    def __iter__(self):
        self.count = 0
        return self

    def __next__(self):
        if self.count == self.nf:
            raise StopIteration
        path = self.files[self.count]

        if self.video_flag[self.count]:
            # Read video
            self.mode = 'video'
            ret_val, img0 = self.cap.read()
            if not ret_val:
                self.count += 1
                self.cap.release()
                if self.count == self.nf:  # last video
                    raise StopIteration
                else:
                    path = self.files[self.count]
                    self.new_video(path)
                    ret_val, img0 = self.cap.read()

            self.frame += 1
            print(f'video {self.count + 1}/{self.nf} ({self.frame}/{self.frames}) {path}: ', end='')

        else:
            # Read image
            self.count += 1
            img0 = cv2.imdecode(np.fromfile(path, dtype=np.uint8),cv2.IMREAD_COLOR)#cv2.imread(path)  # BGR
            assert img0 is not None, 'Image Not Found ' + path
            # print(f'image {self.count}/{self.nf} {path}: ', end='')

        # Padded resize
        img = letterbox(img0, self.img_size, stride=self.stride, auto=self.auto)[0]

        # Convert
        img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        img = np.ascontiguousarray(img)

        return path, img, img0, self.cap

    def new_video(self, path):
        self.frame = 0
        self.cap = cv2.VideoCapture(path)
        self.frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))

    def __len__(self):
        return self.nf  # number of files

from image.gdal import gdal_start
class LoadBigImages:
    # YOLOv5 image/video dataloader, i.e. `python detect.py --source image.jpg/vid.mp4`
    def __init__(self, path, img_size=640, stride=32, auto=True, subsize=[512,512], over_lap=100, load_label=False):
        p = str(Path(path).resolve())  # os-agnostic absolute path
        if '*' in p:
            files = sorted(glob.glob(p, recursive=True))  # glob
        elif os.path.isdir(p):
            files = sorted(glob.glob(os.path.join(p, '*.*')))  # dir
        elif os.path.isfile(p):
            files = [p]  # files
        else:
            raise Exception(f'ERROR: {p} does not exist')

        images = [x for x in files if x.split('.')[-1].lower() in IMG_FORMATS]
        ni = len(images)

        self.img_size = img_size
        self.stride = stride
        self.files = images
        self.nf = ni  # number of files
        self.mode = 'image'
        self.auto = auto
        self.subsize = subsize
        self.over_lap = over_lap
        self.load_label = load_label
        assert self.nf > 0, f'No images or videos found in {p}. ' 


    def __iter__(self):
        self.count = 0
        return self

    def __next__(self):
        if self.count == self.nf:
            raise StopIteration
        path = self.files[self.count]

        # Read image
        self.count += 1
        if self.subsize[0]>0 and self.subsize[1]>0:
            cut = CutImages(subsize=self.subsize, over_lap=self.over_lap, resize=0)
            img0, cut_imgs = cut.cut_images(path,self.img_size) # BGR
            assert img0 is not None, f'Image Not Found {path}'
        else:
            try:
                img0 = cv2.imread(path)  # BGR
                # img0 = gdal_start(path) #img0[H,W,C]
            except Exception as e:
                img0 = None
            cut_imgs = []
        # cut = CutImages(sub_size=self.sub_size, over_lap=self.over_lap)
        # img0, cut_imgs = cut.cut_images(path) # BGR
        # assert img0 is not None, f'Image Not Found {path}'
        s = f'image {self.count}/{self.nf} {path}: '
        convert_imgs = []
        for sub_item in cut_imgs:
            # Padded resize
            sub_img = sub_item['patch']
            # Convert
            if not cut.resize:
                img = sub_img.transpose((2, 0, 1))  # HWC to CHW, BGR to RGB
            else:
                img = letterbox(sub_img, self.img_size, stride=self.stride, auto=self.auto)[0]
                img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB

            # img = letterbox(sub_img, self.img_size, stride=self.stride, auto=self.auto)[0]
            # # Convert
            # img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
            img = np.ascontiguousarray(img)
            convert_imgs.append(img)


        if self.load_label:
            pts_path = self.pts_files[self.count - 1]
            with open(pts_path) as f:
                p = [x.split() for x in f.read().strip().splitlines() if len(x)]
                p = np.array(p, dtype=np.float32)
                p = np.clip(p, 0, 1)
            return path, cut_imgs, convert_imgs, img0, p

        return path, cut_imgs, convert_imgs, img0,  s


    def __len__(self):
        return self.nf  # number of files

class LoadCSV:
    # YOLOv5 image/video dataloader, i.e. `python detect.py --source image.jpg/vid.mp4`
    def __init__(self, path, img_size=640, stride=32, auto=True, subsize=[512,512], over_lap=100, load_label=False):
        p = str(Path(path).resolve())  # os-agnostic absolute path
        if '*' in p:
            files = sorted(glob.glob(p, recursive=True))  # glob
        elif os.path.isdir(p):
            files = sorted(glob.glob(os.path.join(p, '*.*')))  # dir
        elif os.path.isfile(p):
            files = [p]  # files
        else:
            raise Exception(f'ERROR: {p} does not exist')

        images = [x for x in files if x.split('.')[-1].lower() in ['csv']]
        ni = len(images)

        self.img_size = img_size
        self.stride = stride
        self.files = images
        self.nf = ni  # number of files
        self.mode = 'image'
        self.auto = auto
        self.subsize = subsize
        self.over_lap = over_lap
        self.load_label = load_label
        assert self.nf > 0, f'No images or videos found in {p}. ' 

    def __iter__(self):
        self.count = 0
        return self

    def __next__(self):
        if self.count == self.nf:
            raise StopIteration
        path = self.files[self.count]
        
        # Read image
        self.count += 1
        try:
            img0 = None #self.csv_to_img(path) # img0[H,W,C] BGR
            # img0 = gdal_start(path) #img0[H,W,C]
        except Exception as e:
            img0 = None
        # cut = CutImages(sub_size=self.sub_size, over_lap=self.over_lap)
        # img0, cut_imgs = cut.cut_images(path) # BGR
        # assert img0 is not None, f'Image Not Found {path}'
        cmt = f'image {self.count}/{self.nf} {path}: '

        return path, [], [], img0,  cmt


    def __len__(self):
        return self.nf  # number of files

class BigImageDataset(Dataset):
    def __init__(self, image, img_size=[640,640], subsize=512, over_lap=100, stride=32, xyoff=[0,0],resize=0, big_warp=1,swaprgb=0, bkcolor=(114,114,114)):
        cut = CutImages(subsize=subsize, over_lap=over_lap, xyoff=xyoff,resize=resize)
        _, cut_imgs = cut.cut_images(image,img_size) # BGR
        xy = []
        #cuts = []
        #convert_imgs = []
        for sub_item in cut_imgs:
            #sub_img = sub_item['patch']
            #cuts.append(sub_img)
            if not cut.resize:
                xy.append(np.array([sub_item['A23'],sub_item['A23_1'],sub_item['cxy']]))
                #img = sub_img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
            else:
                xy.append(np.array(sub_item['xy']))
                #img = letterbox(sub_img, img_size, stride=stride, auto=True)[0]
                #img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
            #img = np.ascontiguousarray(img)
            #convert_imgs.append(img)
        self.cut = cut
        self.img_size = img_size
        self.xy = xy
        self.image = image
        #self.convert_imgs = convert_imgs
        self.big_warp = big_warp
        self.swaprgb = swaprgb
        self.bkcolor = bkcolor
    
    def __getitem__(self, index):
        xy = self.xy[index]
        if self.cut.resize==0: # 执行仿射变换切图
            A23 = xy[0] #A23[2,3]
            if self.big_warp==0:
                patch = cv2.warpAffine(self.image, A23, (self.img_size[1],self.img_size[0]), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=self.bkcolor)
            else:
                A23_1 = xy[1]
                #image[H,W,3]->patch[self.img_size[1],self.img_size[0],3]
                #cxy1 = A23_1 @ np.array([self.img_size[1]/2,self.img_size[0]/2,1])
                cxy = xy[2,:,2]
                R = max(self.cut.subsize[0],self.cut.subsize[1])
                xylt = np.round(cxy - R).astype(int) #left top coord
                xylt = np.clip(xylt,a_min=0,a_max=None)
                xyrb = xylt + 2*R
                xyrb[0] = np.clip(xylt[0] + 2*R, a_min=None, a_max=self.image.shape[1])
                xyrb[1] = np.clip(xylt[1] + 2*R, a_min=None, a_max=self.image.shape[0])
                patchR = self.image[xylt[1]:xyrb[1], xylt[0]:xyrb[0], :]
                A23t = A23.copy()
                A23t[0,2] += A23t[0,0]*xylt[0] + A23t[0,1]*xylt[1]
                A23t[1,2] += A23t[1,0]*xylt[0] + A23t[1,1]*xylt[1]
                patch = cv2.warpAffine(patchR, A23t, (int(self.img_size[1]),int(self.img_size[0])), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=self.bkcolor)
            
            # patchs[i] = np.ascontiguousarray(patchs[i])
        else:  # 执行resize切图
            x, y = xy[0], xy[1]  # A23[2] -> x, y
            #patchs = image[y:y + subsize[0], x:x + subsize[1]].copy() #patchs[h,w,3]
            patch = self.image[y:y + self.cut.subsize[0], x:x + self.cut.subsize[1]] #patchs[h,w,3]
            # patchs_resize = []
            # for i,xy in enumerate(xys):
            #     patchs_resize.append(letterbox(patchs[i], shape_img, stride=32, auto=True)[0])
            # patchs = np.stack(patchs_resize, axis=0) #patch[B,H,W,3]
            patch = letterbox(patch, self.img_size, stride=32, auto=True)[0]  # patchs[h,w, 3]->ps[img_size[0],img_size[1], 3]
            #patch = np.ascontiguousarray(ps)
        assert patch.shape[:2]==tuple(self.img_size)
        patch = patch[:, :, [2, 1, 0]]  # BGR->RGB
        im = patch.transpose((2, 0, 1)) # patch[H,W,3]->im[3,H,W] HWC->CHW
        if self.swaprgb:
            im = im[::-1]
        im = np.ascontiguousarray(im)
        
        return xy, im
 
    def __len__(self): 
        return len(self.xy)

class LoadWebcam:  # for inference
    def __init__(self, pipe='0', img_size=640, stride=32):
        self.img_size = img_size
        self.stride = stride
        self.pipe = eval(pipe) if pipe.isnumeric() else pipe
        self.cap = cv2.VideoCapture(self.pipe)  # video capture object
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)  # set buffer size

    def __iter__(self):
        self.count = -1
        return self

    def __next__(self):
        self.count += 1
        if cv2.waitKey(1) == ord('q'):  # q to quit
            self.cap.release()
            cv2.destroyAllWindows()
            raise StopIteration

        # Read frame
        ret_val, img0 = self.cap.read()
        img0 = cv2.flip(img0, 1)  # flip left-right

        # Print
        assert ret_val, f'Camera Error {self.pipe}'
        img_path = 'webcam.jpg'
        print(f'webcam {self.count}: ', end='')

        # Padded resize
        img = letterbox(img0, self.img_size, stride=self.stride)[0]

        # Convert
        img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        img = np.ascontiguousarray(img)

        return img_path, img, img0, None

    def __len__(self):
        return 0


class LoadStreams:  # multiple IP or RTSP cameras
    def __init__(self, sources='streams.txt', img_size=640, stride=32, auto=True):
        self.mode = 'stream'
        self.img_size = img_size
        self.stride = stride

        if os.path.isfile(sources):
            with open(sources, 'r') as f:
                sources = [x.strip() for x in f.read().strip().splitlines() if len(x.strip())]
        else:
            sources = [sources]

        n = len(sources)
        self.imgs, self.fps, self.frames, self.threads = [None] * n, [0] * n, [0] * n, [None] * n
        self.sources = [clean_str(x) for x in sources]  # clean source names for later
        self.auto = auto
        for i, s in enumerate(sources):  # index, source
            # Start thread to read frames from video stream
            print(f'{i + 1}/{n}: {s}... ', end='')
            if 'youtube.com/' in s or 'youtu.be/' in s:  # if source is YouTube video
                check_requirements(('pafy', 'youtube_dl'))
                import pafy
                s = pafy.new(s).getbest(preftype="mp4").url  # YouTube URL
            s = eval(s) if s.isnumeric() else s  # i.e. s = '0' local webcam
            cap = cv2.VideoCapture(s)
            assert cap.isOpened(), f'Failed to open {s}'
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            self.fps[i] = max(cap.get(cv2.CAP_PROP_FPS) % 100, 0) or 30.0  # 30 FPS fallback
            self.frames[i] = max(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 0) or float('inf')  # infinite stream fallback

            _, self.imgs[i] = cap.read()  # guarantee first frame
            self.threads[i] = Thread(target=self.update, args=([i, cap]), daemon=True)
            print(f" success ({self.frames[i]} frames {w}x{h} at {self.fps[i]:.2f} FPS)")
            self.threads[i].start()
        print('')  # newline

        # check for common shapes
        s = np.stack([letterbox(x, self.img_size, stride=self.stride, auto=self.auto)[0].shape for x in self.imgs])
        self.rect = np.unique(s, axis=0).shape[0] == 1  # rect inference if all shapes equal
        if not self.rect:
            print('WARNING: Different stream shapes detected. For optimal performance supply similarly-shaped streams.')

    def update(self, i, cap):
        # Read stream `i` frames in daemon thread
        n, f, read = 0, self.frames[i], 1  # frame number, frame array, inference every 'read' frame
        while cap.isOpened() and n < f:
            n += 1
            # _, self.imgs[index] = cap.read()
            cap.grab()
            if n % read == 0:
                success, im = cap.retrieve()
                self.imgs[i] = im if success else self.imgs[i] * 0
            time.sleep(1 / self.fps[i])  # wait time

    def __iter__(self):
        self.count = -1
        return self

    def __next__(self):
        self.count += 1
        if not all(x.is_alive() for x in self.threads) or cv2.waitKey(1) == ord('q'):  # q to quit
            cv2.destroyAllWindows()
            raise StopIteration

        # Letterbox
        img0 = self.imgs.copy()
        img = [letterbox(x, self.img_size, stride=self.stride, auto=self.rect and self.auto)[0] for x in img0]

        # Stack
        img = np.stack(img, 0)

        # Convert
        img = img[..., ::-1].transpose((0, 3, 1, 2))  # BGR to RGB, BHWC to BCHW
        img = np.ascontiguousarray(img)

        return self.sources, img, img0, None

    def __len__(self):
        return len(self.sources)  # 1E12 frames = 32 streams at 30 FPS for 30 years


def img2label_paths(img_paths):
    # Define label paths as a function of image paths
    sa, sb = os.sep + 'images' + os.sep, os.sep + 'labels' + os.sep  # /images/, /labels/ substrings
    return [sb.join(x.rsplit(sa, 1)).rsplit('.', 1)[0] + '.txt' for x in img_paths]

def img2pol_paths(img_paths):
    # Define label paths as a function of image paths
    sa, sb = os.sep + 'images' + os.sep, os.sep + 'labels' + os.sep  # /images/, /labels/ substrings
    return [sb.join(x.rsplit(sa, 1)).rsplit('.', 1)[0] + '.pol' for x in img_paths]

def filt_labels_H(labels, least_pixel_size, least_area=40):
    #labels = self.labels[index].copy()#[nobj,1(cls)+4(xyxy))]
    xyxy = labels[:,1:5]#xyxy[nobj,4]
    wh = xyxy[:,2:4]-xyxy[:,0:2]#wh[nobj,2]
    assert wh.shape[0]==0 or torch.any(wh>=0), 'must wh>=0'
    Lab = torch.norm(wh, p=2, dim=1)
    labels = labels[(Lab > least_pixel_size) & (wh[:,0]*wh[:,1]>=least_area)]
    return labels

class SubsetRich(Subset):
    def __init__(self, dataset, indices):
        super().__init__(dataset, indices)
        # 将原始 dataset 的所有属性挂载到子集对象上
        self.__dict__.update(dataset.__dict__)
        self.indices = indices
    # def __len__(self):
    #     return len(self.indices)

class LoadImagesAndLabels(Dataset):  # for training/testing
    def __init__(self, path, img_size=640, batch_size=16, augment=False, hyp=None, rect=False, image_weights=False,
                 cache_images=False, single_cls=False, stride=32, pad=0.0, prefix='', save_dir='',debug_samples=0, ft_coef=0, hist=None,
                 mask_line=None,hull=1,cache_mosaic=512):
        self.img_size = img_size
        self.augment = augment
        self.hyp = hyp
        self.image_weights = image_weights
        self.rect = False if image_weights else rect
        self.mosaic = self.augment and not self.rect  # load 4 images at a time into a mosaic (only during training)
        self.mosaic_border = [-img_size // 2, -img_size // 2] if isinstance(img_size,int) else [-img_size[0] // 2, -img_size[1] // 2]
        self.path = path
        self.ft_coef = ft_coef
        self.hist = hist
        self.stride = stride
        self.mask_line = mask_line
        self.hull = hull

        #self.albumentations = Albumentations() if augment else None

        if(hyp!=None):
            self.least_pixel_size = hyp.get('least_pixel_size', 4) #at least 2 pixels for every object
            self.least_area = hyp.get('least_area', 16) #at least 4 pixels^2 for every object
            self.nearest_z = hyp.get('nearest_z', 1.0)
        else:
            self.least_pixel_size = 4
            self.least_area = 16
            self.nearest_z = 1.0

        try:
            f = []  # image files
            for p in path if isinstance(path, list) else [path]:
                p = Path(p)  # os-agnostic
                if p.is_dir():  # dir
                    f += glob.glob(str(p / '**' / '*.*'), recursive=True)
                    # f = list(p.rglob('**/*.*'))  # pathlib
                elif p.is_file():  # file
                    with open(p, 'r') as t:
                        t = t.read().strip().splitlines()
                        parent = str(p.parent) + os.sep
                        f += [x.replace('./', parent) if x.startswith('./') else x for x in t]  # local to global path
                        # f += [p.parent / x.lstrip(os.sep) for x in t]  # local to global path (pathlib)
                else:
                    raise Exception(f'{prefix}{p} does not exist')
            self.img_files = sorted([x.replace('/', os.sep) for x in f if x.split('.')[-1].lower() in IMG_FORMATS])
            # self.img_files = sorted([x for x in f if x.suffix[1:].lower() in img_formats])  # pathlib
            assert self.img_files, f'{prefix}No images found'
        except Exception as e:
            raise Exception(f'{prefix}Error loading data from {path}: {e}\nSee {HELP_URL}')

        if ft_coef > 0:
            self.label_length = 5 + ft_coef * 4 + 2
        else:
            raise RuntimeError('FT版本不做水平框训练适配')
        # Check cache
        self.suffix = '.cache_v11dfl_ft' + f'-h{hull}'
        self.cache_version = 0.47
        self.label_files = img2label_paths(self.img_files)  # labels
        cache_name = (p if p.is_file() else Path(self.label_files[0]).parent)
        cache_path = cache_name.with_suffix(self.suffix)
        try:
            cache, exists = np.load(cache_path, allow_pickle=True).item(), True  # load dict
            assert cache['version'] == self.cache_version and cache['hash'] == get_hash(self.label_files + self.img_files)
            assert cache['ft_coef'] >= self.ft_coef
            assert cache['mask_line'] == self.mask_line
        except:
            cache, exists = self.cache_labels(cache_path, prefix), False  # cache

        assert cache['ft_coef'] >= self.ft_coef, "数据集ft阶数不匹配"

        self.cm = self.get_cm(cache,ft_coef) #self.cm[term]
        print(self.cm)

        # Display cache
        nf, nm, ne, nc, n = cache.pop('results')  # found, missing, empty, corrupted, total
        if exists:
            d = f"Scanning '{cache_path}' images and labels... {nf} found, {nm} missing, {ne} empty, {nc} corrupted"
            tqdm(None, desc=prefix + d, total=n, initial=n)  # display cache results
            if cache['msgs']:
                logging.info('\n'.join(cache['msgs']))  # display warnings
        assert nf > 0 or not augment, f'{prefix}No labels in {cache_path}. Can not train without labels. See {HELP_URL}'

        # Read cache
        [cache.pop(k) for k in ('hash', 'version', 'msgs', 'ft_coef', 'mask_line')]  # remove items
        labels, shapes, self.segments = zip(*cache.values())
        # self.labels = list(labels)
        self.labels = [label[:, :self.label_length] for label in labels]
        
        self.shapes = np.array(shapes, dtype=np.float64)
        self.img_files = list(cache.keys())  # update
        self.label_files = img2label_paths(cache.keys())  # update
        if single_cls:
            for x in self.labels:
                x[:, 0] = 0

        n = len(shapes)  # number of images
        bi = np.floor(np.arange(n) / batch_size).astype(np.int64)  # batch index
        nb = bi[-1] + 1  # number of batches
        self.batch = bi  # batch index of image
        self.n = n
        self.indices = range(n)

        # Buffer thread for mosaic images
        self.cache_mosaic = cache_mosaic
        if self.cache_mosaic:
            self.batch_size = batch_size
            self.buffer = []  # buffer size = batch size
            self.max_buffer_length = min((self.n, self.cache_mosaic, 1024)) if self.augment else 0 #self.batch_size * 8
            self.cache = None
            self.img_hw0, self.img_hw = [None] * n, [None] * n


        # Rectangular Training
        if self.rect:
            # Sort by aspect ratio
            s = self.shapes  # wh
            ar = s[:, 1] / s[:, 0]  # aspect ratio
            irect = ar.argsort()
            self.img_files = [self.img_files[i] for i in irect]
            self.label_files = [self.label_files[i] for i in irect]
            self.labels = [self.labels[i] for i in irect]
            self.shapes = s[irect]  # wh
            ar = ar[irect]

            # Set training image shapes
            shapes = [[1, 1]] * nb
            for i in range(nb):
                ari = ar[bi == i]
                mini, maxi = ari.min(), ari.max()
                if maxi < 1:
                    shapes[i] = [maxi, 1]
                elif mini > 1:
                    shapes[i] = [1, 1 / mini]

            if isinstance(img_size,int):
                self.batch_shapes = np.ceil(np.array(shapes) * img_size / stride + pad).astype(np.int64) * stride
            else:
                # one_shape = np.ceil(np.array(img_size) / stride).astype(np.int64) * stride
                # self.batch_shapes = np.repeat([one_shape],nb,axis=0) #([one_shape].repeat(nb,1)
                self.batch_shapes = np.ceil(np.array(shapes) * max(img_size) / stride + pad).astype(np.int64) * stride
            #self.batch_shapes[nb,2]

        # Cache images into memory for faster training (WARNING: large datasets may exceed system RAM)
        self.imgs, self.img_npy = [None] * n, [None] * n
        if cache_images:
            if cache_images == 'disk':
                self.im_cache_dir = Path(Path(self.img_files[0]).parent.as_posix() + '_npy')
                self.img_npy = [self.im_cache_dir / Path(f).with_suffix('.npy').name for f in self.img_files]
                self.im_cache_dir.mkdir(parents=True, exist_ok=True)
            gb = 0  # Gigabytes of cached images
            self.img_hw0, self.img_hw = [None] * n, [None] * n
            results = ThreadPool(NUM_THREADS).imap(lambda x: load_image(*x), zip(repeat(self), range(n)))
            pbar = tqdm(enumerate(results), total=n)
            for i, x in pbar:
                if cache_images == 'disk':
                    if not self.img_npy[i].exists():
                        np.save(self.img_npy[i].as_posix(), x[0])
                    gb += self.img_npy[i].stat().st_size
                else:
                    self.imgs[i], self.img_hw0[i], self.img_hw[i] = x  # im, hw_orig, hw_resized = load_image(self, i)
                    gb += self.imgs[i].nbytes
                pbar.desc = f'{prefix}Caching images ({gb / 1E9:.1f}GB {cache_images})'
            pbar.close()
        self.save_dir = save_dir
        if isinstance(self.save_dir, Path):
            self.save_dir.mkdir(exist_ok=True, parents=True)
        self.debug_samples = debug_samples
        self.xywhn2xyxy = xywhn2xyxy
        self.xyxy2xywhn = xyxy2xywhn
    
    def get_cm(self, cache, k):
        # 从字典 cache 中提取 arr 数据，按规则处理后计算每组的标准差。
        # 参数:
        #     cache: 包含多个键值对的字典，其中值为形如 [np.ndarray, ...] 的列表
        #     k: 需要分组的组数，每组包含 4 列
        # 返回:
        #     长度为 k 的数组，每个元素为对应组的标准差
        # 初始化每组的拼接数据列表
        grouped_data = [[] for _ in range(k)]

        # 遍历字典
        for key, val in cache.items():
            if isinstance(val, list) and len(val) == 3:
                # 获取 val[0] 中的 np 数组
                arr = val[0] #arr[5(cls+xywh)+2(a0c0)+4n]
                if isinstance(arr, np.ndarray) and arr.shape[0] > 0:
                    # 按照 2+4k 顺序排列，抛弃前 2 列，保留后 4k 列
                    sub_array = arr[:, 5+2:5+2 + 4 * k] #sub_array[4n]

                    # 分成 k 组，每组 4 列
                    for i in range(k):
                        group = sub_array[:, i * 4:(i + 1) * 4]
                        # 将当前字典的每组数据拼接到对应列表中
                        grouped_data[i].append(group)

        # 计算每组的标准差
        std_devs = []
        for i,group in enumerate(grouped_data): #loop k times
            # 将组内数据拼接成一个大的数组 group[[n,4(abcd)]]
            concatenated = np.vstack(group) if group else np.empty((0, 4)) #concatenated[N,4(abcd)]
            if concatenated.size > 0:
                # 计算标准差，并存储
                # std_devs.append(np.std(concatenated, axis=0).mean())
                #
                # 计算每一列的均值（这里计算均值通常不会出错）
                mean_vals = np.mean(concatenated, axis=0) #mean_vals[4]
                # 定义阈值
                threshold = 1e-5
                # 针对每一列单独计算标准差
                std_list = []
                for i in range(concatenated.shape[1]):
                    # 如果该列的均值绝对值小于阈值，则认为该列数据过小，直接置标准差为 0
                    if abs(mean_vals[i]) < threshold:
                        std_list.append(0)
                    else:
                        # 单独计算该列的标准差
                        std_list.append(np.std(concatenated[:, i]))

                # 将所有列的标准差取平均后添加到 std_devs 中
                std_devs.append(np.mean(std_list))
            else:
                std_devs.append(0)

        return np.array(std_devs)

    def cache_labels(self, path=Path('./labels.cache'), prefix=''):
        # Cache dataset labels, check images and read shapes
        x = {}  # dict
        nm, nf, ne, nc, msgs = 0, 0, 0, 0, []  # number missing, found, empty, corrupt, messages
        desc = f"{prefix}Scanning '{path.parent / path.stem}' images and labels..."
        with Pool(NUM_THREADS) as pool:
            pbar = tqdm(pool.imap(verify_image_label, zip(self.img_files, 
                                                          self.label_files, 
                                                          repeat(prefix), 
                                                          repeat(self.ft_coef),
                                                          repeat(self.mask_line),
                                                          repeat(self.hull))),
                        desc=desc, total=len(self.img_files))
            for im_file, l, shape, segments, nm_f, nf_f, ne_f, nc_f, msg in pbar:
                nm += nm_f
                nf += nf_f
                ne += ne_f
                nc += nc_f
                if im_file:
                    x[im_file] = [l, shape, segments]
                if msg:
                    msgs.append(msg)
                pbar.desc = f"{desc}{nf} found, {nm} missing, {ne} empty, {nc} corrupted"

        pbar.close()
        if msgs:
            logging.info('\n'.join(msgs))
        if nf == 0:
            logging.info(f'{prefix}WARNING: No labels found in {path}. See {HELP_URL}')
        x['hash'] = get_hash(self.label_files + self.img_files)
        x['results'] = nf, nm, ne, nc, len(self.img_files)
        x['msgs'] = msgs  # warnings
        x['version'] = self.cache_version  # cache version
        x['ft_coef'] = self.ft_coef
        x['mask_line'] = self.mask_line
        try:
            np.save(path, x) #np.save会自动在path后面加上.npy形成保存文件名：labels.cache.npy
            cache_file = path.with_suffix(f'{self.suffix}.npy') #cache_file=labels.cache.npy去掉末尾的.npy后缀还原成path=labels.cache
            if os.path.exists(path): #如果已存在path=labels.cache文件就会报错，所有要先删掉
                path.unlink()
            cache_file.rename(path) #labels.cache.npy->labels.cache 去掉labels.cache.npy末尾的.npy后缀还原成path=labels.cache
            logging.info(f'{prefix}New cache created: {path}')
        except Exception as e:
            logging.info(f'{prefix}WARNING: Cache directory {path.parent} is not writeable: {e}')  # path not writeable
        return x

    def __len__(self):
        return len(self.img_files)

    # def __iter__(self):
    #     self.count = -1
    #     print('ran dataset iter')
    #     #self.shuffled_vector = np.random.permutation(self.nF) if self.augment else np.arange(self.nF)
    #     return self

    def __getitem__(self, index):
        index = self.indices[index]  # linear, shuffled, or image_weights
        hyp = self.hyp
        mosaic = self.mosaic and random.random() < hyp['mosaic']
        if mosaic:
            # Load mosaic
            img, labels = load_mosaic(self, index)
            #img[h,w,3]  labels[n,5=1+4]
            shapes = None

            # MixUp augmentation
            if random.random() < hyp['mixup']:
                img, labels = mixup(img, labels, *load_mosaic(self, random.randint(0, self.n - 1), hyp.get('auto_aug_pts',0)))

        else:
            # Load image
            img, (h0, w0), (h, w) = load_image(self, index)

            # Letterbox
            shape = self.batch_shapes[self.batch[index]] if self.rect else self.img_size  # final letterboxed shape
            img, ratio, pad = letterbox(img, shape, auto=False, scaleup=self.augment)#img[H,W,C=3]
            shapes = (h0, w0), ((h / h0, w / w0), pad)  # for COCO mAP rescaling

            #filt out wrong 3d labels,z<=0
            labels_sel = self.labels[index]
            assert(not np.isnan(labels_sel[:,-1]).any())
            #self.labels[index] = labels_sel[~np.isnan(labels_sel[:,-1])] #labels[nobj,13=1(cls)+4(box)+4(q)+3(abc)+1(z)]
            #self.labels = [t for t in self.labels if t[:,-1]>0]
            #assert(np.sum(self.labels[:,-1]==0)==0)
            labels = self.labels[index].copy()#[nobj,13=1(cls)+4(box)+4(q)+3(abc)+1(z)]

            if labels.size:  # normalized xywh to pixel xyxy format转换为[左上角,右下角,绝对坐标x1,绝对坐标y1,...,绝对坐标x4,绝对坐标y4]
                labels[:, 1:5] = xywhn2xyxy(labels[:, 1:5], ratio[0] * w, ratio[1] * h, padw=pad[0], padh=pad[1])
                labels[:, 5:] = ftnorm2ft(labels[:, 5:], ratio[0] * w, ratio[1] * h, padw=pad[0], padh=pad[1])

            if self.augment and random.random() < hyp.get('augment',0.6):#hyp['augment']是数据增广概率
                img, labels = random_perspective(img, labels,
                                                 degrees=hyp.get('degrees',0),
                                                 translate=hyp.get('translate',0),
                                                 scale=hyp.get('scale',0.0),
                                                 shear=hyp.get('shear',0),
                                                 perspective=hyp.get('perspective',0), # 测试过如果使用透视变换则有误
                                                 flip = [self.hyp.get('fliplr',0),self.hyp.get('flipud',0)],
                                                 auto_aug_pts=hyp.get('auto_aug_pts',0),
                                                 clip_robx=False)
                # HSV color-space
                augment_hsv(img, hgain=hyp.get('hsv_h',0.015), sgain=hyp.get('hsv_s',0.7), vgain=hyp.get('hsv_v',0.4))
            
        if self.labels[0] is not None:
            labels = filt_labels_H(torch.from_numpy(labels),self.least_pixel_size,self.least_area).numpy()
            # labels[labels[:,-1]<self.nearest_z,-1] = self.nearest_z #clip the near objects

        nl = len(labels)  # number of labels
        if nl:
            # after aug show
            if self.debug_samples > 0:
                ft_image = show_ft(img, labels[:,0], labels[:, 1:5], labels[:, 5:], colors = colors) #labels[:, 1:5]
                name = os.path.splitext(os.path.basename(self.img_files[index]))[0]
                debug_samples_path = str(self.save_dir) + '/debug_samples/'
                if(not os.path.exists(debug_samples_path)):
                    os.makedirs(debug_samples_path, exist_ok=True)
                cv2.imencode('.jpg', ft_image)[1].tofile(f'{debug_samples_path}/aug[{index}]_{name}.jpg')
                self.debug_samples-=1
            # labels[:, 1:5] = xyxy2xywhn(labels[:, 1:5], w=img.shape[1], h=img.shape[0], clip=False, eps=1E-3)
            labels[:, 1:] = xyxy2xywhn(labels[:, 1:], w=img.shape[1], h=img.shape[0], clip=False, eps=1E-3)
            labels[:, 5:] = ft2ftnorm(labels[:, 5:], w=img.shape[1], h=img.shape[0])

        labels_out = torch.zeros((nl, 1+labels.shape[-1]))#labels_out[1(batch)+1(cls)+4(box)+4(q)+3(abc)3+1/3(xyz)]
        if nl:
            labels_out[:, 1:] = torch.from_numpy(labels)#labels_out[1(batch)+1(cls)+4(box)+4(q)+3(abc)3+1/3(xyz)]
            #注意第0列在collate_fn里面填入batch
        #labels_out[nt,1(b)+13=(1(cls)+4(box)+4(q)+3(abc)3+1/3(xyz)]

        # Convert
        img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        img = np.ascontiguousarray(img)

        return torch.from_numpy(img), labels_out, self.img_files[index], shapes

    @staticmethod
    def collate_fn(batch):
        img, label, path, shapes = zip(*batch)  # transposed
        for i, l in enumerate(label):
            l[:, 0] = i  # add target image index for build_targets()
        return torch.stack(img, 0), torch.cat(label, 0), path, shapes

    @staticmethod
    def collate_fn4(batch):
        img, label, path, shapes = zip(*batch)  # transposed
        n = len(shapes) // 4
        img4, label4, path4, shapes4 = [], [], path[:n], shapes[:n]

        ho = torch.tensor([[0., 0, 0, 1, 0, 0]])
        wo = torch.tensor([[0., 0, 1, 0, 0, 0]])
        s = torch.tensor([[1, 1, .5, .5, .5, .5]])  # scale
        for i in range(n):  # zidane torch.zeros(16,3,720,1280)  # BCHW
            i *= 4
            if random.random() < 0.5:
                im = F.interpolate(img[i].unsqueeze(0).float(), scale_factor=2., mode='bilinear', align_corners=False)[
                    0].type(img[i].type())
                l = label[i]
            else:
                im = torch.cat((torch.cat((img[i], img[i + 1]), 1), torch.cat((img[i + 2], img[i + 3]), 1)), 2)
                l = torch.cat((label[i], label[i + 1] + ho, label[i + 2] + wo, label[i + 3] + ho + wo), 0) * s
            img4.append(im)
            label4.append(l)

        for i, l in enumerate(label4):
            l[:, 0] = i  # add target image index for build_targets()

        return torch.stack(img4, 0), torch.cat(label4, 0), path4, shapes4

# Ancillary functions --------------------------------------------------------------------------------------------------
def load_image(self, i):
    # loads 1 image from dataset index 'i', returns im, original hw, resized hw
    im = self.imgs[i]
    if im is None:  # not cached in ram
        npy = self.img_npy[i]
        if npy and npy.exists():  # load npy
            im = np.load(npy)
        else:  # read image
            path = self.img_files[i]
            im = cv2.imdecode(np.fromfile(path, dtype=np.uint8),cv2.IMREAD_COLOR)#cv2.imread(path)  # BGR
            assert im is not None, 'Image Not Found ' + path
        h0, w0 = im.shape[:2]  # orig hw
        if isinstance(self.img_size, int):#如果是单一长度，则按不变的长宽比缩放
            r = self.img_size / max(h0, w0)  # ratioa
        else:
            r = min(self.img_size[0] / h0, self.img_size[1] / w0)

        if r != 1:  # if sizes are not equal
            im = cv2.resize(im, (round(w0 * r), round(h0 * r)),
                            interpolation=cv2.INTER_AREA if r < 1 and not self.augment else cv2.INTER_LINEAR)
        if self.cache_mosaic: #if self.augment:
            self.imgs[i], self.img_hw0[i], self.img_hw[i] = im, (h0, w0), im.shape[:2]  # im, hw_original, hw_resized
            self.buffer.append(i)
            if 1 < len(self.buffer) >= self.max_buffer_length:  # prevent empty buffer
                j = self.buffer.pop(0)
                if self.cache != "ram":
                    self.imgs[j], self.img_hw0[j], self.img_hw[j] = None, None, None
        return im, (h0, w0), im.shape[:2]  # im, hw_original, hw_resized
    else:
        return self.imgs[i], self.img_hw0[i], self.img_hw[i]  # im, hw_original, hw_resized


def load_mosaic(self, index):
    # loads images in a 4-mosaic
    labels4, segments4 = [], []
    s = [self.img_size,self.img_size] if(isinstance(self.img_size,int)) else self.img_size
    yc, xc = [int(random.uniform(-x, 2 * s[i] + x)) for i,x in enumerate(self.mosaic_border)]  # mosaic center x, y
    if self.cache_mosaic:
        indices = [index] + random.choices(self.buffer if len(self.buffer)>self.max_buffer_length//2 else self.indices, k=3)  # 3 additional image indices
    else:
        indices = [index] + random.choices(self.indices, k=3)  # 3 additional image indices
    # random.shuffle(indices)
    for i, index in enumerate(indices):
        # Load image
        img, _, (h, w) = load_image(self, index)

        # place img in img4
        if i == 0:  # top left
            img4 = np.full((s[0] * 2, s[1] * 2, img.shape[2]), 114, dtype=np.uint8)  # base image with 4 tiles
            x1a, y1a, x2a, y2a = max(xc - w, 0), max(yc - h, 0), xc, yc  # xmin, ymin, xmax, ymax (large image)
            x1b, y1b, x2b, y2b = w - (x2a - x1a), h - (y2a - y1a), w, h  # xmin, ymin, xmax, ymax (small image)
        elif i == 1:  # top right
            x1a, y1a, x2a, y2a = xc, max(yc - h, 0), min(xc + w, s[1] * 2), yc
            x1b, y1b, x2b, y2b = 0, h - (y2a - y1a), min(w, x2a - x1a), h
        elif i == 2:  # bottom left
            x1a, y1a, x2a, y2a = max(xc - w, 0), yc, xc, min(s[0] * 2, yc + h)
            x1b, y1b, x2b, y2b = w - (x2a - x1a), 0, w, min(y2a - y1a, h)
        elif i == 3:  # bottom right
            x1a, y1a, x2a, y2a = xc, yc, min(xc + w, s[1] * 2), min(s[0] * 2, yc + h)
            x1b, y1b, x2b, y2b = 0, 0, min(w, x2a - x1a), min(y2a - y1a, h)

        img4[y1a:y2a, x1a:x2a] = img[y1b:y2b, x1b:x2b]  # img4[ymin:ymax, xmin:xmax]
        padw = x1a - x1b
        padh = y1a - y1b

        # Labels
        labels, segments = self.labels[index].copy(), self.segments[index].copy()
        if labels.size:
            labels[:, 1:5] = xywhn2xyxy(labels[:, 1:5], w, h, padw, padh)  # normalized xywh to pixel xyxy format
            labels[:, 5:] = ftnorm2ft(labels[:, 5:], w, h, padw=padw, padh=padh)
            x2a = min(x2a, img4.shape[1])
            y2a = min(y2a, img4.shape[0])
            x1a = max(x1a, 0)
            y1a = max(y1a, 0)

            ind = box_candidates_ioa(boxes=labels[:, 1:5], width=x2a, height=y2a, iou_thr=0.2, w_min=x1a, h_min=y1a)
            labels = labels[ind]
            xyxy = labels[:, 1:5].copy()
            xyxy[:, 0] = np.clip(xyxy[:, 0], x1a, x2a)  # x1
            xyxy[:, 1] = np.clip(xyxy[:, 1], y1a, y2a)  # y1
            xyxy[:, 2] = np.clip(xyxy[:, 2], x1a, x2a)  # x2
            xyxy[:, 3] = np.clip(xyxy[:, 3], y1a, y2a)  # y2
            labels[:, 1:5] = xyxy
            segments = [xyn2xy(x, w, h, padw, padh) for x in segments]
        if True: #i==1 and index==83559:
            labels4.append(labels)
        else:
            labels4.append(np.zeros((0,labels.shape[-1]),dtype=float))
        segments4.extend(segments)

    # Concat/clip labels
    labels4 = np.concatenate(labels4, 0)

    for x in (*labels4[:, 1:5], *segments4):
        # np.clip(x, 0, 2 * s, out=x)  # clip when using random_perspective()
        np.clip(x[0::2], 0, 2 * s[1], out=x[0::2])  # clip when using random_perspective()
        np.clip(x[1::2], 0, 2 * s[0], out=x[1::2])  # clip when using random_perspective()
    img4, labels4, segments4 = copy_paste(img4, labels4, segments4, p=self.hyp['copy_paste'])

    # img4, labels4 = replicate(img4, labels4)  # replicate

    # Augment
    img4, labels4 = random_perspective(img4, labels4, segments4,
                                       degrees=self.hyp.get('degrees',0),
                                       translate=self.hyp.get('translate',0),
                                       scale=self.hyp.get('scale',0.0),
                                       shear=self.hyp.get('shear',0),
                                       perspective=self.hyp.get('perspective',0),
                                       flip = [self.hyp.get('fliplr',0),self.hyp.get('flipud',0)],
                                       border=self.mosaic_border,
                                       auto_aug_pts = self.hyp.get('auto_aug_pts',0),
                                       clip_robx=False)  # border to remove
    # HSV color-space
    augment_hsv(img4, hgain=self.hyp.get('hsv_h',0.015), sgain=self.hyp.get('hsv_s',0.7), vgain=self.hyp.get('hsv_v',0.4))

    return img4, labels4

def create_folder(path='./new'):
    # Create folder
    if os.path.exists(path):
        shutil.rmtree(path)  # delete output folder
    os.makedirs(path)  # make new output folder


def flatten_recursive(path='../datasets/coco128'):
    # Flatten a recursive directory by bringing all files to top level
    new_path = Path(path + '_flat')
    create_folder(new_path)
    for file in tqdm(glob.glob(str(Path(path)) + '/**/*.*', recursive=True)):
        shutil.copyfile(file, new_path / Path(file).name)


def extract_boxes(path='../datasets/coco128'):  # from utils.datasets import *; extract_boxes()
    # Convert detection dataset into classification dataset, with one directory per class
    path = Path(path)  # images dir
    shutil.rmtree(path / 'classifier') if (path / 'classifier').is_dir() else None  # remove existing
    files = list(path.rglob('*.*'))
    n = len(files)  # number of files
    for im_file in tqdm(files, total=n):
        if im_file.suffix[1:] in IMG_FORMATS:
            # image
            im = cv2.imread(str(im_file))[..., ::-1]  # BGR to RGB
            h, w = im.shape[:2]

            # labels
            lb_file = Path(img2label_paths([str(im_file)])[0])
            if Path(lb_file).exists():
                with open(lb_file, 'r') as f:
                    lb = np.array([x.split() for x in f.read().strip().splitlines()], dtype=np.float32)  # labels

                for j, x in enumerate(lb):
                    c = int(x[0])  # class
                    f = (path / 'classifier') / f'{c}' / f'{path.stem}_{im_file.stem}_{j}.jpg'  # new filename
                    if not f.parent.is_dir():
                        f.parent.mkdir(parents=True)

                    b = x[1:] * [w, h, w, h]  # box
                    # b[2:] = b[2:].max()  # rectangle to square
                    b[2:] = b[2:] * 1.2 + 3  # pad
                    b = xywh2xyxy(b.reshape(-1, 4)).ravel().astype(np.int)

                    b[[0, 2]] = np.clip(b[[0, 2]], 0, w)  # clip boxes outside of image
                    b[[1, 3]] = np.clip(b[[1, 3]], 0, h)
                    assert cv2.imwrite(str(f), im[b[1]:b[3], b[0]:b[2]]), f'box failure in {f}'


def autosplit(path='../datasets/coco128/images', weights=(0.9, 0.1, 0.0), annotated_only=False):
    """ Autosplit a dataset into train/val/test splits and save path/autosplit_*.txt files
    Usage: from utils.datasets import *; autosplit()
    Arguments
        path:            Path to images directory
        weights:         Train, val, test weights (list, tuple)
        annotated_only:  Only use images with an annotated txt file
    """
    path = Path(path)  # images dir
    files = sum([list(path.rglob(f"*.{img_ext}")) for img_ext in IMG_FORMATS], [])  # image files only
    n = len(files)  # number of files
    random.seed(0)  # for reproducibility
    indices = random.choices([0, 1, 2], weights=weights, k=n)  # assign each image to a split

    txt = ['autosplit_train.txt', 'autosplit_val.txt', 'autosplit_test.txt']  # 3 txt files
    [(path.parent / x).unlink(missing_ok=True) for x in txt]  # remove existing

    print(f'Autosplitting images from {path}' + ', using *.txt labeled images only' * annotated_only)
    for i, img in tqdm(zip(indices, files), total=n):
        if not annotated_only or Path(img2label_paths([str(img)])[0]).exists():  # check label
            with open(path.parent / txt[i], 'a') as f:
                f.write('./' + img.relative_to(path.parent).as_posix() + '\n')  # add image to txt file

import spectral as sp
def load_image_bsq(im_file):
    ext = os.path.splitext(im_file)[1].lower()  # 获取扩展名
    if ext in [".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"]:
        # 普通图像，用PIL读取
        im = Image.open(im_file)
        return im
    elif ext == ".bsq":
        # 高光谱数据，需要有对应的 .hdr 文件
        hdr_file = im_file.replace(".bsq", ".hdr")
        if not os.path.exists(hdr_file):
            raise FileNotFoundError(f"缺少对应的 .hdr 文件: {hdr_file}")
        
        img = sp.open_image(hdr_file)
        data = img.load()  # numpy数组 (rows, cols, bands)
        return data
    else:
        raise ValueError(f"暂不支持的文件格式: {ext}")

def verify_image_label(args):
    # Verify one image-label pair
    im_file, lb_file, prefix, ft_coef, mask_line, hull = args
    nm, nf, ne, nc, msg, segments = 0, 0, 0, 0, '', []  # number (missing, found, empty, corrupt), message, segments
    try:
        # verify images
        im = load_image_bsq(im_file) #Image.open(im_file)
        # im.verify()  # PIL verify
        shape = exif_size(im)  # image size
        assert (shape[0] > 9) & (shape[1] > 9), f'image size {shape} <10 pixels'
        assert im.format.lower() in IMG_FORMATS, f'invalid image format {im.format}'
        if im.format.lower() in ('jpg', 'jpeg'):
            with open(im_file, 'rb') as f:
                f.seek(-2, 2)
                if f.read() != b'\xff\xd9':  # corrupt JPEG
                    Image.open(im_file).save(im_file, format='JPEG', subsampling=0, quality=100)  # re-save image
                    msg = f'{prefix}WARNING: corrupt JPEG restored and saved {im_file}'

        # verify labels
        lb_file = Path(lb_file)
        pol_file = lb_file.with_suffix('.pol')
        ft_p = None
        if os.path.exists(pol_file):
            nf = 1  # label found
            with open(pol_file) as f: #.pts
                pol_p = [np.array(x.split(), dtype=np.float32) for x in f.read().strip().splitlines() if len(x.strip())]    # cls x1,y1,x2,y2...,xn,yn
            nl = len(pol_p)
            ft_p = []
            l = []
            l_ft = []
            if nl:
                for pol in pol_p:
                    x1, y1, x2, y2 = min(pol[1::2]), min(pol[2::2]), max(pol[1::2]), max(pol[2::2])
                    l.append([pol[0], (x1+x2)/2, (y1+y2)/2, x2-x1, y2-y1])
                    ft_p.append(pol[1:])
                if any([len(x) > 8 for x in l]):  # is segment
                    classes = np.array([x[0] for x in l], dtype=np.float32)
                    segments = [np.array(x[1:], dtype=np.float32).reshape(-1, 2) for x in l]  # (cls, xy1...)
                    l = np.concatenate((classes.reshape(-1, 1), segments2boxes(segments)), 1)  # (cls, xywh)
                l = np.array(l, dtype=np.float32)
        elif os.path.isfile(lb_file):
            nf = 1  # label found
            with open(lb_file, 'r') as f:
                l = [x.split() for x in f.read().strip().splitlines() if len(x)]
                if any([len(x) > 8 for x in l]):  # is segment
                    classes = np.array([x[0] for x in l], dtype=np.float32)
                    segments = [np.array(x[1:], dtype=np.float32).reshape(-1, 2) for x in l]  # (cls, xy1...)
                    l = np.concatenate((classes.reshape(-1, 1), segments2boxes(segments)), 1)  # (cls, xywh)
                l = np.array(l, dtype=np.float32)
            nl = len(l)
            if nl:
                assert l.shape[1] == 5, 'labels require 5 columns each'
                # assert (l[:, 1:] <= 1).all(), 'non-normalized or out of bounds coordinate labels'
                # assert np.unique(l, axis=0).shape[0] == l.shape[0], 'duplicate labels'
                ft_file = lb_file.with_suffix('.ft')
                if os.path.exists(ft_file):
                    with open(ft_file) as f: #.dir (4)
                        l_ft = [x.split() for x in f.read().strip().splitlines() if len(x)]#l_ft[nt][str[4]]
                        l_ft = np.array(l_ft, dtype=np.float32)
                        if len(l_ft.shape) == 2:
                            l_ft = l_ft[:, 1: 1 + 2 + ft_coef * 4]#list转np矩阵 l_ft[nt][str[4]]-->l_ft[nt,4]
                    assert l.shape[0] == l_ft.shape[0], "bbox标签数量不匹配, [ft]"
                    for i_ in range(l_ft.shape[0]):
                        if mask_line is not None:
                            flag = mask_line[int(l[i_, 0])] == 1
                        else:
                            flag = False
                        if flag:
                            l_ft[:, 3::2] == 0. # 设b d 为0 
                else:
                    l_ft = []
                    xc,yc,w,h = l[:, 1:].T
                    w2, h2 = w/2, h/2
                    # [str(round(xc-w/2,6)),str(round(yc-h/2,6)),
                    #                     str(round(xc+w/2,6)),str(round(yc-h/2,6)),
                    #                     str(round(xc+w/2,6)),str(round(yc+h/2,6)),
                    #                     str(round(xc-w/2,6)),str(round(yc+h/2,6))]
                    if os.path.exists(lb_file.with_suffix('.pts')):
                        with open(lb_file.with_suffix('.pts')) as f: #.pts
                            p = [x.split() for x in f.read().strip().splitlines() if len(x)]
                        for i in range(len(p)):
                            if p[i]==['-']:#无数据，针对非旋转目标的情况,填入水平框四个角点坐标
                                xc,yc,w,h = float(l[i][1]),float(l[i][2]),float(l[i][3]),float(l[i][4])
                                #p[i] = [str(round(xc-w/2,6)),'0','0','0','0','0','0','0']
                                p[i] = [str(round(xc-w/2,6)),str(round(yc-h/2,6)),
                                        str(round(xc+w/2,6)),str(round(yc-h/2,6)),
                                        str(round(xc+w/2,6)),str(round(yc+h/2,6)),
                                        str(round(xc-w/2,6)),str(round(yc+h/2,6))]
                                #由于后面p = np.array(p, dtype=np.float32)要求字符串必须是数值的，'-'转数据矩阵会报错
                                #也就是水平框的四个顶点构建四边形
                        ft_p = np.array(p, dtype=np.float32)#list转np矩阵[nt,4*2=8]
                    else:
                        ft_p = np.stack([xc - w2, yc - h2, 
                                        xc + w2, yc - h2, 
                                        xc + w2, yc + h2, 
                                        xc - w2, yc + h2],
                                        axis=-1)
                    assert l.shape[0] == len(ft_p), "bbox标签数量不匹配, [pol/pts]"
        else:
            nm = 1  # label missing
            nl = 0
        if nl:
            if ft_p is not None:
                for i_ in range(len(ft_p)):
                    poly = ft_p[i_]
                    flag = mask_line is not None and mask_line[int(l[i_, 0])]==1
                    if flag==0 and hull:
                        poly = cv2.convexHull(poly.reshape(-1, 2)).reshape(-1, 2).flatten() #poly[n,2]->poly[2n]
                    ft1 = compute_coefficients(poly,terms=ft_coef, interp=True, line=flag)
                    # if not flag:
                    #     ft_area = fft_area(ft1)
                    #     if ft_area<0:
                    #         reverse_fft(ft1)
                    l_ft.append(ft1)
                l_ft = np.array(l_ft, dtype=np.float32)
                # l_ft = np.zeros([l.shape[0], 2 + ft_coef * 4], dtype=np.float32)
            #l_ft[nt,2+4n]
            if mask_line is None:
                ft_area = fft_areas(l_ft)#l_ft[nt,2+4n]->ft_area[nt]
                reverse_ffts(l_ft[ft_area<0]) ##l_ft[nt2,2+4n]
            else:
                mask_line_array = np.array(mask_line, dtype=bool)
                mask_roll = mask_line_array[l[:,0].astype(np.int32)]==False
                ft_area = fft_areas(l_ft)#l_ft[nt,2+4n]->ft_area[nt]
                reverse_ffts(l_ft[mask_roll & (ft_area<0)]) ##l_ft[nt2,2+4n]

            assert (l_ft.shape[0]==l.shape[0]), "bbox标签数量不匹配, [pol/pts]"#dir的行数即目标数  和  lables里的行数目标数应该一致

            l = np.concatenate((l, l_ft), axis=1)#把dir,abc,xyz数据p拼到原始yolo标签l后面:l[nt,5] cat p[nt,4+3+1]-->p[nt,5 + 4(q)+3(abc)+1(D)]
            assert (l.shape[1] >= 5 + 2 + ft_coef * 4), f'labels require {5 + 2 + ft_coef * 4} columns, {l.shape[1]} columns detected'
            #
            assert (l[:, 0] >= 0).all(), f'negative class index {l[0]}'
            nl2 = len(l)
            l = np.unique(l, axis=0)  # remove duplicate rows,  同一目标重复标注，合并
            if len(l) < nl2:
                segments = np.unique(segments, axis=0)
                msg = f'{prefix}WARNING: {im_file}: {nl - len(l)} duplicate labels removed'

            assert (l[:, 0] >= 0).all(), 'negative labels'
                # assert (l[:, 1:] >= -0.3).all() and (l[:, 1:] <= 1.3).all(), 'over range labels'
        else:
            ne = 1 if nm == 0 else 0  # label empty
            l = np.zeros((0, 5 + 2 + ft_coef * 4), dtype=np.float32)
        return im_file, l, shape, segments, nm, nf, ne, nc, msg
    except Exception as e:
        nc = 1
        msg = f'{prefix}WARNING: Ignoring corrupted image and/or label {im_file}: {e}'
        return [None, None, None, None, nm, nf, ne, nc, msg]


def dataset_stats(path='coco128.yaml', autodownload=False, verbose=False, profile=False, hub=False):
    """ Return dataset statistics dictionary with images and instances counts per split per class
    To run in parent directory: export PYTHONPATH="$PWD/yolov5"
    Usage1: from utils.datasets import *; dataset_stats('coco128.yaml', autodownload=True)
    Usage2: from utils.datasets import *; dataset_stats('../datasets/coco128_with_yaml.zip')
    Arguments
        path:           Path to data.yaml or data.zip (with data.yaml inside data.zip)
        autodownload:   Attempt to download dataset if not found locally
        verbose:        Print stats dictionary
    """

    def round_labels(labels):
        # Update labels to integer class and 6 decimal place floats
        return [[int(c), *[round(x, 4) for x in points]] for c, *points in labels]

    def unzip(path):
        # Unzip data.zip TODO: CONSTRAINT: path/to/abc.zip MUST unzip to 'path/to/abc/'
        if str(path).endswith('.zip'):  # path is data.zip
            assert Path(path).is_file(), f'Error unzipping {path}, file not found'
            assert os.system(f'unzip -q {path} -d {path.parent}') == 0, f'Error unzipping {path}'
            dir = path.with_suffix('')  # dataset directory
            return True, str(dir), next(dir.rglob('*.yaml'))  # zipped, data_dir, yaml_path
        else:  # path is data.yaml
            return False, None, path

    def hub_ops(f, max_dim=1920):
        # HUB ops for 1 image 'f'
        im = Image.open(f)
        r = max_dim / max(im.height, im.width)  # ratio
        if r < 1.0:  # image too large
            im = im.resize((int(im.width * r), int(im.height * r)))
        im.save(im_dir / Path(f).name, quality=75)  # save

    zipped, data_dir, yaml_path = unzip(Path(path))
    with open(check_file(yaml_path), errors='ignore') as f:
        data = yaml.safe_load(f)  # data dict
        if zipped:
            data['path'] = data_dir  # TODO: should this be dir.resolve()?
    check_dataset(data, autodownload)  # download dataset if missing
    hub_dir = Path(data['path'] + ('-hub' if hub else ''))
    stats = {'nc': data['nc'], 'names': data['names']}  # statistics dictionary
    for split in 'train', 'val', 'test':
        if data.get(split) is None:
            stats[split] = None  # i.e. no test set
            continue
        x = []
        dataset = LoadImagesAndLabels(data[split])  # load dataset
        for label in tqdm(dataset.labels, total=dataset.n, desc='Statistics'):
            x.append(np.bincount(label[:, 0].astype(int), minlength=data['nc']))
        x = np.array(x)  # shape(128x80)
        stats[split] = {'instance_stats': {'total': int(x.sum()), 'per_class': x.sum(0).tolist()},
                        'image_stats': {'total': dataset.n, 'unlabelled': int(np.all(x == 0, 1).sum()),
                                        'per_class': (x > 0).sum(0).tolist()},
                        'labels': [{str(Path(k).name): round_labels(v.tolist())} for k, v in
                                   zip(dataset.img_files, dataset.labels)]}

        if hub:
            im_dir = hub_dir / 'images'
            im_dir.mkdir(parents=True, exist_ok=True)
            for _ in tqdm(ThreadPool(NUM_THREADS).imap(hub_ops, dataset.img_files), total=dataset.n, desc='HUB Ops'):
                pass

    # Profile
    stats_path = hub_dir / 'stats.json'
    if profile:
        for _ in range(1):
            file = stats_path.with_suffix('.npy')
            t1 = time.time()
            np.save(file, stats)
            t2 = time.time()
            x = np.load(file, allow_pickle=True)
            print(f'stats.npy times: {time.time() - t2:.3f}s read, {t2 - t1:.3f}s write')

            file = stats_path.with_suffix('.json')
            t1 = time.time()
            with open(file, 'w') as f:
                json.dump(stats, f)  # save stats *.json
            t2 = time.time()
            with open(file, 'r') as f:
                x = json.load(f)  # load hyps dict
            print(f'stats.json times: {time.time() - t2:.3f}s read, {t2 - t1:.3f}s write')

    # Save, print and return
    if hub:
        print(f'Saving {stats_path.resolve()}...')
        with open(stats_path, 'w') as f:
            json.dump(stats, f)  # save stats.json
    if verbose:
        print(json.dumps(stats, indent=2, sort_keys=False))
    return stats


def resize_and_save_images(data_path, num=64, imgsz=[640,640]):
    src_folder = data_path + '/images'
    dst_folder = data_path + '/qnt_imgs'
    # 确保目标文件夹存在
    if not os.path.exists(dst_folder):
        os.makedirs(dst_folder)

    # 支持的图像扩展名
    extensions = ['.jpg', '.png', '.bmp', '.tif']
    
    # 获取所有符合条件的图像文件
    image_files = [os.path.join(src_folder, f) for f in os.listdir(src_folder)
                   if os.path.splitext(f)[1].lower() in extensions]
    
    # 随机选择指定数量的图像文件
    selected_images = random.sample(image_files, num)
    
    # 调整图像大小并保存到目标文件夹
    for i, image_file in tqdm(enumerate(selected_images)):
        with Image.open(image_file) as img:
            try:
                resized_img = img.resize((imgsz[1], imgsz[0]), Image.Resampling.LANCZOS)
            except AttributeError:
                # 如果失败，回退到旧的 Image.ANTIALIAS
                resized_img = img.resize((imgsz[1], imgsz[0]), Image.ANTIALIAS)
            # 保存图像到目标文件夹
            base_name = os.path.basename(image_file)
            resized_img.save(os.path.join(dst_folder, base_name))
            #print(f"Saved {i+1}/{num}: {os.path.join(dst_folder, base_name)}")


def get_calib_name(image_path):
    # 获取文件名和其父目录路径
    dir_path, filename = os.path.split(image_path)
    parent_dir, current_dir = os.path.split(dir_path)

    # 将当前目录名（即'images'）替换为'calib'
    new_dir_path = os.path.join(parent_dir, 'calib')

    # 更改文件扩展名为'.txt'
    file_base, _ = os.path.splitext(filename)
    new_filename = file_base + '.txt'

    # 组合新的目录路径和文件名
    calib_path = os.path.join(new_dir_path, new_filename)
    return calib_path

def load_calib(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # 遍历每一行，找到以'P0:'开头的行
    for line in lines:
        if line.startswith('P0:'):
            # 去掉行首的'P0:'，并按空格分割剩余内容
            data_str = line.strip().split(' ')[1:]
            # 将字符串列表转换为浮点数列表
            data = [float(item) for item in data_str]
            # 将数据重塑为3x4的矩阵
            P0_matrix = np.array(data).reshape(3, 4)
            # 提取左侧3x3子矩阵K
            K_matrix = P0_matrix[:, :3]
            # 输出K矩阵
            #print("3x3子矩阵K为：\n", K_matrix)
            return K_matrix
    return None


def compute_coefficients(xy, terms=2, interp=False, dist=True, line=False): # [0 ~ terms] 4  a0c0 a2~d2 6 2
    x = np.array(xy[0::2])
    y = np.array(xy[1::2])  # points 
    if interp:
        if dist:
            if not line:
                x = np.concatenate([x, [x[0]]], dtype=np.float32)
                y = np.concatenate([y, [y[0]]], dtype=np.float32)
            else:
                x = np.concatenate([x, x[::-1]], dtype=np.float32)
                y = np.concatenate([y, y[::-1]], dtype=np.float32)
            distances = np.concatenate([np.zeros(1), np.sqrt((x[1:] - x[:-1]) ** 2 + (y[1:] - y[:-1]) ** 2)], dtype=np.float32)
            distances = np.cumsum(distances)
            ori = distances / distances[-1]
        else:
            ori = np.linspace(0, 1, x.shape[0], endpoint=True)
        gap = np.linspace(0, 1, max(terms*2, x.shape[0] - 1), endpoint=False) #点的总数(x.shape[0]-1)应该>=2*terms(即阶数-1)
        x = np.interp(gap, ori, x)  # 0, x0; 0.25, x1; 0.5, x2; 0.75, x3; 1, x0;
        y = np.interp(gap, ori, y)
        N = x.shape[0]
    else:
        N = x.shape
    # if line:
    #     t = np.linspace(0, 1*np.pi, N, endpoint=False)  # t = t*2pi/n
    # else:
    t = np.linspace(0, 2*np.pi, N, endpoint=False)  # t = t*2pi/n
    a0 = 1./N * sum(x)
    c0 = 1./N * sum(y)
    
    an, bn, cn, dn = [np.zeros(1 + terms) for i in range(4)]
    
    for k in range(1, (N // 2) + 1):    # 1,2,...,int(N/2)
        if k > terms:
            break
        an[k] = 2./N * sum(x * np.cos(k*t))
        # bn[k] = 2./N * sum(x * np.sin(k*t))
        bn[k] = (2./N * sum(x * np.sin(k*t))) if not line else 0
        cn[k] = 2./N * sum(y * np.cos(k*t))
        # dn[k] = 2./N * sum(y * np.sin(k*t))
        dn[k] = (2./N * sum(y * np.sin(k*t))) if not line else 0
    list_coef = [a0, c0]
    for k in range(1, an.shape[0]):
        list_coef.append(an[k])
        list_coef.append(bn[k])
        list_coef.append(cn[k])
        list_coef.append(dn[k])
    return list_coef    # a0, c0, a1, b1, c1, d1, ... ak, bn, ck, dk
