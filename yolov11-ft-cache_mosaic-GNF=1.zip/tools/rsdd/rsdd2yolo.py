import os
import math
import xml.etree.ElementTree as ET
from tqdm import tqdm

def parse_and_convert(xml_path, label_output_dir, name2id):
    tree = ET.parse(xml_path)
    root = tree.getroot()

    W = int(root.find('size/width').text)
    H = int(root.find('size/height').text)

    txt_lines = []
    pts_lines = []

    for obj in root.findall('object'):
        name = obj.find('name').text.strip()

        # 自动注册新类别
        if name not in name2id:
            name2id[name] = len(name2id)
        cls_id = name2id[name]

        robndbox = obj.find('robndbox')
        cx = float(robndbox.find('cx').text)
        cy = float(robndbox.find('cy').text)
        w = float(robndbox.find('w').text)
        h = float(robndbox.find('h').text)
        angle = float(robndbox.find('angle').text)

        # YOLO格式
        txt_line = f"{cls_id} {cx/W:.6f} {cy/H:.6f} {w/W:.6f} {h/H:.6f}"
        txt_lines.append(txt_line)

        # 四角点坐标（顺时针）
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        dx = h / 2
        dy = w / 2
        corners = [(-dx, -dy), (dx, -dy), (dx, dy), (-dx, dy)]

        pts = []
        for x_off, y_off in corners:
            x_rot = cx + x_off * cos_a - y_off * sin_a
            y_rot = cy + x_off * sin_a + y_off * cos_a
            pts.append(f"{x_rot/W:.6f} {y_rot/H:.6f}")
        pts_lines.append(" ".join(pts))

    # 写入对应 .txt 和 .pts
    base_name = os.path.splitext(os.path.basename(xml_path))[0]
    txt_path = os.path.join(label_output_dir, base_name + ".txt")
    pts_path = os.path.join(label_output_dir, base_name + ".pts")

    with open(txt_path, 'w') as f:
        f.write("\n".join(txt_lines))
    with open(pts_path, 'w') as f:
        f.write("\n".join(pts_lines))


def batch_convert(data_path, annotation_dir, label_output_dir):
    annotation_dir = os.path.join(data_path, annotation_dir)
    label_output_dir = os.path.join(data_path, label_output_dir)
    os.makedirs(label_output_dir, exist_ok=True)

    name2id = {}

    # 所有 xml 文件
    xml_files = [f for f in os.listdir(annotation_dir) if f.endswith('.xml')]

    for filename in tqdm(xml_files, desc="转换中", unit="文件"):
        xml_path = os.path.join(annotation_dir, filename)
        parse_and_convert(xml_path, label_output_dir, name2id)

    # 写入 names.txt
    names_path = os.path.join(data_path, 'names.txt')
    with open(names_path, 'w') as f:
        for name in sorted(name2id, key=lambda x: name2id[x]):
            f.write(name + "\n")

    print(f"✅ 转换完成：{len(xml_files)} 个 XML，生成 {len(name2id)} 个类别，已写入 names.txt")


if __name__ == "__main__":
    # 可自定义路径
    data_path = r'K:\datas\rsdd'  # 根目录
    annotation_dir = "Annotations"
    label_output_dir = "labels"

    batch_convert(data_path, annotation_dir, label_output_dir)
