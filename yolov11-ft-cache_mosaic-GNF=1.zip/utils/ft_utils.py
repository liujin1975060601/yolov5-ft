# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Wuqiang Li∗, Huan Li, Biyin Zhang, Yaorong Cen, Zhenfeng Shao",
#     title   = "Group-Normalized Fourier Detection for Arbitrary-Shaped Objects",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }
import numpy as np
import torch
import torch.nn.functional as F

def scale_coords_ft(img1_shape, coords, img0_shape, ratio_pad=None):
    # Rescale coords (xyxy) from img1_shape to img0_shape
    if ratio_pad is None:  # calculate from img0_shape
        gain = min(img1_shape[0] / img0_shape[0], img1_shape[1] / img0_shape[1])  # gain  = old / new
        pad = (img1_shape[1] - img0_shape[1] * gain) / 2, (img1_shape[0] - img0_shape[0] * gain) / 2  # wh padding
    else:
        gain = ratio_pad[0][0]
        pad = ratio_pad[1]

    coords[:, 0] -= pad[0]  # x padding
    coords[:, 1] -= pad[1]  # y padding
    coords /= gain
    return coords

def fft_1(coeffs,npts): #coeffs[2+4n]
    n = (len(coeffs) - 2) // 4
    t = np.linspace(0, 1, npts, endpoint=False)
    x = np.ones_like(t) * coeffs[0]
    y = np.ones_like(t) * coeffs[1]
    offset = 2
    for i in range(n):#i==0其实就是1阶了，所以i到n-1其实就是n阶
        assert offset + 4 <= len(coeffs)
        a, b, c, d = coeffs[offset : offset + 4]
        x += a * np.cos(2*np.pi*(i+1)*t) + b * np.sin(2*np.pi*(i+1)*t) #i==0其实就是1阶了，所以要i+1
        y += c * np.cos(2*np.pi*(i+1)*t) + d * np.sin(2*np.pi*(i+1)*t)
        offset+=4
    return x,y #x[npts],y[npts]
def fft_pts(coeffs, npts):
    # 傅里叶描述子重建轮廓
    # coeffs: 傅里叶系数数组 [2+4n]
    # npts: 采样点数
    # return: 轮廓点坐标数组 [npts, 2]
    n = (len(coeffs) - 2) // 4
    t = np.linspace(0, 1, npts, endpoint=False)
    
    # 初始化 x, y 坐标
    x = np.ones_like(t) * coeffs[0]
    y = np.ones_like(t) * coeffs[1]
    
    offset = 2
    for i in range(n):
        assert offset + 4 <= len(coeffs)
        a, b, c, d = coeffs[offset : offset + 4]
        x += a * np.cos(2*np.pi*(i+1)*t) + b * np.sin(2*np.pi*(i+1)*t)
        y += c * np.cos(2*np.pi*(i+1)*t) + d * np.sin(2*np.pi*(i+1)*t)
        offset += 4
    
    # 组合成 [npts, 2] 格式
    xy = np.column_stack((x, y))
    return xy #xy[npts,2]

# def ffts_1(coeffs, npts): #coeffs[nt,2+4n]
#     # coeffs: [nt, 2 + 4n]  -> [a0, c0, a1, b1, c1, d1, ..., an, bn, cn, dn]
#     # npts: 生成的曲线采样点数
#     # 返回:
#     #     x: [nt, npts]
#     #     y: [nt, npts]
#     nt, total_len = coeffs.shape
#     n = (total_len - 2) // 4  # 阶数
#     t = np.linspace(0, 1, npts, endpoint=False)  # [npts]
#     t = t[None, :]  # [1, npts]，方便广播

#     # 初始 a0, c0 项
#     x = np.ones((nt, npts)) * coeffs[:, 0:1] #x[nt,npts]
#     y = np.ones((nt, npts)) * coeffs[:, 1:2] #y[nt,npts]

#     offset = 2
#     for i in range(n):
#         a = coeffs[:, offset + 0][:, None]  # [nt, 1]
#         b = coeffs[:, offset + 1][:, None]
#         c = coeffs[:, offset + 2][:, None]
#         d = coeffs[:, offset + 3][:, None]

#         angle = 2 * np.pi * (i + 1) * t  # [1, npts]，广播到 [nt, npts]
#         cos_t = np.cos(angle)
#         sin_t = np.sin(angle)

#         x += a * cos_t + b * sin_t
#         y += c * cos_t + d * sin_t

#         offset += 4

#     return x, y #x[nt,npts],y[nt,npts]
def ffts_1(coeffs, npts):
    # 批量傅里叶逆变换
    # coeffs: [nt, 2 + 4*n] -> [a0, c0, a1, b1, c1, d1, ..., an, bn, cn, dn]
    # npts: 每条曲线采样点数
    # 返回:
    #     x: [nt, npts]
    #     y: [nt, npts]
    if isinstance(coeffs,np.ndarray): #numpy
        coeffs = coeffs.astype(np.float64)  # 确保浮点运算
        nt, total_len = coeffs.shape
        n = (total_len - 2) // 4  # 阶数
        t = np.linspace(0, 1, npts, endpoint=False)  # [npts]

        # 初始 a0, c0 项
        x = coeffs[:, 0:1] + np.zeros((nt, npts), dtype=np.float64)  # [nt,npts]
        y = coeffs[:, 1:2] + np.zeros((nt, npts), dtype=np.float64)

        offset = 2
        for i in range(n):
            a = coeffs[:, offset + 0][:, None]  # [nt,1]
            b = coeffs[:, offset + 1][:, None]
            c = coeffs[:, offset + 2][:, None]
            d = coeffs[:, offset + 3][:, None]

            angle = 2 * np.pi * (i + 1) * t  # [npts]
            cos_t = np.cos(angle)[None, :]  # [1, npts]
            sin_t = np.sin(angle)[None, :]

            x += a * cos_t + b * sin_t
            y += c * cos_t + d * sin_t

            offset += 4
    else: #torch
        # 确保是浮点类型，并保留设备
        coeffs = coeffs.to(torch.float64)
        device, dtype = coeffs.device, coeffs.dtype

        nt, total_len = coeffs.shape
        n = (total_len - 2) // 4

        # 采样时间向量（等价于 linspace(0, 1, npts, endpoint=False)）
        t = torch.arange(0, npts, device=device, dtype=dtype) / npts  # [npts]

        # 初始 a0, c0 项
        x = coeffs[:, 0:1] + torch.zeros((nt, npts), device=device, dtype=dtype)
        y = coeffs[:, 1:2] + torch.zeros((nt, npts), device=device, dtype=dtype)

        offset = 2
        for i in range(n):
            a = coeffs[:, offset + 0][:, None]  # [nt,1]
            b = coeffs[:, offset + 1][:, None]
            c = coeffs[:, offset + 2][:, None]
            d = coeffs[:, offset + 3][:, None]

            angle = 2 * torch.pi * (i + 1) * t  # [npts]
            cos_t = torch.cos(angle)[None, :]   # [1, npts]
            sin_t = torch.sin(angle)[None, :]

            x = x + a * cos_t + b * sin_t
            y = y + c * cos_t + d * sin_t

            offset += 4

    return x, y

def ffts_1_slow(coeffs_batch, npts):
    """
    循环调用 fft_1 的慢速批量版本
    coeffs_batch: [nt, 2 + 4*n] 
    返回:
        x: [nt, npts]
        y: [nt, npts]
    """
    nt = coeffs_batch.shape[0]
    x_list = []
    y_list = []
    for i in range(nt):
        x, y = fft_1(coeffs_batch[i], npts)
        x_list.append(x)
        y_list.append(y)
    x_arr = np.stack(x_list, axis=0)  # [nt, npts]
    y_arr = np.stack(y_list, axis=0)  # [nt, npts]
    return x_arr, y_arr




def ft_correct_clockwise(ft_code):
    # ft_code: [nt, 2 + nf*4]
    # 返回:
    #     ft_code_corr: [nt, 2 + nf*4] 纠正后的结果
    #     corrected: [nt] bool tensor 是否纠正
    nt, m = ft_code.shape
    nf = (m - 2) // 4

    # 提取 an, bn, cn, dn [nt, nf]
    an = ft_code[:, 2+0::4]
    bn = ft_code[:, 2+1::4]
    cn = ft_code[:, 2+2::4]
    dn = ft_code[:, 2+3::4]

    idx = torch.arange(1, nf+1, device=ft_code.device).float().view(1, -1)  # [1,nf]

    # 面积公式
    area = torch.pi * torch.sum(idx * (an * dn - bn * cn), dim=1)  # [nt]

    # 判断是否逆向链
    corrected = area < 0  # [nt] bool

    # 创建一个拷贝
    # ft_code_corr = ft_code.clone()

    # 把 bn, dn 取反
    ft_code[:, 2+1::4][corrected] *= -1
    ft_code[:, 2+3::4][corrected] *= -1

    return corrected


def _get_covariance_matrix_pts4A(boxes,method=1,ft=False): #boxes[nt,nf, 8(xyxyxyxy)] -> (sigma_xx, sigma_yy, sigma_xy)
    assert boxes.dim() == 3 and boxes.size(-1) == 8
    nt,nf = boxes.shape[:2]
    pts = boxes.view(nt, nf, 4, 2)  # [nt,nf,4,2]

    # 重心坐标 (几何中心)
    cxy = pts.mean(dim=-2)  # cxy[nt,nf,2]
    # cx, cy = cxy[..., 0], cxy[..., 1]

    # 平移到重心
    pts_centered = pts - cxy[:,:, None, :]  # pts_centered[nt,nf,4,2]

    if method==0: #advance
        # 1) 用 PCA 求主轴方向（对点顺序不敏感）
        #    仅用于方向；宽高用极值投影求，保证与实心矩形一致
        # with torch.cuda.amp.autocast(enabled=False):
        # with torch.amp.autocast(device, enabled=False):
        # 2x2 协方差（散度矩阵），对四点等权：S = (X^T X)/4
        S = torch.matmul(pts_centered.transpose(-2, -1), pts_centered).to(torch.float32) / 4.0  # [nt, nf, 2, 2]
        # 特征分解，取最大特征向量做 w 方向
        # eigh 返回升序特征值
        evals, evecs = torch.linalg.eigh(S)                     # evals[e0<=e1], evecs[..., :, i]
        v = evecs[..., :, 1]                                    # 最大特征向量，形状 [nt, nf, 2]
        # 规范化，避免数值误差
        v = v / (v.norm(dim=-1, keepdim=True) + 1e-12)          # v_x, v_y
        vx, vy = v[..., 0], v[..., 1]

        # 2) 在主轴 v 和其正交方向 v_perp 上投影四点，取极值差得到 w,h
        v_perp = torch.stack([-vy, vx], dim=-1)                      # [nt, nf, 2]
        proj_x = (pts_centered * v.unsqueeze(-2)).sum(dim=-1)            # [nt, nf, 4]
        proj_y = (pts_centered * v_perp.unsqueeze(-2)).sum(dim=-1)       # [nt, nf, 4]
        w = proj_x.max(dim=-1).values - proj_x.min(dim=-1).values    # [nt, nf]
        h = proj_y.max(dim=-1).values - proj_y.min(dim=-1).values    # [nt, nf]

        # 3) 面域协方差主轴分量（与 _get_covariance_matrix 完全一致）
        a = (w ** 2) / 12.0
        b = (h ** 2) / 12.0

        # 4) 由方向向量 v 直接得到 cos,sin（v 与 w 方向对齐）
        cos = vx
        sin = vy
        cos2 = cos * cos
        sin2 = sin * sin

        sigma_xx = a * cos2 + b * sin2
        sigma_yy = a * sin2 + b * cos2
        sigma_xy = (a - b) * cos * sin
    elif method==1:
        # PCA 求主轴方向
        cov = torch.matmul(pts_centered.transpose(-2,-1), pts_centered).to(torch.float32) / 4.0  # [nt,nf,2,2]
        # 协方差矩阵分量
        sigma_xx = cov[..., 0, 0]
        sigma_yy = cov[..., 1, 1]
        sigma_xy = cov[..., 0, 1]
    else:
        assert method==2
        # 计算协方差矩阵
        # 对于2D点集，协方差矩阵为 [[a, c], [c, b]]
        a = (pts_centered[..., 0].pow(2).mean(dim=-1))
        b = (pts_centered[..., 1].pow(2).mean(dim=-1))
        c = (pts_centered[..., 0] * pts_centered[..., 1]).mean(dim=-1)
        
        # 调整尺度以匹配原始实现中的高斯分布假设
        # 原始实现中，宽度和高度的方差是 w^2/12 和 h^2/12
        # 这里我们需要估计等效的宽度和高度
        # 使用最小外接矩形的近似
        x_min = pts[..., 0].min(dim=-1)[0]
        x_max = pts[..., 0].max(dim=-1)[0]
        y_min = pts[..., 1].min(dim=-1)[0]
        y_max = pts[..., 1].max(dim=-1)[0]
        
        width = x_max - x_min
        height = y_max - y_min
        
        # 估计旋转角度（使用主成分分析）
        # 计算特征向量
        eigenvalues, eigenvectors = torch.linalg.eigh(torch.stack([
            torch.stack([a, c], dim=-1),
            torch.stack([c, b], dim=-1)
        ], dim=-2))
        
        # 主方向的角度
        angle = torch.atan2(eigenvectors[..., 1, 0], eigenvectors[..., 0, 0])
        
        # 使用原始实现中的方法计算协方差参数
        a_cov = width.pow(2) / 12
        b_cov = height.pow(2) / 12
        
        if ft:
            cos = (1 / (1 + angle.pow(2))).sqrt()
            sin = angle * cos
        else:
            cos = angle.cos()
            sin = angle.sin()
        
        cos2 = cos.pow(2)
        sin2 = sin.pow(2)

        sigma_xx = a_cov * cos2 + b_cov * sin2 #sigma_xx[nt,nf]
        sigma_yy = a_cov * sin2 + b_cov * cos2 #sigma_yy[nt,nf]
        sigma_xy = (a_cov - b_cov) * cos * sin #sigma_xy[nt,nf]

    return sigma_xx, sigma_yy, sigma_xy, cxy #sigma_xx[nt,nf] sigma_yy[nt,nf] sigma_xy[nt,nf]  cxy[nt,nf,2]

def probiou_pts4(obb1, obb2, eps=1e-3, method=1): #obb1[nt,nf,8],obb2[nt,nf,8]
    an1, bn1, cn1, cxy1 = _get_covariance_matrix_pts4A(obb1,method) #an1[nt,nf] bn1[nt,nf] cn1[nt,nf]  cxy1[nt,nf,2]
    cx1, cy1 = cxy1[..., 0], cxy1[..., 1] #cx1[nt,nf] cy1[nt,nf]
    an2, bn2, cn2, cxy2 = _get_covariance_matrix_pts4A(obb2,method) #an2[nt,nf] bn2[nt,nf] cn2[nt,nf]  cxy2[nt,nf,2]
    cx2, cy2 = cxy2[..., 0], cxy2[..., 1] #cx2[nt,nf] cy2[nt,nf]

    det = (an1 + an2) * (bn1 + bn2) - (cn1 + cn2).pow(2) #det[nt,nf]
    assert torch.all(det != 0).item()

    t1 = (((an1 + an2) * (cy1 - cy2).pow(2) + (bn1 + bn2) * (cx1 - cx2).pow(2)) / (det + eps)) * 0.25 #t1[nt,nf]
    t2 = (((cn1 + cn2) * (cx2 - cx1) * (cy1 - cy2)) / (det + eps)) * 0.5 #t2[nt,nf]

    det1 = (an1 * bn1 - cn1.pow(2)) #det1[nt,nf]
    det2 = (an2 * bn2 - cn2.pow(2)) #det2[nt,nf]
    # assert torch.all(det1*det2 + eps >= 0.0).item()
    t3_arg = det / (4 * (det1.clamp_(0) * det2.clamp_(0) + 10*eps).sqrt()) #t3_arg[nt,nf]
    # assert torch.all(t3_arg+eps > 0).item()
    t3 = (t3_arg.clamp(min=eps, max=10.0)).log() * 0.5 #t3[nt,nf]

    bd = (t1 + t2 + t3).clamp(min=eps, max=100.0)  #bd[nt,nf]避免过大或负数
    assert torch.all((1.0 - (-bd).exp() + eps) >= 0.0).item()
    hd = (1.0 - (-bd).exp() + eps).sqrt() #bd[nt,nf]
    iou = 1 - hd #iou[nt,nf]

    return iou #iou[nt,nf]

def solve_cos_sin_closed_form(coef0: torch.Tensor, coef: torch.Tensor, eps: float = 1e-8, normalize: bool = True):
    # Analytic least-squares solution for cos/sin for each sample (no torch.linalg.solve).
    # Inputs:
    #     coef0: [nt, 4]  -- (an0, bn0, cn0, dn0)
    #     coef:  [nt, 4]  -- (an,  bn,  cn,  dn)
    #     eps:   float    -- small regularizer added to denominator S to avoid div0
    #     normalize: bool -- if True, force (cos,sin) to unit length (optional)
    # Returns:
    #     cos_sin: [nt, 2] tensor, columns [cos, sin]
    assert coef0.ndim == 2 and coef0.shape[1] == 4
    assert coef.ndim == 2 and coef.shape[1] == 4
    an0, bn0, cn0, dn0 = coef0.unbind(dim=1)  # each [nt]
    an,  bn,  cn,  dn  = coef.unbind(dim=1)

    if normalize:
        # --- 新增：norm 对齐 ---
        norm_ab0 = torch.sqrt(an0**2 + bn0**2 + eps)
        norm_ab  = torch.sqrt(an**2  + bn**2  + eps)
        # scale (an,bn) 使其和 (an0,bn0) 具有相同模长
        scale_ab = norm_ab0 / norm_ab
        an = an * scale_ab
        bn = bn * scale_ab

        norm_cd0 = torch.sqrt(cn0**2 + dn0**2 + eps)
        norm_cd  = torch.sqrt(cn**2  + dn**2  + eps)
        # scale (cn,dn) 使其和 (cn0,dn0) 具有相同模长
        scale_cd = norm_cd0 / norm_cd
        cn = cn * scale_cd
        dn = dn * scale_cd
        # --- norm 对齐结束 ---

    if 1:
        # S = an0^2 + bn0^2 + cn0^2 + dn0^2  [nt]
        S = an0 * an0 + bn0 * bn0 + cn0 * cn0 + dn0 * dn0
        S = S + eps  # regularize

        # Atb components:
        Atb0 = an0 * an + bn0 * bn + cn0 * cn + dn0 * dn
        Atb1 = bn0 * an - an0 * bn + dn0 * cn - cn0 * dn

        cos = Atb0 / S
        sin = Atb1 / S

        cos_sin = torch.stack([cos, sin], dim=1)  # [nt,2]
    else:
        S = an0 * an0 + bn0 * bn0
        # Atb components:
        Atb0 = an0 * an + bn0 * bn
        Atb1 = bn0 * an - an0 * bn
        S = S + eps  # regularize
        cos_ab = Atb0 / S
        sin_ab = Atb1 / S
        #
        S = cn0 * cn0 + dn0 * dn0
        # Atb components:
        Atb0 = cn0 * cn + dn0 * dn
        Atb1 = dn0 * cn - cn0 * dn
        S = S + eps  # regularize
        cos_cd = Atb0 / S
        sin_cd = Atb1 / S
        #
        cos = (cos_ab+cos_cd)*0.5
        sin = (sin_ab+sin_cd)*0.5
        cos_sin = torch.stack([cos, sin], dim=1)  # [nt,2]
    
    if normalize:
        norm = torch.norm(cos_sin, dim=1, keepdim=True).clamp_min(eps)
        cos_sin = cos_sin / norm

    return cos_sin #cos_sin[nt]
def solve_cos_sin_closed_form2(coef0: torch.Tensor, coef: torch.Tensor,
                              eps: float = 1e-4, normalize: bool = True):
    # Vectorized analytic estimator of (cos t, sin t) from multi-harmonic coef pairs.
    # Args:
    #     coef0: [nt, nf*4] baseline coefficients (a0,b0,c0,d0, ...)
    #     coef:  [nt, nf*4] target   coefficients (a,b,c,d, ...)
    #     eps:   small regularizer to avoid div0
    #     normalize: if True, do per-harmonic norm alignment (scale ab/cd to match baseline)
    #                AND project final r to unit circle and normalize output (keeps old behavior)
    # Returns:
    #     cos_sin: [nt, 2], estimated (cos, sin)
    # checks
    assert coef0.ndim == 2 and coef.ndim == 2
    assert coef0.shape == coef.shape, "coef0 and coef must have same shape"
    nt, four_nf = coef0.shape
    assert four_nf % 4 == 0, "second dim must be multiple of 4"
    nf = four_nf // 4
    device = coef0.device
    dtype = coef0.dtype

    # reshape to [nt, nf, 4]
    coef0 = coef0.view(nt, nf, 4)
    coef  = coef.view(nt, nf, 4)

    a0 = coef0[..., 0]
    b0 = coef0[..., 1]
    c0 = coef0[..., 2]
    d0 = coef0[..., 3]

    a = coef[..., 0]
    b = coef[..., 1]
    c = coef[..., 2]
    d = coef[..., 3]

    # --- per-harmonic norm alignment (scale ab and cd to match baseline) ---
    if normalize:
        # use +eps inside sqrt to avoid zero
        norm_ab0 = torch.sqrt(a0 * a0 + b0 * b0)  # [nt, nf]
        norm_ab  = torch.sqrt(a  * a  + b  * b)
        scale_ab = norm_ab0 / (norm_ab + eps)
        a = a * scale_ab
        b = b * scale_ab

        norm_cd0 = torch.sqrt(c0 * c0 + d0 * d0)
        norm_cd  = torch.sqrt(c  * c  + d  * d)
        scale_cd = norm_cd0 / (norm_cd + eps)
        c = c * scale_cd
        d = d * scale_cd
    # --- end norm alignment ---

    # Cast real parts to float32 before building complex to avoid ComplexHalf issues.
    # Keep device placement.
    real_dtype = torch.float32
    a0f = a0.to(real_dtype)
    b0f = b0.to(real_dtype)
    c0f = c0.to(real_dtype)
    d0f = d0.to(real_dtype)

    af = a.to(real_dtype)
    bf = b.to(real_dtype)
    cf = c.to(real_dtype)
    df = d.to(real_dtype)

    # Build complex tensors (complex64) safely
    u1 = torch.complex(a0f, b0f)   # [nt, nf] complex64
    v1 = torch.complex(af, bf)

    u2 = torch.complex(c0f, d0f)
    v2 = torch.complex(cf, df)

    # numerator and denominator for per-harmonic x_k = estimate of r^k
    # den uses baseline magnitudes (a0,b0,c0,d0) as intended
    den = (a0f * a0f + b0f * b0f) + (c0f * c0f + d0f * d0f)  # [nt, nf], real
    den = den + eps

    num = torch.conj(u1) * v1 + torch.conj(u2) * v2               # [nt, nf] complex
    x = num / den  # x[nt, nf] complex, per-harmonic estimate of r^k

    # estimate r from sequence x_k using linear LS r * x_k ~ x_{k+1}
    if nf == 1:
        r = x[:, 0]  # [nt] complex
    else:
        xk  = x[:, :-1]   # [nt, nf-1]
        xk1 = x[:, 1:]    # [nt, nf-1]
        wk  = den[:, :-1] # [nt, nf-1]  (use baseline energy as weight)

        # numerator and denominator (weighted)
        num_r = torch.sum(wk * torch.conj(xk) * xk1, dim=1)                           # [nt] complex
        den_r = torch.sum(wk * (xk.real * xk.real + xk.imag * xk.imag), dim=1) + eps   # [nt] real

        r = num_r / den_r  # r[nt] complex

    # optionally project to unit circle (force pure phase)
    if normalize:
        r = r / (torch.abs(r) + eps) # r[nt] complex

    cos = r.real.to(dtype)
    sin = r.imag.to(dtype)
    cos_sin = torch.stack([cos, sin], dim=1)  # [nt, 2]

    # final guard-normalize (keep compatibility with your previous code)
    if 1:
        norm = torch.norm(cos_sin, dim=1, keepdim=True).clamp_min(eps)
        cos_sin = cos_sin / norm

    return cos_sin #cos_sin[nt,2]

def rotate_high_orders(abcd1, coefs: torch.Tensor, cos_sin: torch.Tensor):
    # Rotate higher-order Fourier coefficients by given cos,sin.
    # Args:
    #     abcd1:   [nt, 4]
    #     coefs:   [nt, 2+nf*4]  higher-order coefficients stacked as (an,bn,cn,dn) per order
    #              (e.g., from target_ft_det[mask_nt, ft_offset:], so nf = (#orders-1))
    #     cos_sin: [nt,nf, 2]    (cos, sin) for each sample
    # Returns:
    #     rolled: [nt, nf*4]  rolled higher-order coefficients
    offset_cs = 1 if abcd1 is not None else 0
    cos, sin = cos_sin[:,offset_cs:, 0], cos_sin[:,offset_cs:, 1]  # cos[nt,nf] sin[nt,nf]
    offset = 6 if abcd1 is not None else 2
    coefs4 = coefs[:,offset:] #coefs[nt, 2+nf*4]->coefs4[nt, (nf-1)*4]
    nt, nf4 = coefs4.shape
    assert nf4 % 4 == 0
    nf = nf4 // 4

    # reshape to [nt, nf, 4]
    coef_split = coefs4.view(nt, nf, 4) #coef_split[nt, nf-1,4]
    an0, bn0, cn0, dn0 = coef_split.unbind(-1)  # each [nt, nf-1]

    # apply rotation
    an = an0 * cos + bn0 * sin  # an[nt, nf-1]
    bn = -an0 * sin + bn0 * cos # bn[nt, nf-1]
    cn = cn0 * cos + dn0 * sin  # cn[nt, nf-1]
    dn = -cn0 * sin + dn0 * cos # dn[nt, nf-1]

    rolled4f = torch.stack([an, bn, cn, dn], dim=-1).reshape(nt, nf4) #[nt, (nf-1)*4]
    if abcd1 is not None:
        rolled = torch.cat([coefs[:,:2], abcd1, rolled4f], dim=-1)#rolled
    else:
        rolled = torch.cat([coefs[:,:2], rolled4f], dim=-1)#rolled
    assert rolled.shape[-1]==coefs.shape[-1]
    return rolled #[nt, 2+nf*4]





def ft2dir(coefs,cen=0):
    # a1, b1, c1, d1 = an[1], bn[1], cn[1], dn[1] # nt,1
    abcd = coefs[:, 2:6] #abcd[nt,4]
    a1, b1, c1, d1 = torch.split(abcd, 1, dim=-1) #[nt,1]

    # if 1:
    if cen==0:
        a1,b1,c1,d1 = a1.float(),b1.float(),c1.float(),d1.float()
        cos_sin2t = torch.stack([a1**2 + c1**2 - b1**2 - d1**2, 2*(a1*b1 + c1*d1)],dim=1).squeeze(2)#[nt,2]
        cos_sin2t = F.normalize(cos_sin2t,p=2,dim=-1)#[nt,2]   

        cos_t = torch.sqrt((1+cos_sin2t[:,0])/2)#[nt]
        sin_t = torch.sqrt((1-cos_sin2t[:,0])/2)#[nt]
        sin_t[cos_sin2t[:,1]<0] *= -1

        cos_sin = torch.stack([cos_t,sin_t],dim=1)#[nt,2]
    elif cen==1:
        tan2t = (2*(a1*b1 + c1*d1))/(a1**2 + c1**2 - b1**2 - d1**2) # x, y   2t~[-0.5pi, 0.5pi], t~[-0.25pi, 0.25pi]  
        # sin(A/2) = √{(1–cosA)/2}
        # cos(A/2) = √{(1+cosA)/2}
        cos2t = torch.sqrt(1 / (1 + tan2t**2)).view(-1,1)
        cos_sin = cos2t @ torch.tensor([[0.5, -0.5]], dtype=abcd.dtype, device=coefs.device) + 0.5    # nt,1 @ 1,2 -> [nt, 2]
        cos_sin = torch.sqrt(cos_sin)
        index = torch.where(tan2t < 0)[0]
        cos_sin[index, 1] *= -1 #cos_sin[nt,2]
    else: #cen==2
        # 直接构造 2θ 的正余弦分量
        x = a1**2 + c1**2 - b1**2 - d1**2  # [nt,1]  cos(2θ) 的未归一化分量
        y = 2*(a1*b1 + c1*d1)              # [nt,1]  sin(2θ) 的未归一化分量

        # 用 atan2 得到 2θ，再除以 2；避免 sqrt 半角的尖点
        phi2 = torch.atan2(y + 0.0, x + 0.0)  ##phi2[nt,1]   2θ，(0,0) -> 0
        phi  = 0.5 * phi2 #phi2[nt,1]->phi[nt,1]

        cos_t = torch.cos(phi) #cos_t[nt,1]
        sin_t = torch.sin(phi) #sin_t[nt,1]
        cos_sin = torch.cat([cos_t,sin_t],dim=1)#cos_t[nt,1]+sin_t[nt,1]->cos_sin[nt,2]

    return cos_sin #cos_sin[nt,2]

def ft2dir_k(coefs):#coefs[nt, 2+nf*4]
    assert (coefs.shape[1]-2) % 4 == 0
    nt,nf = coefs.shape[0],(coefs.shape[1]-2)//4
    abcd = coefs[:, 2:].view(nt,nf,4) #abcd[nt,nf*4]->abcd[nt,nf,4]
    an, bn, cn, dn = abcd[..., 0], abcd[..., 1], abcd[..., 2], abcd[..., 3] #an[nt,nf] bn[nt,nf] cn[nt,nf] dn[nt,nf]
    # a1,b1,c1,d1 = a1.float(),b1.float(),c1.float(),d1.float()
    if 1:
        # 直接构造 2θ 的正余弦分量
        x = an**2 + cn**2 - bn**2 - dn**2   # cos(2θ) 的未归一化分量
        y = 2*(an*bn + cn*dn)               # sin(2θ) 的未归一化分量

        # 用 atan2 得到 2θ，再除以 2；避免 sqrt 半角的尖点
        phi2 = torch.atan2(y + 0.0, x + 0.0)      # 2θ，(0,0) -> 0
        phi  = 0.5 * phi2

        cos_t = torch.cos(phi)
        sin_t = torch.sin(phi)
    else:
        cos_sin2t = torch.stack([an**2 + cn**2 - bn**2 - dn**2, 2*(an*bn + cn*dn)],dim=2)#[nt,nf] -> cos_sin2t[nt,nf,2]
        cos_sin2t = F.normalize(cos_sin2t,p=2,dim=-1)#cos_sin2t[nt,nf,2]

        cos_t = torch.sqrt((1+cos_sin2t[...,0])/2)        #cos_t[nt,nf]
        sin_t = torch.sqrt((1-cos_sin2t[...,0])/2).clone()#sin_t[nt,nf]
        sin_t[cos_sin2t[...,1]<0] *= -1

    cos_sin = torch.stack([cos_t,sin_t],dim=2)#cos_sin[nt,nf,2]

    return cos_sin #cos_sin[nt,nf,2]

def angle_multiple(cs: torch.Tensor, m: int):
    # Args:
    #     cs: [nt,2],  cs[:,0]=cosθ, cs[:,1]=sinθ
    #     m:  倍数
    # Returns:
    #     [nt,m,2],  cos_sin[:,k,0]=cos((k+1)θ), cos_sin[:,k,1]=sin((k+1)θ)
    c, s = cs[:, 0], cs[:, 1]      # [nt]

    cos_k = c.clone()              # cos(θ)
    sin_k = s.clone()              # sin(θ)

    outs = [torch.stack([cos_k, sin_k], dim=-1)]  # [nt,2]

    for _ in range(1, m):
        new_cos = cos_k * c - sin_k * s
        new_sin = sin_k * c + cos_k * s
        outs.append(torch.stack([new_cos, new_sin], dim=-1))
        cos_k, sin_k = new_cos, new_sin           # 注意这里是新变量，不会覆盖梯度图里的旧值

    return torch.stack(outs, dim=1)  # [nt,m,2]
 
def ft2pts(coefs,cen=0): #coefs[nt, 2+4*coef]
    cos_sin = ft2dir(coefs,cen)#[nt,2]
    abcd = coefs[:, 2:6] #abcd[nt,4]
    
    xc, yc = torch.split(coefs[:, :2].clone(), 1, dim=-1)
    an1, bn1, cn1, dn1 = torch.split(abcd, 1, dim=-1)
    m_sin = cos_sin[:, 1:2]
    m_cos = cos_sin[:, 0:1]
    scale=1.0
    a1 = scale*(an1 * m_cos + bn1 * m_sin)
    b1 = scale*(-an1 * m_sin + bn1 * m_cos)
    c1 = scale*(cn1 * m_cos + dn1 * m_sin)
    d1 = scale*(-cn1 * m_sin + dn1 * m_cos)   
    P0=torch.cat([xc-a1-b1,yc-c1-d1], dim=-1).view(-1, 2)
    P1=torch.cat([xc-a1+b1,yc-c1+d1], dim=-1).view(-1, 2)
    P2=torch.cat([xc+a1+b1,yc+c1+d1], dim=-1).view(-1, 2)
    P3=torch.cat([xc+a1-b1,yc+c1-d1], dim=-1).view(-1, 2)
    points = torch.cat([P0, P1, P2, P3], dim=1)
    return points
def ft_rot_normlize(coefs,cen=0): #coefs[nt, 2+nf*4]->coefs[nt, 2+nf*4]
    cos_sin1 = ft2dir(coefs,cen)#cos_sin[nt,2]
    assert ((coefs.shape[-1]-2) % 4)==0
    nf = (coefs.shape[-1]-2)//4
    cos_sin = angle_multiple(cos_sin1, nf) #cos_sin1[nt,2]->cos_sin[nt,nf,2]

    nt = coefs.shape[0]
    abcd = coefs[:, 2:].view(nt,nf,4) #abcd[nt,4*nf]->abcd[nt,nf,4(abcd)]
    
    an0, bn0, cn0, dn0 = abcd[..., 0], abcd[..., 1], abcd[..., 2], abcd[..., 3] #an0[nt,nf],bn0[nt,nf],cn0[nt,nf],dn0[nt,nf]
    m_cos = cos_sin[..., 0] #m_cos[nt,nf]
    m_sin = cos_sin[..., 1] #m_sin[nt,nf]
    an =  an0 * m_cos + bn0 * m_sin #[nt,nf]
    bn = -an0 * m_sin + bn0 * m_cos #[nt,nf]
    cn =  cn0 * m_cos + dn0 * m_sin #[nt,nf]
    dn = -cn0 * m_sin + dn0 * m_cos #[nt,nf]
    coefs_ft = torch.stack([an,bn,cn,dn],dim=-1).view(nt,nf*4) #coefs_ft[nt,nf,4]->coefs_ft[nt,nf*4]
    return torch.cat([coefs[:,:2],coefs_ft],dim=-1),cos_sin #[nt,2+nf*4]

def ft2pts_k(coefs,use_center=True): #coefs[nt, 2+nf*4]->points[nt,nf,8]
    # cos_sin1 = ft2dir(coefs)#cos_sin[nt,2]
    # assert ((coefs.shape[-1]-2) % 4)==0
    nf = (coefs.shape[-1]-2)//4
    # cos_sin = angle_multiple(cos_sin1, nf) #cos_sin1[nt,2]->cos_sin[nt,nf,2]
    coefs2, cos_sin = ft_rot_normlize(coefs,0) #coefs[nt,2+nf*4] -> coefs2[nt,2+nf*4],cos_sin[nt,nf,2]

    nt = coefs2.shape[0]
    abcd = coefs2[:, 2:].view(nt,nf,4) #abcd[nt,nf*4]->abcd[nt,nf,4(abcd)]
    
    if 1:
        an, bn, cn, dn = abcd[..., 0], abcd[..., 1], abcd[..., 2], abcd[..., 3] #an[nt,nf],bn[nt,nf],cn[nt,nf],dn[nt,nf]
        # an, bn, cn, dn = abcd.unbind(dim=-1) #abcd[nt,nf,4(abcd)]->an[nt,nf],bn[nt,nf],cn[nt,nf],dn[nt,nf]
    else:
        an0, bn0, cn0, dn0 = abcd[..., 0], abcd[..., 1], abcd[..., 2], abcd[..., 3] #an0[nt,nf],bn0[nt,nf],cn0[nt,nf],dn0[nt,nf]
        m_cos = cos_sin[..., 0] #m_cos[nt,nf]
        m_sin = cos_sin[..., 1] #m_sin[nt,nf]
        an =  an0 * m_cos + bn0 * m_sin #[nt,nf]
        bn = -an0 * m_sin + bn0 * m_cos #[nt,nf]
        cn =  cn0 * m_cos + dn0 * m_sin #[nt,nf]
        dn = -cn0 * m_sin + dn0 * m_cos #[nt,nf]
    #
    P0=torch.stack([-an-bn,-cn-dn], dim=-1) #P0[nt,nf,2]
    P1=torch.stack([-an+bn,-cn+dn], dim=-1) #P1[nt,nf,2]
    P2=torch.stack([+an+bn,+cn+dn], dim=-1) #P2[nt,nf,2]
    P3=torch.stack([+an-bn,+cn-dn], dim=-1) #P3[nt,nf,2]
    if use_center:
        xc, yc = torch.split(coefs2[:, :2], 1, dim=-1) #coefs2[nt, 2] -> xc[nt,1],yc[nt,1]
        center = torch.stack([xc,yc],dim=-1) #center[nt,1,2]
        P0[:,0:1,:] += center #P0[nt,nf,2]
        P1[:,0:1,:] += center #P1[nt,nf,2]
        P2[:,0:1,:] += center #P2[nt,nf,2]
        P3[:,0:1,:] += center #P3[nt,nf,2]
    points = torch.cat([P0, P1, P2, P3], dim=-1) #P0[nt,nf,8]
    if 0:
        v = P1 - P0  # v[nt,nf,2]
        norm = torch.norm(v, dim=2, keepdim=True)   # [nt, nf, 1]
        v_unit = v / (norm + 1e-8)                  # v_unit[nt, nf, 2]
    return points,cos_sin,coefs2 #points[nt,nf,8] cos_sin[nt,nf,2]
