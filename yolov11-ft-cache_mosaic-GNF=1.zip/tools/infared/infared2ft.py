import os
import cv2
import numpy as np
from tqdm import tqdm

# ==== 傅里叶函数与缩放 ====
def compute_coefficients_interp(xy, terms=12, interp=True, return_list=False):
    x = np.array(xy[0::2])
    y = np.array(xy[1::2])
    if interp:
        x = np.concatenate([x, [x[0]]], dtype=np.float32)
        y = np.concatenate([y, [y[0]]], dtype=np.float32)
        ori = np.linspace(0, 1, x.shape[0], endpoint=True)
        gap = np.linspace(0, 1, terms * 2, endpoint=False)
        x = np.interp(gap, ori, x)
        y = np.interp(gap, ori, y)
    N = len(x)
    t = np.linspace(0, 2 * np.pi, N, endpoint=False)
    a0 = 1. / N * np.sum(x)
    c0 = 1. / N * np.sum(y)
    an, bn, cn, dn = [np.zeros(terms + 1) for _ in range(4)]
    for k in range(1, (N // 2) + 1):
        if k > terms:
            break
        an[k] = 2. / N * np.sum(x * np.cos(k * t))
        bn[k] = 2. / N * np.sum(x * np.sin(k * t))
        cn[k] = 2. / N * np.sum(y * np.cos(k * t))
        dn[k] = 2. / N * np.sum(y * np.sin(k * t))
    if return_list:
        list_coef = [a0, c0]
        for k in range(1, terms + 1):
            list_coef.extend([an[k], bn[k], cn[k], dn[k]])
        return list_coef
    an[0] = a0
    cn[0] = c0
    return (an, bn, cn, dn)

def ft_scale(ft, scale):
    assert ((len(ft)-2) % 4) == 0
    scalex, scaley = scale
    ft[0] *= scalex
    ft[1] *= scaley
    ft[2::4] *= scalex
    ft[3::4] *= scalex
    ft[4::4] *= scaley
    ft[5::4] *= scaley

# ==== 单个图像标签处理 ====
def process_single_label(label_path, image_path, delta_thresh=0, ft_terms=12, use_hull=True):
    pol_lines = []
    ft_lines = []

    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"读取失败: {image_path}")
        return [], []

    height, width = img.shape[:2]

    with open(label_path, 'r') as f:
        lines = f.readlines()

    for line in lines:
        parts = line.strip().split()
        # if len(parts) != 5:
        #     continue
        cls, x, y, w, h = map(float, parts)
        cx = x * width
        cy = y * height
        bw = w * width
        bh = h * height

        # 裁剪 ROI
        x1 = max(cx - bw / 2, 0)
        y1 = max(cy - bh / 2, 0)
        x2 = min(cx + bw / 2, width - 1)
        y2 = min(cy + bh / 2, height - 1)
        roi = img[round(y1):round(y2+1), round(x1):round(x2+1)]

        # if roi.size == 0:
        #     continue

        if 1:
            otsu_thresh, _ = cv2.threshold(roi, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            # 自定义阈值（提升10灰度等级）
            adjusted_thresh = np.clip(otsu_thresh + delta_thresh, 0, 255)
            _, binary = cv2.threshold(roi, adjusted_thresh, 255, cv2.THRESH_BINARY)
        else:
            _, binary = cv2.threshold(roi, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        assert(contours and len(contours)>0)

        contour = max(contours, key=cv2.contourArea)
        # if len(contour) < 3:
        #     continue

        poly = contour.reshape(-1, 2).astype(np.float32)
        poly[:, 0] += x1
        poly[:, 1] += y1

        if use_hull:
            poly = cv2.convexHull(poly).reshape(-1, 2)

        poly_flat = poly.flatten().tolist()
        # 归一化为相对坐标
        normalized_poly = [
            coord / width if i % 2 == 0 else coord / height
            for i, coord in enumerate(poly_flat)
        ]
        pol_line = f"{int(cls)} " + " ".join([f"{p:.6f}" for p in normalized_poly])
        pol_lines.append(pol_line)

        ft = compute_coefficients_interp(poly_flat, terms=ft_terms, return_list=True)
        ft = np.array(ft, dtype=np.float32)
        ft_scale(ft, (1.0 / width, 1.0 / height))

        ft_line = f"{int(cls)} " + " ".join([f"{v:.6f}" for v in ft.tolist()])
        ft_lines.append(ft_line)

    assert len(pol_lines)==len(lines) and len(ft_lines)==len(lines)
    return pol_lines, ft_lines

# ==== 遍历文件夹入口 ====
def process_dataset(image_dir, label_dir, output_dir, delta_thresh=0, ft_terms=12, use_hull=True):
    if output_dir!='':
        if not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
    else:
        output_dir = label_dir
    
    image_jpg_dir = os.path.join(os.path.dirname(image_dir), "images")  # 新的 jpg 输出路径
    os.makedirs(image_jpg_dir, exist_ok=True)

    label_files = [f for f in os.listdir(label_dir) if f.endswith('.txt')]
    
    for label_name in tqdm(label_files, desc="Processing labels"):
        if not label_name.endswith('.txt'):
            continue

        # if(label_name!='177.txt'):
        #     continue

        base = os.path.splitext(label_name)[0]
        label_path = os.path.join(label_dir, label_name)
        image_path = os.path.join(image_dir, base + '.bmp')
        image_jpg_path = os.path.join(image_jpg_dir, base + '.jpg')

        # if not os.path.exists(image_path):
        #     print(f"图像缺失: {image_path}")
        #     continue
        # ✅ 保存高质量 jpg 图像
        img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
        if img is None:
            print(f"读取失败: {image_path}")
            continue
        
        # 保存 jpg，参数95 表示较高画质（最大是100）
        cv2.imwrite(image_jpg_path, img, [cv2.IMWRITE_JPEG_QUALITY, 95])

        pol_lines, ft_lines = process_single_label(
            label_path, image_path, delta_thresh=delta_thresh, ft_terms=ft_terms, use_hull=use_hull
        )

        if not pol_lines:
            continue

        output_pol_path = os.path.join(output_dir, f"{base}.pol")
        output_ft_path = os.path.join(output_dir, f"{base}.ft")

        with open(output_pol_path, 'w') as pol_file:
            for p_line in pol_lines:
                pol_file.write(p_line + '\n')

        with open(output_ft_path, 'w') as ft_file:
            for f_line in ft_lines:
                ft_file.write(f_line + '\n')

        # print(f"✅ 生成: {base}.pol / {base}.ft")

    print("🎉 全部完成！每个图像已分别生成 pol 和 ft 文件。")

# ==== 实际调用 ====
if __name__ == '__main__':
    data_path = r'K:\datas\infared-pol'
    image_dir = os.path.join(data_path, 'images-bmp')
    label_dir = os.path.join(data_path, 'labels')
    output_pol = '' #os.path.join(data_path, 'output.pol')
    # output_ft = os.path.join(data_path, 'output.ft')
    ft_terms = 12
    use_hull = True
    delta_thresh = -10

    process_dataset(image_dir, label_dir, output_pol, delta_thresh, ft_terms, use_hull)
