import torch
import math

def fourier_curve(coeffs, t):
    """
    coeffs: (a0, c0, a1,b1,c1,d1, ..., an,bn,cn,dn)
    t: [T]  0..2π
    return: x[t], y[t]
    """
    # 解析系数
    a0, c0, rest = coeffs[0], coeffs[1], coeffs[2:]
    K = rest.numel() // 4
    a = rest[0::4]  # a1,a2,...
    b = rest[1::4]  # b1,b2,...
    c = rest[2::4]  # c1,c2,...
    d = rest[3::4]  # d1,d2,...

    t = t[..., None]                     # [T,1]
    k = torch.arange(1, K+1, device=t.device, dtype=t.dtype)[None, :]  # [1,K]
    kt = k * t                           # [T,K]
    coskt, sinkt = torch.cos(kt), torch.sin(kt)

    x = a0 + (coskt @ a) + (sinkt @ b)   # [T]
    y = c0 + (coskt @ c) + (sinkt @ d)   # [T]
    return x, y

def sample_polygon(coeffs, T=1024):
    t = torch.linspace(0, 2*math.pi, T+1, dtype=coeffs.dtype, device=coeffs.device)[:-1]
    x, y = fourier_curve(coeffs, t)
    V = torch.stack([x, y], dim=-1)  # [T,2]
    return V

def soft_winding_inside(P, V, eps=1e-6, alpha=40.0):
    """
    P: [H,W,2] 网格点坐标
    V: [T,2] 多边形顶点（闭合，函数内部会 roll 一下）
    返回: [H,W] 的软内部值 in [0,1]
    """
    V2 = torch.roll(V, shifts=-1, dims=0)
    E  = V2 - V               # [T,2]
    # r_i = p - v_i
    # 为了批量：把 [H,W,2] 和 [T,2] 做广播
    R = P[..., None, :] - V[None, None, :, :]   # [H,W,T,2]
    E = E[None, None, :, :]                     # [1,1,T,2]

    cross = E[..., 0]*R[..., 1] - E[..., 1]*R[..., 0]     # [H,W,T]
    dot   = E[..., 0]*R[..., 0] + E[..., 1]*R[..., 1]     # [H,W,T]
    ang   = torch.atan2(cross, dot + eps)                 # [H,W,T]
    w     = ang.sum(dim=-1) / (2*math.pi)                 # [H,W]
    s     = torch.sigmoid(alpha*(w - 0.5))                # [H,W]
    
    return s.clamp(0, 1)

def iou_fourier(coeffs1, coeffs2, grid_res=64, margin=0.1, T=128, alpha=40.0):
    ### grid_res=512, T=1024, out of memory
    ### grid_res=256, T=512, out of memory
    ### grid_res=128, T=256, out of memory
    """
    返回可微 IoU 近似
    """
    # 采样多边形
    V1 = sample_polygon(coeffs1, T=T)  # [T,2]
    V2 = sample_polygon(coeffs2, T=T)

    # 自适应边界框（两曲线合并后再留 margin）
    allV = torch.cat([V1, V2], dim=0)
    xy_min = allV.amin(dim=0)
    xy_max = allV.amax(dim=0)
    size = (xy_max - xy_min)
    xy_min = xy_min - margin*size
    xy_max = xy_max + margin*size

    H = W = grid_res
    ys = torch.linspace(xy_min[1].item(), xy_max[1].item(), H, dtype=allV.dtype, device=allV.device)
    xs = torch.linspace(xy_min[0].item(), xy_max[0].item(), W, dtype=allV.dtype, device=allV.device)
    X, Y = torch.meshgrid(xs, ys, indexing='xy')   # [W,H]
    P = torch.stack([X, Y], dim=-1)                # [W,H,2] 与上面 inside 的 [H,W,2] 一致也可

    # 软掩码
    S1 = soft_winding_inside(P, V1, alpha=alpha)   # [W,H]
    S2 = soft_winding_inside(P, V2, alpha=alpha)

    inter = (S1*S2).sum()
    union = (S1 + S2 - S1*S2).sum() + 1e-8
    return inter / union
