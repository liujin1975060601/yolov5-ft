import os
import shutil
import cv2
import numpy as np
import random
from tqdm import tqdm

import torch
torch.manual_seed(88)
import random
random.seed(88)
import numpy as np
np.random.seed(88)

# 全局变量
scale = 1.0 #scale>1时放大，app scale = master_obj_scale / app_obj_size, master scale=1.0
PATCH_SIZE = (896, 896)  # [宽, 高]
MAX_OBJ_SELECT = 10
MAX_NEG_SELECT = 10
MIN_DISTANCE_TO_EDGE = -30000

def get_affine_transform(center, s, angle, dst_offset):
    angle_rad = np.deg2rad(angle)
    cos_rad = np.cos(angle_rad)
    sin_rad = np.sin(angle_rad)
    cx,cy = center
    dx,dy = dst_offset
    transform_matrix = np.array([
        [ s*cos_rad, s*sin_rad, dx - s*( cos_rad*cx+sin_rad*cy)],
        [-s*sin_rad, s*cos_rad, dy - s*(-sin_rad*cx+cos_rad*cy)]
    ])
    return transform_matrix

def read_image_label(image_path):
    image = cv2.imread(image_path)
    if image is None:
        return None, None

    base_name, _ = os.path.splitext(os.path.basename(image_path))
    base_dir = os.path.dirname(image_path)
    pol_path = os.path.join(base_dir.replace('images', 'labels'), f"{base_name}.pol")

    if not os.path.exists(pol_path):
        return image, None

    with open(pol_path, "r") as f:
        # 每行 9 个数据：cls + 8 个点坐标
        pol_data = [list(map(float, line.strip().split())) 
                    for line in f.readlines() if len(line.strip().split()) >= 7]

    return image, pol_data

def save_patch(image, pol_data, patch_name, output_path):
    image_name = f"{output_path}/images/{patch_name}.jpg"
    pol_name = f"{output_path}/labels/{patch_name}.pol"

    cv2.imwrite(image_name, image)

    if pol_data:
        with open(pol_name, "w") as f:
            for line in pol_data:
                f.write(" ".join(map(str, line)) + "\n")


def generate_patches(data_path, diz, diz_angle, diz_scale, min_dist_to_edge, max_obj_select, max_neg_select,output_folder='patches-py',max_generated=0):
    image_dir = os.path.join(data_path, 'images')
    image_files = [os.path.join(image_dir, f) for f in os.listdir(image_dir) if f.lower().endswith(('.tif', '.tiff', '.jpg', '.jpeg', '.png', '.bmp'))]

    output_path = os.path.join(data_path, output_folder)
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    # 拷贝 names.txt 文件到新数据集路径
    names_file = os.path.join(data_path, 'names.txt')
    if os.path.exists(names_file):
        shutil.copy(names_file, output_path)
    else:
        print(f"Warning: {names_file} does not exist.")

    if not os.path.exists(os.path.join(output_path, 'images')):
        os.makedirs(os.path.join(output_path, 'images'))
    if not os.path.exists(os.path.join(output_path, 'labels')):
        os.makedirs(os.path.join(output_path, 'labels'))

    total_img = 0
    for image_path in tqdm(image_files, total=len(image_files)):
        image, pol_data = read_image_label(image_path)
        if image is None or pol_data is None:
            print(f"Failed to read {image_path}")
            continue

        height, width = image.shape[:2]
        select_times = [0] * len(pol_data)

        filename_with_extension = os.path.basename(image_path)
        filename, _ = os.path.splitext(filename_with_extension)

        #gen positive samples
        patch_index = 0
        while True:
            subset = [i for i, t in enumerate(select_times) if t < max_obj_select]
            if not subset:
                break

            idx = random.choice(subset)
            cls = pol_data[idx][0]
            pts = np.array(pol_data[idx][1:]).reshape(-1, 2) * [width, height]
            x_center, y_center = pts[:,0].mean(), pts[:,1].mean()
            dx, dy = random.randint(-diz, diz), random.randint(-diz, diz)
            #angle = random.choice([-180, -90, 0, 90])
            angle = random.uniform(-diz_angle,diz_angle)

            #matrix = cv2.getRotationMatrix2D((x_center + dx, y_center + dy), angle, 1.0)
            matrix = get_affine_transform((x_center + dx, y_center + dy),scale * random.uniform(1.0/diz_scale, diz_scale),angle,(PATCH_SIZE[0]/2,PATCH_SIZE[1]/2))
            patch = cv2.warpAffine(image, matrix, PATCH_SIZE)
            # cv2.imshow('patch',patch)
            # cv2.waitKey(0)

            new_pol_data = []
            for j, obj in enumerate(pol_data):
                cls = int(obj[0])
                pts = np.array(obj[1:]).reshape(-1, 2) * [width, height]
                new_pts = cv2.transform(np.array([pts]), matrix)[0]
                new_pts = new_pts / PATCH_SIZE  # 将绝对坐标转换为相对坐标
                # 计算新坐标的中心点
                center_x, center_y = new_pts[:,0].mean(), new_pts[:,1].mean()
                #if all(0 <= p[0] < 1 and 0 <= p[1] < 1 for p in new_pts):
                if 0 <= center_x < 1 and 0 <= center_y < 1:
                    x_min, y_min = new_pts[:, 0].min(), new_pts[:, 1].min()
                    x_max, y_max = new_pts[:, 0].max(), new_pts[:, 1].max()
                    new_x = (x_min + x_max) / 2
                    new_y = (y_min + y_max) / 2
                    new_w = (x_max - x_min)
                    new_h = (y_max - y_min)
                    new_pol_data.append([cls] + new_pts.flatten().tolist())

                    if min(x_min*PATCH_SIZE[0], (1 - x_max)*PATCH_SIZE[0], y_min*PATCH_SIZE[1], (1 - y_max)*PATCH_SIZE[1]) > min_dist_to_edge:
                        select_times[j] += 1

            patch_name = f'{filename}_{idx}-{dx}_{dy}-{angle}-{patch_index}'
            save_patch(patch, new_pol_data, patch_name, output_path)
            patch_index += 1
            
        #gen negitive samples
        for _ in range(max_neg_select):
            x_center, y_center = random.randint(min_dist_to_edge, width - min_dist_to_edge), random.randint(min_dist_to_edge, height - min_dist_to_edge)
            angle = random.uniform(-diz_angle,diz_angle)
            #matrix = cv2.getRotationMatrix2D((x_center, y_center), angle, scale)
            matrix = get_affine_transform((x_center, y_center), scale * random.uniform(1.0/diz_scale, diz_scale),angle,(PATCH_SIZE[0]/2,PATCH_SIZE[1]/2))
            patch = cv2.warpAffine(image, matrix, PATCH_SIZE)

            for j, obj in enumerate(pol_data):
                pts = np.array(obj[1:]).reshape(-1, 2) * [width, height]
                new_pts = cv2.transform(np.array([pts]), matrix)[0]
                new_pts = new_pts / PATCH_SIZE  # 将绝对坐标转换为相对坐标

                center_x = np.mean(new_pts[:, 0])
                center_y = np.mean(new_pts[:, 1])
                #if all(0 <= p[0] < 1 and 0 <= p[1] < 1 for p in new_pts):
                if 0 <= center_x < 1 and 0 <= center_y < 1:
                    cv2.fillPoly(patch, [np.int32(new_pts * PATCH_SIZE)], (128, 128, 128))

            patch_name = f'neg-{os.path.basename(image_path)}_{x_center}_{y_center}-{patch_index}'
            save_patch(patch, [], patch_name, output_path)
            patch_index += 1
        total_img+=1
        if max_generated>0 and total_img>max_generated:
            break

# 示例用法
# data_path = '/media/data4T/datas/SAR-TZ-ship'
#data_path ='/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/car_det_train/val'
#data_path = '/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/dota1.5/generated_car'
data_path = r'/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/track-345/track-345/converted_outputs'
generate_patches(data_path, 36, 180, 2.0, MIN_DISTANCE_TO_EDGE, MAX_OBJ_SELECT, MAX_NEG_SELECT,output_folder='val-patches',max_generated=0)
