import torch
from .metrics import bbox_iou

def build_one2one_cost_matrix(pred_scores, pred_bboxes, target_bboxes, target_scores, gt_bboxes, gt_labels, strides):
    # 构建一对一匹配的cost矩阵
    # Args:
    #     pred_scores: [n_pos, nc] 预测分类分数
    #     pred_bboxes: [n_pos, 4] 预测边界框
    #     target_bboxes: [n_pos, 4] 目标边界框
    #     target_scores: [n_pos, nc] 目标分类分数
    #     gt_bboxes: [n_gt, 4] 真实边界框
    #     gt_labels: [n_gt] 真实标签
    #     strides: [n_pos, 1] 步长
    # Returns:
    #     cost_matrix: [n_gt, n_pos] cost矩阵
    n_gt = gt_bboxes.shape[0]
    n_pos = pred_bboxes.shape[0]
    
    # 初始化cost矩阵
    cost_matrix = torch.zeros((n_gt, n_pos), device=pred_scores.device)
    
    # 计算分类cost（负的分类置信度，因为要最小化cost）
    cls_cost = -pred_scores[:, gt_labels]  # [n_pos, n_gt]
    
    # 计算IOU cost
    iou_cost = torch.zeros((n_pos, n_gt), device=pred_scores.device)
    for j in range(n_gt):
        # 只考虑与当前gt匹配的预测框
        gt_mask = (target_scores.argmax(-1) == gt_labels[j])  # [n_pos]
        if gt_mask.any():
            ious = bbox_iou(pred_bboxes[gt_mask], gt_bboxes[j:j+1], xywh=False, CIoU=True)  # [n_gt_mask, 1]
            iou_cost[gt_mask, j] = 1.0 - ious.squeeze(-1)  # IOU越大，cost越小
    
    # 组合cost（分类cost + IOU cost）
    cost_matrix = cls_cost.T + iou_cost.T * 2.0  # 给IOU cost更高权重
    
    return cost_matrix

def hungarian_matching(cost_matrix):
    # 使用匈牙利算法进行一对一匹配
    # Args:
    #     cost_matrix: [n_gt, n_pos] cost矩阵
    # Returns:
    #     matched_gt_indices: 匹配的gt索引
    #     matched_pred_indices: 匹配的预测框索引
    try:
        from scipy.optimize import linear_sum_assignment
        import numpy as np
        
        cost_matrix_np = cost_matrix.cpu().detach().numpy()
        gt_indices, pred_indices = linear_sum_assignment(cost_matrix_np)
        
        return gt_indices, pred_indices
    except ImportError:
        # 备用方案：使用简单的贪婪匹配
        return greedy_matching(cost_matrix)

def greedy_matching(cost_matrix):
    # 贪婪匹配作为备用方案
    n_gt, n_pos = cost_matrix.shape
    matched_gt = set()
    matched_pred = set()
    matches = []
    
    # 按cost排序
    all_costs = []
    for i in range(n_gt):
        for j in range(n_pos):
            all_costs.append((cost_matrix[i, j].item(), i, j))
    
    all_costs.sort(key=lambda x: x[0])
    
    for cost, i, j in all_costs:
        if i not in matched_gt and j not in matched_pred:
            matches.append((i, j))
            matched_gt.add(i)
            matched_pred.add(j)
            
            if len(matches) == min(n_gt, n_pos):
                break
    
    if matches:
        gt_indices, pred_indices = zip(*matches)
        return list(gt_indices), list(pred_indices)
    else:
        return [], []
    

# === 新增：一对一筛选 ===
def one_to_one_refine(target_labels, target_bboxes, target_scores, fg_mask, target_gt_idx, mask_gt):
    # 保留每个 GT 只对应一个 anchor（置信度最高的那个）
    # 所有形状保持一致，方便后续直接使用。
    #target_labels[B,ntotal] target_bboxes[B,ntotal,4(xyxy)] target_scores[B,ntotal,nc] fg_mask[B,ntotal] target_gt_idx[B,ntotal] mask_gt: [B, nt, 1] -> 原始GT有效mask 
    B, N, C = target_scores.shape
    new_fg_mask = torch.zeros_like(fg_mask)
    new_target_scores = torch.zeros_like(target_scores) #new_target_scores[B,ntotal,nc]
    new_target_bboxes = torch.zeros_like(target_bboxes)#new_target_bboxes[B,ntotal,4(xyxy)]
    new_target_labels = torch.full_like(target_labels, fill_value=-1) #new_target_labels[B,ntotal] 默认无匹配
    new_target_gt_idx = torch.full_like(target_gt_idx, fill_value=-1) #new_target_gt_idx[B,ntotal]

    gt_sum = 0 
    for b in range(B):
        pos_idx = fg_mask[b].nonzero(as_tuple=True)[0] #pos_idx[ntb]
        if len(pos_idx) > 0:
            # 获取正样本对应的 GT 索引
            gt_ids = target_gt_idx[b, pos_idx] #gt_ids[ntb]
            conf = target_scores[b, pos_idx].max(dim=1).values  # conf[ntb]每个正样本置信度

            gt_ids_1 = gt_ids.unique()
            for g in gt_ids_1:
                mask = gt_ids == g #mask[ntb]
                if mask.sum() > 0 and g >= 0:
                    idxs = pos_idx[mask] #idxs[mask]->idxs[ntb2]
                    best = idxs[conf[mask].argmax()] #conf[mask][ntb2]->best

                    # ✅ 保留最佳匹配 anchor
                    if mask_gt[b,target_gt_idx[b, best]]:
                        new_fg_mask[b, best] = True
                        new_target_scores[b, best] = target_scores[b, best]
                        new_target_bboxes[b, best] = target_bboxes[b, best]
                        new_target_labels[b, best] = target_labels[b, best]
                        new_target_gt_idx[b, best] = target_gt_idx[b, best]
                        gt_sum += 1
            # gt_sum += gt_ids_1.shape[0]

    return new_target_labels, new_target_bboxes, new_target_scores, new_fg_mask, new_target_gt_idx, gt_sum
          #new_target_scores[B,ntotal,nc] new_target_bboxes[B,ntotal,4(xyxy)] new_target_labels[B,ntotal] new_target_gt_idx[B,ntotal]

def one_to_one_refine2(target_labels, target_bboxes, target_scores, fg_mask, target_gt_idx, mask_gt):
    # 严格一对一匹配，每个 GT 只对应一个 anchor（置信度最高的那个），
    # 并保证 gt_sum <= nt。
    # Args:
    #     target_labels: [B, N]
    #     target_bboxes: [B, N, 4]
    #     target_scores: [B, N, C]
    #     fg_mask: [B, N]
    #     target_gt_idx: [B, N] -> 对应GT索引
    #     mask_gt: [B, nt, 1] -> 原始GT有效mask
    # Returns:
    #     new_target_labels, new_target_bboxes, new_target_scores, new_fg_mask, new_target_gt_idx, gt_sum
    B, N, C = target_scores.shape
    _, nt, _ = mask_gt.shape

    # 初始化输出
    new_fg_mask = torch.zeros_like(fg_mask)
    new_target_scores = torch.zeros_like(target_scores)
    new_target_bboxes = torch.zeros_like(target_bboxes)
    new_target_labels = torch.full_like(target_labels, -1)
    new_target_gt_idx = torch.full_like(target_gt_idx, -1)

    gt_sum = 0

    for b in range(B):
        # 遍历原始有效GT索引
        for g in range(nt):
            if mask_gt[b, g, 0]:
                # 找出当前GT对应的所有正样本anchor
                anchor_idx = (target_gt_idx[b] == g).nonzero(as_tuple=True)[0]
                if len(anchor_idx) > 0: #有匹配到任何anchor
                    # 选择置信度最高的anchor
                    conf = target_scores[b, anchor_idx].max(dim=1).values
                    best = anchor_idx[conf.argmax()]

                    # 保存到新张量
                    new_fg_mask[b, best] = True
                    new_target_scores[b, best] = target_scores[b, best]
                    new_target_bboxes[b, best] = target_bboxes[b, best]
                    new_target_labels[b, best] = target_labels[b, best]
                    new_target_gt_idx[b, best] = g

                    gt_sum += 1  # 累加匹配到的GT

    return new_target_labels, new_target_bboxes, new_target_scores, new_fg_mask, new_target_gt_idx, gt_sum