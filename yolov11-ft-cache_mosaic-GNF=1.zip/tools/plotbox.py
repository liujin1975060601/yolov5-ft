import cv2
import random
import os
import numpy as np
import json


def plot_one_box(x, img, color=None, label=None, line_thickness=None,text=None):
    # Plots one bounding box on image img
    tl = line_thickness or round(0.001 * max(img.shape[0:2])) + 1  # line thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1)  # filled
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)
    if text is not None:
        cv2.putText(img, text, (c1[0], c1[1] - 2 + 20), 0, tl/3, color, thickness=tf, lineType=cv2.LINE_AA)

def plot_one_rot_box(x, img, color=None, label=None, line_thickness=None, leftop=False, radius=3, dir_line=False,text=None):
    tl = line_thickness or round(0.001 * max(img.shape[0:2])) + 1  # line thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    x = np.int32(x)
    leftop_x = (x[0], x[1])
    if dir_line:
        x1, y1 = (x[0] + x[2]) / 2, (x[1]+x[3]) / 2
        x2, y2 = (x[4] + x[6]) / 2, (x[5] + x[7]) / 2
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        cv2.arrowedLine(img, (int(cx), int(cy)), (int(x1), int(y1)), (0, 0, 255), thickness=tl)
    x = x.reshape((-1, 1, 2))
    cv2.polylines(img, [x], True, color, thickness=tl)
    if leftop:
        cv2.circle(img, leftop_x, radius, color, tl)
    if label:
        tf = max(tl - 1, 1) 
        cv2.putText(img, label, leftop_x, 0, tl/3, color, thickness=tf, lineType=cv2.LINE_AA)
    if text is not None:
        cv2.putText(img, text, (leftop_x[0],leftop_x[1]+20), 0, tl/3, color, thickness=tf, lineType=cv2.LINE_AA)

def ft2xy(an,bn,cn,dn,theta_fine,term):
    term = an.shape[0] if term<=0 else term
    x_approx = sum([an[i]*np.cos(i*theta_fine) + bn[i]*np.sin(i*theta_fine) for i in range(term)])
    y_approx = sum([cn[i]*np.cos(i*theta_fine) + dn[i]*np.sin(i*theta_fine) for i in range(term)])
    return x_approx,y_approx
def fft_area(ft_label):
    an,bn,cn,dn = np.split(ft_label[2:].reshape(-1, 4), 4, axis=-1) #[4n]->[n,4]->an[n,1],bn[n,1],cn[n,1],dn[n,1]
    an, bn, cn, dn = an.squeeze(-1), bn.squeeze(-1), cn.squeeze(-1), dn.squeeze(-1)
    #Sum(k*(ak*dk-bk*ck))
    assert an.shape[0]==len(an)==bn.shape[0]==cn.shape[0]==dn.shape[0]
    return np.pi * ((an*dn-bn*cn)*np.arange(1,1+an.shape[0])).sum()

def fft_areas(ft_labels):
    # 计算多个傅里叶闭合曲线的面积
    # 参数:  ft_labels: [n_obj, 2+4n]
    # 返回:  areas: [n_obj] 每个目标曲线的面积
    n_obj, dim = ft_labels.shape
    n = (dim - 2) // 4  # 傅里叶阶数
    # 取出 an, bn, cn, dn  [n_obj, n]
    coeffs = ft_labels[:, 2:].reshape(n_obj, n, 4)
    an, bn, cn, dn = coeffs[..., 0], coeffs[..., 1], coeffs[..., 2], coeffs[..., 3]
    # 权重 k = 1..n
    k = np.arange(1, n+1, dtype=ft_labels.dtype)
    # 面积公式: π * Σ k * (an*dn - bn*cn)
    areas = np.pi * ((an * dn - bn * cn) * k).sum(axis=1)
    return areas #[n_obj]
def reverse_ffts(ft_label):
    ft_label[:,3::2] *= -1

def plot_one_box_with_ft(x, img, color=None, label=None, line_thickness=None, ft_label=None, amp_stat=None, show_amp=0, show_box=False):
    # Plots one bounding box on image img
    tl = line_thickness or round(0.001 * max(img.shape[0:2])) + 1  # line thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    tf = max(tl - 1, 1)  # font thickness
    if ft_label is None or show_box:
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        # c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
        cv2.rectangle(img, c1, c2, color, thickness=tl)
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1)  # filled
        cv2.rectangle(img, c1, c2, color, thickness=tl)
        if label:
            cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)
    if ft_label is not None :
        theta_fine = np.linspace(0, 2*np.pi, 200)
        an,bn,cn,dn = np.split(ft_label[2:].reshape(-1, 4), 4, axis=-1)
        an,bn,cn,dn = np.insert(an,0,ft_label[0]),np.insert(bn,0,0),np.insert(cn,0,ft_label[1]),np.insert(dn,0,0)

        x_approx,y_approx = ft2xy(an,bn,cn,dn,theta_fine,0)#an.shape[0]
        contour_approx = np.array(list(zip(x_approx, y_approx)), dtype=np.int32).reshape((-1, 1, 2))
        cv2.polylines(img, [contour_approx], isClosed=True, color=color, thickness=2)

        if label:
            t_size = cv2.getTextSize(label, 0, fontScale=tl / 6, thickness=max(tf//2,1))[0]
            # cv2.rectangle(img, (round(ft_label[0]), round(ft_label[1])), (round(ft_label[0]) + t_size[0], round(ft_label[1] - 2) - t_size[1] - 3), (255,255,255), -1)
            cv2.putText(img, label, (round(ft_label[0]), round(ft_label[1] - 2)), 0, tl / 6, [50, 50, 50], thickness=max(tf//2,1), lineType=cv2.LINE_AA)

        amp = [0 for i in range(1, an.shape[0])]
        if amp_stat is None:
            amp_stat = [0 for i in range(0, an.shape[0])]
        for i_ in range(1, an.shape[0]):
            amp[i_ - 1] = np.sqrt(an[i_] ** 2 + bn[i_] ** 2 + cn[i_] ** 2 + dn[i_] ** 2) 
            amp_stat[i_ - 1] += amp[i_ - 1]
            amp[i_ - 1] = amp[i_ - 1] / max(img.shape) * 30
            amp_stat[-1] += 1
        if show_amp:
            c1 = (round(ft_label[0]), round(ft_label[1] - 15))
            #
            cv2.rectangle(img, (c1[0], c1[1] + 3), (c1[0] + len(amp) * 6 + 3, int(c1[1] - max(amp) * 5 - 3)), (255,255,255), -1)
            for i_ in range(1, an.shape[0]):
                offset_amp = i_ * 6 - 3
                cv2.rectangle(img, (c1[0] + offset_amp, c1[1]), (c1[0] + offset_amp + 3, int(c1[1] - amp[i_ - 1] * 5)), (255,255,0), -1)
            #
            ft_area = fft_area(ft_label)
            str_area = f'{ft_area:.1f}'
            t_size = cv2.getTextSize(str_area, 0, fontScale=tl / 8, thickness=max(tf//2,1))[0]
            cv2.putText(img, str_area, (c1[0] + len(amp) * 6 - t_size[0], int(c1[1] - max(amp) * 5 + t_size[1])), 0, tl / 8, color=color, thickness=max(tf//2,1), lineType=cv2.LINE_AA)




def plot_images_from_8points():
    image_path = '/home/LIESMARS/2019286190105/datasets/final-master/DOTA/DOTA768/val/images'
    label_path = '/home/LIESMARS/2019286190105/datasets/final-master/DOTA/DOTA768/val/labelTxt1.5'
    images = os.listdir(image_path)
    save_path = './runs/detect/results'

    for image in images:
        # 读取label
        label_name = image.split('.')[0] + '.txt'
        src_img = cv2.imread(os.path.join(image_path, image))
        with open(os.path.join(label_path, label_name), 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip().split(' ')
                segmentation = [int(float(x)) for x in line[:8]]
                category = line[8]
                # xmin, ymin, xmax, ymax = min(segmentation[::2]), min(segmentation[1::2]), \
                #                          max(segmentation[::2]), max(segmentation[1::2])
                # xyxy = np.array([xmin, ymin, xmax, ymax])
                # plot_one_box(xyxy, src_img, label=category)
                plot_one_rot_box(segmentation, src_img, label=category, dir_line=True, leftop=True)
            cv2.imwrite(os.path.join(save_path, image), src_img)


def plot_images_from_xywh():
    image_path = r'/home/LIESMARS/2019286190105/datasets/final-master/UCAS50/images/train'
    label_path = r'/home/LIESMARS/2019286190105/datasets/final-master/UCAS50/labels/train'
    images = os.listdir(image_path)
    save_path = '../runs/detect/exp2'
    # clses = ['triangle_horizontal', 'triangle_vertical', 'triangle_oblique', 'dangerous_goods', 'dangerous']
    for image in images:
        label_name = image.split('.')[0] + '.txt'
        src_img = cv2.imread(os.path.join(image_path, image))
        # width, height = src_img.shape[:2]
        height, width = src_img.shape[:2]
        label = os.path.join(label_path, label_name)
        if not os.path.exists(label):
            continue
        with open(label, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip().split(' ')
                # cls = int(line[0])
                # category = clses[cls]
                category = line[0]
                xywh = [float(line[1]), float(line[2]), float(line[3]), float(line[4])]
                xyxy = np.array(xywh2xyxy(xywh, width, height))
                plot_one_box(xyxy, src_img, label=category)
            cv2.imwrite(os.path.join(save_path, image), src_img)


def plot_images_from_rot():
    image_path = r'/home/LIESMARS/2019286190105/datasets/final-master/DOTA/DOTA1.0-1.5/val/images'
    label_path = r'/home/LIESMARS/2019286190105/datasets/final-master/DOTA/DOTA1.0-1.5/val/labels1.5'
    save_path = r'/home/LIESMARS/2019286190105/finalwork/yolov5/runs/detect/images'
    images = os.listdir(image_path)
    for image in images:
        print(image)
        label_name = image.split('.')[0] + '.pts'
        src_img = cv2.imread(os.path.join(image_path, image))
        height, width  = src_img.shape[:2]
        with open(os.path.join(label_path, label_name), 'r', encoding='utf-8') as f:
            for line in f:
                points = line.strip().split(' ')
                arr = []
                for i, x in enumerate(points[1:]):
                    if i % 2 == 0:
                        arr.append(float(x) * width)
                    else:
                        arr.append(float(x) * height)
                plot_one_rot_box(np.array(arr), src_img, dir_line=True, label=points[0], leftop=True)
                # plot_one_rot_box(np.array(arr), src_img, dir_line=False, label=None)
            cv2.imwrite(os.path.join(save_path, image), src_img)


def xyrot2xy(x, width, height):
    x = np.array(x, dtype=np.float)
    x[:, 0] *= width
    x[:, 1] *= height
    return x


def xywh2xyxy(x, width, height):
    x, y, w, h = x[0], x[1], x[2], x[3]
    x1, y1 = x - w / 2, y - h / 2
    x2, y2 = x + w / 2, y + h / 2
    x1 *= width
    x2 *= width
    y1 *= height
    y2 *= height
    return [int(x1), int(y1), int(x2), int(y2)]

def show_ft(img, cls_id=(),xy_rect=(),ft_labels=(),colors=None):
    # h, w, _ = img.shape
    new_img = img.copy()
    theta_fine = np.linspace(0, 2*np.pi, 200)
    for i, label in enumerate(ft_labels):
        if len(ft_labels) > i:#for ft
            cls = int(cls_id[i])
            an,bn,cn,dn = [abcd.reshape(-1) for abcd in np.split(label[2:].reshape(-1, 4), 4, axis=-1)]
            x_approx = sum([an[i]*np.cos((i+1)*theta_fine) + bn[i]*np.sin((i+1)*theta_fine) for i in range(an.shape[0])])
            y_approx = sum([cn[i]*np.cos((i+1)*theta_fine) + dn[i]*np.sin((i+1)*theta_fine) for i in range(an.shape[0])])
            xy = np.vstack([x_approx + label[0], y_approx + label[1]]).T# * (w, h)
            xy = xy.astype(np.int32)
            color = colors(cls%colors.n) if colors is not None else (0,0,255)
            cv2.polylines(new_img, [xy], True, color, 2)
        
        if len(xy_rect) > 0: #for h rect
            xy_label = xy_rect[i]
            if len(xy_label)==4:
                cv2.rectangle(new_img, (int(xy_label[0]), int(xy_label[1])), (int(xy_label[2]), int(xy_label[3])), (0,255,0), 2)
            elif len(xy_label)==12: # for pts
                pts_ = xy_label[4:].reshape([-1, 2]).astype(np.int32)
                cv2.polylines(new_img, [pts_], True, (0,0,255), 2)
    return new_img

import torch
def render_fourier_heatmap(image, coeffs, res=256, nf=None):
    """
    可视化傅里叶形状目标的热力图
    Args:
        image: 原始BGR图像 (numpy)
        coeffs: [np, 2 + nf*4] torch.Tensor
        res: 曲线采样点数
    Returns:
        与原图叠加后的热力图 BGR (numpy)
    """
    H, W = image.shape[:2]
    device = coeffs.device if torch.is_tensor(coeffs) else "cpu"
    coeffs = coeffs.to(device)
    np_target = coeffs.shape[0]

    # 自动计算 nf
    nf = (coeffs.shape[1] - 2) // 4 if nf is None else nf

    heat = np.zeros((H, W), np.float32)

    for i in range(np_target):
        coef = coeffs[i]
        a0, c0 = coef[0].item(), coef[1].item()
        f = coef[2:].view(nf, 4)
        an, bn, cn, dn = [f[:, j].cpu().numpy() for j in range(4)]

        # 采样傅里叶曲线
        t = np.linspace(0, 2*np.pi, res)
        n = np.arange(1, nf + 1)
        cos_t = np.cos(np.outer(t, n))
        sin_t = np.sin(np.outer(t, n))

        x_t = a0 + (cos_t @ an + sin_t @ bn)
        y_t = c0 + (cos_t @ cn + sin_t @ dn)
        pts = np.stack([x_t, y_t], axis=1).astype(np.int32)

        # 绘制mask
        mask = np.zeros((H, W), np.uint8)
        cv2.fillPoly(mask, [pts], 1)

        # 距离变换
        dist_out = cv2.distanceTransform(1 - mask, cv2.DIST_L2, 3)
        dist_in = cv2.distanceTransform(mask, cv2.DIST_L2, 3)
        signed_dist = dist_in - dist_out

        # 平滑归一化
        norm_dist = np.tanh(signed_dist / 15.0)
        heat = np.maximum(heat, norm_dist)  # 合并多个目标

    # 归一化到[0,1]
    heat_norm = (heat - heat.min()) / (heat.max() - heat.min() + 1e-6)

    # 使用红蓝显著色彩映射
    heatmap = cv2.applyColorMap((heat_norm * 255).astype(np.uint8), cv2.COLORMAP_JET)

    # 融合原图
    blend = cv2.addWeighted(image, 0.5, heatmap, 0.7, 0)

    return blend


if __name__ == '__main__':
    # plot_images_from_xywh()
    plot_images_from_8points()
    # plot_images_from_rot()
