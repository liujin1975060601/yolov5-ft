import os
import csv
import math
from pathlib import Path
import numpy as np
import cv2
import pandas as pd
import shutil
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from utils.csv_utils import csv_to_img,ais_to_pixel

# def read_csv_points(path):
#     ais = []
#     with open(path, newline='') as f:
#         reader = csv.reader(f)
#         for r in reader:
#             if not r:
#                 continue
#             try:
#                 x = float(r[0])
#                 y = float(r[1])
#                 h = float(r[-1])
#                 v = float(r[-2])
#                 ais.append([x, y, h, v])
#             except Exception:
#                 continue
#     return np.array(ais, dtype=float) if ais else np.zeros((0, 2)) #ais[L,4(xyhv)]

if __name__ == "__main__":
    # 输入输出路径
    ROOT = Path("../track-345")  # 你自己的根目录
    csv_dir = ROOT / "images"
    labels_dir = ROOT / "labels"
    out_root = ROOT / "converted_outputs"
    images_out = out_root / "images"
    labels_out = out_root / "labels"
    images_out.mkdir(parents=True, exist_ok=True)
    labels_out.mkdir(parents=True, exist_ok=True)

    # 自动拷贝 names.txt
    src_names = os.path.join(ROOT, "names.txt")
    dst_names = os.path.join(out_root, "names.txt")

    if os.path.exists(src_names):
        shutil.copy(src_names, dst_names)
        print(f"✅ 已拷贝 {src_names} -> {dst_names}")
    else:
        print("⚠️ 原始目录中没有找到 names.txt")

    summary = []
    csv_paths = sorted(csv_dir.glob("*.csv"))
    for csv_path in csv_paths:
        base = csv_path.stem
        img,ais,puv,A23 = csv_to_img(csv_path, scale_factor = 500)
        img_h,img_w = img.shape[:2]
        aisxy = ais[:,:2]
        cv2.imwrite(str(images_out / f"{base}.jpg"), img)
        if puv is not None:
            # 标签
            label_path = labels_dir / f"{base}.txt"
            pol_lines = []
            if label_path.exists():
                with open(label_path, "r") as f:
                    for line in f:
                        parts = line.strip().split()
                        if len(parts) < 3:
                            continue
                        cls, t0, t1 = int(parts[0]), int(parts[1]), int(parts[2])
                        n = aisxy.shape[0]
                        t0c = max(0, min(n-1, t0))
                        t1c = max(0, min(n-1, t1))
                        if t1c < t0c:
                            t0c, t1c = t1c, t0c
                        aisxy_seg = aisxy[t0c:t1c+1, :]
                        if aisxy_seg.shape[0] == 0:
                            aisxy_seg = aisxy[[t0c], :]

                        # 转换到像素坐标
                        seg_pixels = np.array([ais_to_pixel(x,y,A23) for x,y in aisxy_seg])
                        seg_pixels = seg_pixels.astype(np.float32)

                        # 最小外接矩形
                        rect = cv2.minAreaRect(seg_pixels)  # (center, (w,h), angle)
                        box = cv2.boxPoints(rect)  # 4个点
                        # 归一化
                        coords = []
                        for (px, py) in box:
                            coords.extend([px/img_w, py/img_h])
                        line_str = f"{cls} " + " ".join(f"{c:.6f}" for c in coords)
                        pol_lines.append(line_str)

                with open(labels_out / f"{base}.pol", "w") as f:
                    f.write("\n".join(pol_lines))

            summary.append({
                "file": csv_path.name,
                "points": aisxy.shape[0],
                "status": "done"
            })

    print(pd.DataFrame(summary))
    print("输出目录：", out_root)
