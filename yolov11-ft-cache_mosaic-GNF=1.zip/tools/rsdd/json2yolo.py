import json
import os
import numpy as np
from collections import defaultdict
from tqdm import tqdm
import cv2

# Fourier coefficient computation (given by user)
def compute_coefficients_interp(xy, terms=2, interp=True, return_list=False):
    if len(xy.shape) == 2:
        x = np.array(xy[:, 0])
        y = np.array(xy[:, 1])
    else:
        assert len(xy.shape) == 1
        x = np.array(xy[0::2])
        y = np.array(xy[1::2])

    if interp:
        x = np.concatenate([x, [x[0]]], dtype=np.float32)
        y = np.concatenate([y, [y[0]]], dtype=np.float32)
        ori = np.linspace(0, 1, x.shape[0], endpoint=True)
        gap = np.linspace(0, 1, terms * 2, endpoint=False)
        x = np.interp(gap, ori, x)
        y = np.interp(gap, ori, y)

    N = len(x)
    t = np.linspace(0, 2 * np.pi, N, endpoint=False)
    a0 = 1. / N * sum(x)
    c0 = 1. / N * sum(y)

    an, bn, cn, dn = [np.zeros(1 + terms) for _ in range(4)]
    for k in range(1, (N // 2) + 1):
        if k > terms:
            break
        an[k] = 2. / N * sum(x * np.cos(k * t))
        bn[k] = 2. / N * sum(x * np.sin(k * t))
        cn[k] = 2. / N * sum(y * np.cos(k * t))
        dn[k] = 2. / N * sum(y * np.sin(k * t))

    if return_list:
        list_coef = [a0, c0]
        for k in range(1, an.shape[0]):
            list_coef += [an[k], bn[k], cn[k], dn[k]]
        return list_coef

    an[0] = a0
    cn[0] = c0
    return (an, bn, cn, dn), (x, y)

# Add helper to scale Fourier coefficient from pixel to normalized coordinates
def ft_scale(ft, scale):
    assert ((len(ft) - 2) % 4) == 0
    scalex, scaley = scale
    ft[0] *= scalex  # a0
    ft[1] *= scaley  # c0
    ft[2::4] = np.array(ft[2::4]) * scalex  # a_i
    ft[3::4] = np.array(ft[3::4]) * scalex  # b_i
    ft[4::4] = np.array(ft[4::4]) * scaley  # c_i
    ft[5::4] = np.array(ft[5::4]) * scaley  # d_i
    return ft

def process_data(json_path,ft_terms=6,apply_hull=True):
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Build image_id -> filename, width, height
    id_to_image = {img["id"]: img for img in data["images"]}

    # Build class name -> id map
    cat_id_to_name = {cat["id"]: cat["name"] for cat in data["categories"]}
    name_to_cls = {name: idx for idx, name in enumerate(sorted(set(cat_id_to_name.values())))}

    # Prepare output storage
    results = defaultdict(lambda: {"txt": [], "pol": [], "ft": []})

    # Process annotations with hull + scaled Fourier features
    for ann in tqdm(data["annotations"], desc="Processing with hull and scaling"):
        image_info = id_to_image[ann["image_id"]]
        fname = os.path.splitext(image_info["file_name"])[0]
        width, height = image_info["width"], image_info["height"]
        cls_name = cat_id_to_name[ann["category_id"]]
        cls_id = name_to_cls[cls_name]

        # YOLO bbox
        x, y, w, h = ann["bbox"]
        cx = (x + w / 2) / width
        cy = (y + h / 2) / height
        w /= width
        h /= height
        results[fname]["txt"].append(f"{cls_id} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}")

        # Polygon points
        poly = ann["segmentation"][0]
        if apply_hull:
            poly_np = np.array(poly, dtype=np.float32).reshape(-1, 2)
            poly_np = cv2.convexHull(poly_np).reshape(-1, 2)
            poly = poly_np.flatten().tolist()

        # Store .pol (normalized)
        norm_poly = [f"{poly[i]/width:.6f}" if i % 2 == 0 else f"{poly[i]/height:.6f}" for i in range(len(poly))]
        results[fname]["pol"].append(f"{cls_id} " + " ".join(norm_poly))

        # Fourier transform (.ft)
        ft_list = compute_coefficients_interp(np.array(poly), terms=ft_terms, return_list=True)
        ft_scaled = ft_scale(ft_list, (1.0 / width, 1.0 / height))
        results[fname]["ft"].append(f"{cls_id} " + " ".join([f"{v:.6f}" for v in ft_scaled]))
    
    # Prepare result summary (e.g., sample file output)
    sample_key = next(iter(results))
    sample_result = results[sample_key]
    sample_result["txt"][:2], sample_result["pol"][:2], sample_result["ft"][:2]


    # Extract and sort all class names (for names.txt)
    sorted_names = [name for name, _ in sorted(name_to_cls.items(), key=lambda x: x[1])]
    sorted_names[:5], sample_key, results[sample_key]["ft"][:1]


    # 定义输出目录
    output_dir = os.path.join(os.path.dirname(json_path),'labels') #"/mnt/data/labels"
    os.makedirs(output_dir, exist_ok=True)

    # 写入所有 .txt, .pol, .ft 文件
    for fname, content in results.items():
        base_path = os.path.join(output_dir, fname)
        
        with open(base_path + ".txt", "w") as f_txt:
            f_txt.write("\n".join(content["txt"]) + "\n")
        
        with open(base_path + ".pol", "w") as f_pol:
            f_pol.write("\n".join(content["pol"]) + "\n")
        
        with open(base_path + ".ft", "w") as f_ft:
            f_ft.write("\n".join(content["ft"]) + "\n")

    # 写入 names.txt（与 labels 文件夹平行）
    names_txt_path = os.path.join(os.path.dirname(output_dir), "names.txt")
    with open(names_txt_path, "w") as f_names:
        f_names.write("\n".join(sorted_names) + "\n")

    # 返回示例文件名和其内容预览
    example_file = next(iter(results))
    example_file_paths = {
        "txt": base_path + ".txt",
        "pol": base_path + ".pol",
        "ft": base_path + ".ft",
        "names": names_txt_path
    }
    example_file_paths

if __name__ == "__main__":
    # Load JSON
    json_path = r"K:/datas/rsdd/train.json"
    process_data(json_path,ft_terms=6,apply_hull=True)
    json_path = r"K:/datas/rsdd/test.json"
    process_data(json_path,ft_terms=6,apply_hull=True)

    

