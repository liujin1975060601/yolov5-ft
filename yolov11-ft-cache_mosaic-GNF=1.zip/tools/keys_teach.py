import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from scipy.interpolate import interp1d

if __name__ == "__main__":
    # 1. 模拟傅里叶系数数据（偏正态分布）
    np.random.seed(42)
    fourier_coeffs = np.random.normal(loc=0.0, scale=1.0, size=10000)

    # 2. 估计密度函数 f(t)
    kde = gaussian_kde(fourier_coeffs, bw_method=0.3)
    t = np.linspace(fourier_coeffs.min(), fourier_coeffs.max(), 1000)
    f_t = kde(t)

    # 3. 计算累积分布函数 F(t)
    cdf = np.cumsum(f_t)
    cdf = cdf / cdf[-1]  # 归一化为 [0,1]

    # 4. 插值获得 F⁻¹(u)
    F_inv = interp1d(cdf, t, bounds_error=False, fill_value=(t[0], t[-1]))

    # 5. 生成等间隔概率值并反算关键值序列
    u_values = np.linspace(0, 1, 17)  # 比如分成16个间隔
    key_values = F_inv(u_values)

    # 6. 可视化
    plt.figure(figsize=(14, 6))

    # PDF 和关键值展示
    plt.subplot(1, 2, 1)
    plt.plot(t, f_t, label='Estimated PDF f(t)', color='steelblue')
    plt.vlines(key_values, ymin=0, ymax=np.max(f_t)*0.2, colors='red', linestyles='--', label='Key Values')
    plt.title('PDF f(t) and Key Values')
    plt.xlabel('Fourier Coefficient Value t')
    plt.ylabel('Density')
    plt.legend()

    # CDF 和关键值位置 + 纵向投影
    plt.subplot(1, 2, 2)
    plt.plot(t, cdf, label='CDF F(t)', color='green')
    plt.scatter(key_values, u_values, color='red', label='Key Points', zorder=5)

    # 添加纵向投影线（从 t 轴投影到 CDF 曲线）
    for x, y in zip(key_values, u_values):
        plt.plot([x, x], [0, y], color='gray', linestyle='--', linewidth=1)

    # 添加横向投影线（辅助观察 y 轴等间距）
    for x, y in zip(key_values, u_values):
        plt.plot([x - 0.1, x + 0.1], [y, y], color='red', linestyle='--', linewidth=1)

    plt.title('CDF F(t) and Equi-Probability Points')
    plt.xlabel('Fourier Coefficient Value t')
    plt.ylabel('Cumulative Probability F(t)')
    plt.legend()

    plt.tight_layout()
    plt.show()

