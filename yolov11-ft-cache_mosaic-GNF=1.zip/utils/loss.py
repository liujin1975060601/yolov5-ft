# YOLOv5 ������ by Ultralytics, GPL-3.0 license
"""
Loss functions
"""

import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F 

from utils.metrics import bbox_iou
from utils.torch_utils import is_parallel

from utils.general import xywh2xyxy, dist2bbox
from models.yolo import OUT_LAYER
from .tal import TaskAlignedAssigner
from utils.general import check_version
from pathlib import Path

import scipy.stats
from utils.ft_utils import ft2pts

def generate_anchor_bias(shape, max_value=8.0, percentile=0.99, device='cpu'):
    # 生成一个高斯分布的 anchor_bias 张量，值分布在 [-max_value, max_value] 的区间中，约占百分比 percentile。
    # 参数:
    # - shape: 输出张量形状（例如 [batch, num_anchor, 4]）
    # - max_value: 希望值分布的最大幅值（即 -max_value ~ +max_value）
    # - percentile: 值分布在 [-max_value, max_value] 的百分比（例如 0.99）
    # - device: torch 设备字符串
    # 计算给定百分比的 z-score，例如 0.99 对应 z=2.576
    z = scipy.stats.norm.ppf((1 + percentile) / 2.0)
    std = max_value / z

    # 生成正态分布随机张量
    return torch.randn(*shape, device=device) * std

def smooth_BCE(eps=0.1):  # https://github.com/ultralytics/yolov3/issues/238#issuecomment-598028441
    # return positive, negative label smoothing BCE targets
    return 1.0 - 0.5 * eps, 0.5 * eps


class BCEBlurWithLogitsLoss(nn.Module):
    # BCEwithLogitLoss() with reduced missing label effects.
    def __init__(self, alpha=0.05):
        super(BCEBlurWithLogitsLoss, self).__init__()
        self.loss_fcn = nn.BCEWithLogitsLoss(reduction='none')  # must be nn.BCEWithLogitsLoss()
        self.alpha = alpha

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true)
        pred = torch.sigmoid(pred)  # prob from logits
        dx = pred - true  # reduce only missing label effects
        # dx = (pred - true).abs()  # reduce missing label and false label effects
        alpha_factor = 1 - torch.exp((dx - 1) / (self.alpha + 1e-4))
        loss *= alpha_factor
        return loss.mean()


class FocalLoss(nn.Module):
    # Wraps focal loss around existing loss_fcn(), i.e. criteria = FocalLoss(nn.BCEWithLogitsLoss(), gamma=1.5)
    def __init__(self, loss_fcn, gamma=1.5, alpha=0.25):
        super(FocalLoss, self).__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'  # required to apply FL to each element

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true)
        # p_t = torch.exp(-loss)
        # loss *= self.alpha * (1.000001 - p_t) ** self.gamma  # non-zero power for gradient stability

        # TF implementation https://github.com/tensorflow/addons/blob/v0.7.1/tensorflow_addons/losses/focal_loss.py
        pred_prob = torch.sigmoid(pred)  # prob from logits
        p_t = true * pred_prob + (1 - true) * (1 - pred_prob)
        alpha_factor = true * self.alpha + (1 - true) * (1 - self.alpha)
        modulating_factor = (1.0 - p_t) ** self.gamma
        loss *= alpha_factor * modulating_factor

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss


class QFocalLoss(nn.Module):
    # Wraps Quality focal loss around existing loss_fcn(), i.e. criteria = FocalLoss(nn.BCEWithLogitsLoss(), gamma=1.5)
    def __init__(self, loss_fcn, gamma=1.5, alpha=0.25):
        super(QFocalLoss, self).__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'  # required to apply FL to each element

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true)

        pred_prob = torch.sigmoid(pred)  # prob from logits
        alpha_factor = true * self.alpha + (1 - true) * (1 - self.alpha)
        modulating_factor = torch.abs(true - pred_prob) ** self.gamma
        loss *= alpha_factor * modulating_factor

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss


class ComputeLoss:
    # Compute losses
    def __init__(self, model, autobalance=False, key_loss=False, ft_stat=0, ft_cgm=None, debug_samples=0, save_dir=None):
        super(ComputeLoss, self).__init__()
        self.h = model.hyp  # hyperparameters
        self.sort_obj_iou = self.h.get('sort_obj_iou',0)
        self.cen_tobj = self.h.get('cen_tobj',0)
        self.GNF = self.h.get('GNF',0)
        self.ftxy = self.h.get('ftxy',0.0)
        self.ft_dec = self.h.get('ft_dec',0.0)
        self.n_loop = model.hyp.get('n_loop',8)
        device = next(model.parameters()).device  # get model device
        # Define criteria
        BCEcls = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([self.h['cls_pw']], device=device))
        BCEobj = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([self.h['obj_pw']], device=device))
        self.ft_cgm = ft_cgm
        # Class label smoothing https://arxiv.org/pdf/1902.04103.pdf eqn 3
        self.cp, self.cn = smooth_BCE(eps=self.h.get('label_smoothing', 0.0))  # positive, negative BCE targets

        # Focal loss
        g = self.h['fl_gamma']  # focal loss gamma
        if g > 0:
            BCEcls, BCEobj = FocalLoss(BCEcls, g), FocalLoss(BCEobj, g)

        det = model.module.model[-1] if is_parallel(model) else model.model[-1]  # Detect() module
        
        det = model.module.get_module_byname('Detect') if is_parallel(model) else model.get_module_byname('Detect')  # Detect() module
        if det is not None:
            self.balance = {3: [4.0, 1.0, 0.4]}.get(det.nl, [4.0, 1.0, 0.25, 0.06, .02])  # P3-P7
            self.ssi = list(det.stride).index(16) if autobalance else 0  # stride 16 index
        self.BCEcls, self.BCEobj, self.gr, self.hyp, self.autobalance = BCEcls, BCEobj, 1.0, self.h, autobalance
        
        if isinstance(save_dir, Path):
            save_dir.mkdir(exist_ok=True, parents=True)
        else:
            print('ComputeLoss:没有提供有效的画图保存路径, 已设置debug_samples = 0')
            save_dir = None
            debug_samples = 0

        # self.mode = 'origin'
        mname = ''
        for mname in OUT_LAYER.keys():
            m = model.module.get_module_byname(mname) if is_parallel(model) else model.get_module_byname(mname)
            if m is not None:
                break
            
        if mname in ['DetectDFL', 'DetectDFL_FT']:
            tal_topk = 10
            self.nc = m.nc
            self.na = 1
            self.nl = m.nl
            self.strides = m.stride
            # self.dfl_loss = m.compute_ecloss_dim3
            self.bce = nn.BCEWithLogitsLoss(reduction="none")
            self.reg_max = m.reg_max
            if mname == 'DetectDFL':
                # self.mode = 'dfl'
                self.assigner = TaskAlignedAssigner(topk=tal_topk, num_classes=self.nc, alpha=0.5, beta=6.0)
                self.__call = self.call_dfl
                self.bbox_loss = BboxLoss(self.reg_max).to(device)
            elif mname in ['DetectDFL_FT']:
                # self.mode = 'obb'
                self.assigner = TaskAlignedAssigner(topk=tal_topk, num_classes=self.nc, alpha=0.5, beta=6.0)
                self.__call = self.call_ft
                self.bbox_loss = BboxLoss(self.reg_max, key_loss=key_loss).to(device)
                if hasattr(model,'mask_line'):
                    self.mask_line = model.mask_line
                self.reg_max_ft = m.reg_max_ft
                self.ft_coef_length = m.ft_coef_length
                self.ft_loss = FTLoss(self.reg_max_ft, self.n_loop, self.GNF,self.ftxy,self.ft_dec,self.h.get('pred_clockwise',1),self.h.get('rot_normlize',0),
                                      debug_samples=debug_samples,save_dir=save_dir)
                self.proj_ft = m.proj_ft#.clone().detach()
                self.tags = ('Epoch', 'gpu_mem', 'box', 'cls', 'dfl', 'ft_xy', 'ft_coef', 'ft_dfl', 'labels', 'img_size')
            self.proj = m.proj #torch.arange(self.reg_max, dtype=torch.float, device=device)
        elif mname in ['Detect']:
            for k in 'na', 'nc', 'nl', 'anchors':
                setattr(self, k, getattr(det, k))
            self.__call = self.call_origin
        else:
            raise RuntimeError("模型找不到输出层[{OUT_LAYER}], 或者ComputeLoss还没适配当前模型输出层")
        if ft_stat == 1:
            self.__call = self.call_ft_statistics
        elif ft_stat == 2:
            self.__call = self.call_ft_statistics_nomodel
        
        self.debug_samples = debug_samples

    def __call__(self, *args, **kwds):
        return self.__call(*args, **kwds)

    def call_origin(self, p, targets, paths = None, master_path=''):   # predictions, targets, model
        device = targets.device
        bs = p[0].shape[0]
        assert paths is None or bs==len(paths)
        lcls, lbox, lobj = torch.zeros(1, device=device), torch.zeros(1, device=device), torch.zeros(1, device=device)
        tcls, tbox, indices, anchors = self.build_targets(p, targets)  # targets
        #tcls[nl][n,1(cls)]
        #tbox[nl][n,4(xywh)]
        #indices[nl][4(b,a,gj,gi)][n]
        #anchors[nl][n,2(aw,ah)]
        # Losses
        for i, pi in enumerate(p):  # layer index, layer predictions
            #pi[b,a,gj,gi,4(rect)+1(obj)+cls]
            b, a, gj, gi = indices[i]  # image, anchor, gridy, gridx
            #[n]
            tobj = torch.zeros_like(pi[..., 0], device=device)  # target obj
            #tobj[b,a,gj,gi]
            n = b.shape[0]  # number of targets
            if n:
                ps = pi[b, a, gj, gi]  # prediction subset corresponding to targets
                #[b,a,gj,gi,1(obj)+4(rect[xywh])+cls]-->ps[n,4(rect[xywh])+1(obj)+cls]
                # Regression
                pxy = ps[:, :2].sigmoid() * 2. - 0.5
                # pxy[n,2]
                pwh = (ps[:, 2:4].sigmoid() * 2) ** 2 * anchors[i]
                # pwh[n,2]
                pbox = torch.cat((pxy, pwh), 1)  # predicted box
                #pbox[n,4]
                #iou = bbox_iou(pbox, tbox[i], x1y1x2y2=False, CIoU=True)  # iou(prediction, target)
                iou = bbox_iou(pbox, tbox[i], CIoU=True).squeeze(-1)  # iou(prediction, target)
                # iou[n]
                lbox += (1.0 - iou).mean()  # iou loss

                # Objectness
                if self.cen_tobj:
                    pbox_cen = torch.cat((torch.full_like(pxy, 0.5, device=device), anchors[i]), 1)  # predicted box
                    iou_cen = bbox_iou(pbox_cen, tbox[i], CIoU=True).squeeze(-1)  # iou(prediction, target)
                    score_iou = iou_cen.detach().clamp(0).type(tobj.dtype)
                else:
                    score_iou = iou.detach().clamp(0).type(tobj.dtype)
                # score_iou[n]
                if self.sort_obj_iou:
                    sort_id = torch.argsort(score_iou)
                    b, a, gj, gi, score_iou = b[sort_id], a[sort_id], gj[sort_id], gi[sort_id], score_iou[sort_id]
                tobj[b, a, gj, gi] = (1.0 - self.gr) + self.gr * score_iou  # iou ratio
                # 所有目标对应的网格anchors都给1，其他都在初始化时刷0

                # Classification
                if self.nc > 1:  # cls loss (only if multiple classes)
                    if master_path=='':
                        # ps[:, 5:]的shape是[n, cls]  cn==0  全部填0
                        t = torch.full_like(ps[:, 5:], self.cn, device=device)  # targets
                        # t[n, cls]
                        # tcls[i]的shape是[n]  cp==1
                        # range(n)是一个shape为[n]的数组，下标从0~n-1
                        t[range(n), tcls[i]] = self.cp
                        ps_cls = ps[:, 5:]
                        lcls += self.BCEcls(ps_cls,t)  # BCE MSE
                        #det1_cls = t-ps[:, 5:]
                        #lcls2 += self.BCEcls(ps2[:, 5:], det1_cls)  # BCE
                        #master_masks = torch.ones([bs],device=tobj.device).to(torch.bool)
                    else:
                        # 生成布尔过滤器数组，True 表示包含 master_path 的路径，False 表示不包含
                        master_masks = torch.tensor([master_path in path for path in paths],device=tobj.device)
                        assert master_masks.shape[0]==bs
                        assert master_masks.sum().item()<=bs
                        if master_masks.sum().item()<bs:
                            # 取反布尔数组
                            #master_masks_reversed = np.logical_not(master_masks.cpu().numpy())
                            # 根据取反后的布尔数组过滤 paths，得到包含 include_str 的路径
                            app_paths = np.array(paths)[~master_masks.cpu().numpy()]
                            assert len(app_paths)>0
                            #print(app_paths)

                        master_obj_masks = master_masks[b] #master_obj_masks[n]
                        assert master_obj_masks.shape[0]==n
                        assert master_obj_masks.sum().item()<=n
                        if master_obj_masks.sum() > 0:
                            t = torch.full_like(ps[master_obj_masks, 7:], self.cn, device=device)  # targets
                            #t[n,class]==self.cn==0
                            t[range(master_obj_masks.sum().item()), tcls[i][master_obj_masks]] = self.cp
                            lcls += self.BCEcls(ps[master_obj_masks, 7:], t)  # BCE
                            if lcls.isnan():
                                print('lcls.isnan() == True')

                # Append targets to text file
                # with open('targets.txt', 'a') as file:
                #     [file.write('%11.5g ' * 4 % tuple(x) + '\n') for x in torch.cat((txy[i], twh[i]), 1)]

            pobj = pi[..., 4]
            if self.h.get('pn_obj', 1) == 1:
                obji = self.BCEobj(pobj, tobj)
            else:#self.h['max_obj']默认256，dota1.5这种数据集里面最大目标数量可能超过256爆仓
                # 计算 tobj > 0 的损失
                # 创建一个等于0的掩码，只有一定比例的元素为True
                mask = torch.rand_like(tobj) < self.h.get('pn_obj', 1)  # mask_ratio 是你要保留的比例
                mask_obj,mask_noobj = tobj > 0, (tobj == 0) & mask
                objp_scale = self.h.get('objp_scale', 0.05) #((mask_obj.sum() + mask_noobj.sum()) / tobj.numel()).detach()
                objp_loss = self.BCEobj(pobj[mask_obj], tobj[mask_obj])
                objn_loss = self.BCEobj(pobj[mask_noobj], tobj[mask_noobj])
                obji = objp_scale * objp_loss + objn_loss

            lobj += obji * self.balance[i]  # obj loss
            #det1 = tobj - pi[..., 4]
            #lobj2 = self.MseLoss(pi2[..., 4], det1)
            if self.autobalance: #多个不同尺度直接的学习因子平衡
                self.balance[i] = self.balance[i] * 0.9999 + 0.0001 / obji.detach().item()

        if self.autobalance:
            self.balance = [x / self.balance[self.ssi] for x in self.balance]
        lbox *= self.hyp['box']
        lobj *= self.hyp['obj']
        lcls *= self.hyp['cls']
        bs = tobj.shape[0]  # batch size

        return (lbox + lobj + lcls) * bs, torch.cat((lbox, lobj, lcls)).detach()

    def call_dfl(self, preds, targets, imgsz, **kwds):
        """Calculate the sum of the loss for box, cls and dfl multiplied by batch size."""
        # pred_distri, pred_scores, _ = preds
        feats = preds[1] if isinstance(preds, tuple) else preds #feats[3][B,80=16*4(ltrb)+cls,H,W]
        pred_distri, pred_scores = torch.cat([xi.view(feats[0].shape[0], feats[0].shape[1], -1) for xi in feats], 2).split(
            (self.reg_max * 4, self.nc), 1
        )#feats[3][B,80=16*4(ltrb)+cls,H,W] -> pred_distri[b,64=16*4(ltrb),ntotal] + pred_scores[b,cls,ntotal]  ntotal=20*20+40*40+80*80

        pred_scores = pred_scores.permute(0, 2, 1).contiguous() #pred_scores[b,cls,ntotal]->pred_scores[b,ntotal,cls]
        pred_distri = pred_distri.permute(0, 2, 1).contiguous() #pred_distri[b,64=16*4(ltrb),ntotal]->pred_distri[b,ntotal,64=16*4(ltrb)]
        device = pred_scores.device
        dtype = pred_scores.dtype
        batch_size = pred_scores.shape[0]
        loss = torch.zeros(3, device=device)  # lbox, lcls, ldfl        
        anchor_points, stride_tensor = self.make_anchors(imgsz, self.strides, dtype, device, 0.5)# self.mdetect.anchor_points, self.mdetect.stride_tensor #anchor_points[ntotal,2]  stride_tensor[ntotal,1]
        imgsz = torch.tensor(imgsz, dtype=dtype, device=device)  # image size (h,w)

        # Targets
        # targets = torch.cat((batch["batch_idx"].view(-1, 1), batch["cls"].view(-1, 1), batch["bboxes"]), 1) #targets[nt,6=1(b)+1(cls)+4(xywh)]
        targets = self.preprocess_dfl(targets.to(device), batch_size, scale_tensor=imgsz[[1, 0, 1, 0]], device=device) #->targets[b,nt,5=1(cls)+4(xyxy)]
        gt_labels, gt_bboxes = targets.split((1, 4), 2)  # gt_labels[b,nt,1(cls)], gt_bboxes[b,nt,4(xyxy)]
        mask_gt = gt_bboxes.sum(2, keepdim=True).gt_(0.0) #mask_gt[b,nt,1] pad 0 at end

        # Pboxes
        pred_bboxes = dist2bbox(self.bbox_decode(pred_distri), anchor_points, xywh=False) #anchor_points[ntotal,2] + pred_distri[b,ntotal,16(ng)*4(ltrb)] -> pred_bboxes[b, ntotal, 4(xyxy)]
        # dfl_conf = pred_distri.view(batch_size, -1, 4, self.reg_max).detach().softmax(-1)
        # dfl_conf = (dfl_conf.amax(-1).mean(-1) + dfl_conf.amax(-1).amin(-1)) / 2

        _, target_bboxes, target_scores, fg_mask, _ = self.assigner(
            # pred_scores.detach().sigmoid() * 0.8 + dfl_conf.unsqueeze(-1) * 0.2,
            pred_scores.detach().sigmoid(), #pred_scores[b,ntotal,cls=16)]
            (pred_bboxes.detach() * stride_tensor).type(gt_bboxes.dtype), #pred_bboxes[b, ntotal, 4(xyxy)]
            anchor_points * stride_tensor, #anchor_points[ntotal,2]*stride_tensor[ntotal,1]->[ntotal,2]  anchor_coords*stride->pixel coords
            gt_labels, #gt_labels[b,nt,1(cls)]
            gt_bboxes, #mask_gt[b,nt,4(xyxy)]
            mask_gt, #mask_gt[b,nt,1]  pad 0 at end of mask_gt
        ) #->target_bboxes[b,ntotal,4(xyxy)] target_scores[b,ntotal,cls] fg_mask[b,ntotal]  target_gt_idx[b,ntotal]

        target_scores_sum = max(target_scores.sum(), 1) #target_scores[b,ntotal,cls]

        # Cls loss
        # loss[1] = self.varifocal_loss(pred_scores, target_scores, target_labels) / target_scores_sum  # VFL way
        loss[1] = self.bce(pred_scores, target_scores.to(dtype)).sum() / target_scores_sum #pred_scores[b,ntotal,cls] ~ target_scores[b,ntotal,cls]

        # Bbox loss
        if fg_mask.sum():
            target_bboxes /= stride_tensor #target_bboxes[b,ntotal,4(xyxy)] / stride_tensor[ntotal,1] -> target_bboxes[b,ntotal,4(xyxy)] grid coords
            loss[0], loss[2] = self.bbox_loss(
                pred_distri, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask
            )
            # weight = target_scores.sum(-1)[fg_mask].unsqueeze(-1)
            # iou = bbox_iou(pred_bboxes[fg_mask], target_bboxes[fg_mask], xywh=False, CIoU=True)
            # target_ltrb = self.bbox2dist(anchor_points, target_bboxes)
            # loss[0] = ((1.0 - iou) * weight).sum() / target_scores_sum
            # loss[2] = (self.dfl_loss(pred_distri, target_ltrb, fg_mask) * weight).sum() / target_scores_sum
            # loss[0], loss[2] = self.bbox_loss(
            #     pred_distri, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask
            # )#pred_distri[B,ntotal,64=16*4(ltrb)] pred_bboxes[B,ntotal,4(ltrb)]  anchor_points[ntotal,2] target_bboxes[b,ntotal,4] target_scores[b,ntotal,cls] fg_mask[b,ntotal]
        # torch.cuda.empty_cache()
        loss[0] *= self.hyp['box']  # box gain
        loss[1] *= self.hyp['cls']  # cls gain
        loss[2] *= self.hyp.get('dfl', 0.01)  # dfl gain

        return loss.sum() * batch_size, loss.detach()  # loss(box, cls, dfl)

    def call_ft(self, preds, targets, imgsz, **kwds): #targets[nt,1(b)+1(cls)+4(box)+2+4n]
        """Calculate the sum of the loss for box, cls and dfl multiplied by batch size."""
        # pred_distri, pred_scores, _ = preds
        
        feats, pred_ft = preds if isinstance(preds[0], list) else preds[2]
        pred_distri, pred_scores = torch.cat([xi.view(feats[0].shape[0], feats[0].shape[1], -1) for xi in feats], 2).split(
            (self.reg_max * 4, self.nc), 1
        )#feats[3][B,80=16*4(ltrb)+cls,H,W] -> pred_distri[b,64=16*4(ltrb),ntotal] + pred_scores[b,cls,ntotal]  ntotal=20*20+40*40+80*80
        #pred_ft[b,672=?,ntotal]

        pred_scores = pred_scores.permute(0, 2, 1).contiguous() #pred_scores[b,cls,ntotal]->pred_scores[b,ntotal,cls]
        pred_distri = pred_distri.permute(0, 2, 1).contiguous() #pred_distri[b,64=16*4(ltrb),ntotal]->pred_distri[b,ntotal,64=16*4(ltrb)]
        pred_ft = pred_ft.permute(0, 2, 1).contiguous()  # p, q, abc, xyz [b, ntotal, ne=reg_max(2+nf*4)]

        device = pred_scores.device
        dtype = pred_scores.dtype
        batch_size = pred_scores.shape[0]
        loss = torch.zeros(len(self.tags) - 4, device=device)  # lbox, lcls, ldfl, lpab, ldir, labc, lxy, lz
        anchor_points, stride_tensor = self.make_anchors(imgsz, self.strides, dtype, device, 0.5)# self.mdetect.anchor_points, self.mdetect.stride_tensor #anchor_points[ntotal,2]  stride_tensor[ntotal,1]
        imgsz = torch.tensor(imgsz, dtype=dtype, device=device)  # image size (h,w)

        # Targets
        # targets = torch.cat((batch["batch_idx"].view(-1, 1), batch["cls"].view(-1, 1), batch["bboxes"]), 1) #targets[nt,6=1(b)+1(cls)+4(xywh)]
        targets = self.preprocess_dfl(targets.to(device), batch_size, scale_tensor=imgsz[[1, 0, 1, 0]], device=device) #->targets[b,nt,5=1(cls)+4(xyxy)]
        gt_labels, gt_bboxes = targets.split((1, targets.shape[-1] - 1), 2)  # gt_labels[b,nt,1(cls)], gt_bboxes[b,nt,4(xyxy)]
        mask_gt = gt_bboxes.sum(2, keepdim=True).gt_(0.0) #mask_gt[b,nt,1] pad 0 at end

        # Pboxes
        pred_bboxes = dist2bbox(self.bbox_decode(pred_distri), anchor_points, xywh=False) #anchor_points[ntotal,2] + pred_distri[b,ntotal,16(ng)*4(ltrb)] -> pred_bboxes[b, ntotal, 4(xyxy)]
        # dfl_conf = pred_distri.view(batch_size, -1, 4, self.reg_max).detach().softmax(-1)
        # dfl_conf = (dfl_conf.amax(-1).mean(-1) + dfl_conf.amax(-1).amin(-1)) / 2

        _, target_bboxes, target_scores, fg_mask, target_gt_idx = self.assigner(
            # pred_scores.detach().sigmoid() * 0.8 + dfl_conf.unsqueeze(-1) * 0.2,
            pred_scores.detach().sigmoid(), #pred_scores[b,ntotal,cls=16)]
            (pred_bboxes.detach() * stride_tensor).type(gt_bboxes.dtype), #pred_bboxes[b, ntotal, 4(xyxy)]
            anchor_points * stride_tensor, #anchor_points[ntotal,2]*stride_tensor[ntotal,1]->[ntotal,2]  anchor_coords*stride->pixel coords
            gt_labels, #gt_labels[b,nt,1(cls)]
            gt_bboxes, #mask_gt[b,nt,2+nf*4]
            mask_gt, #mask_gt[b,nt,1]  pad 0 at end of mask_gt
        ) #->target_bboxes[b,ntotal,4(xyxy)+2+nf*4] target_scores[b,ntotal,cls] fg_mask[b,ntotal]  target_gt_idx[b,ntotal]

        target_scores_sum = max(target_scores.sum(), 1) #target_scores[b,ntotal,cls]
        # target_bboxes [b, ntotal, 4(xyxy)+2+nf*4]
        # target_bboxes [b, ntotal, 4(xyxy)+2+nf*4] --> target_bboxes [b, ntotal, 4(xyxy)] + tft [b, ntotal, 2+nf*4]
        target_bboxes, tft = torch.split(target_bboxes, [4, self.ft_coef_length], dim=-1)
        
        # Cls loss
        # loss[1] = self.varifocal_loss(pred_scores, target_scores, target_labels) / target_scores_sum  # VFL way
        loss[1] = self.bce(pred_scores, target_scores.to(dtype)).sum() / target_scores_sum #pred_scores[b,ntotal,cls] ~ target_scores[b,ntotal,cls]

        # Bbox loss
        if fg_mask.sum():
            if self.mask_line is not None:
                target_gt_cls = torch.gather(gt_labels.squeeze(-1), 1, target_gt_idx)[fg_mask]  # [fg_mask]
                mask_line = torch.gather(self.mask_line, 0, target_gt_cls.long()).bool()
            else:
                mask_line = None
            target_bboxes /= stride_tensor #target_bboxes[b,ntotal,4(xyxy)] / stride_tensor[ntotal,1] -> target_bboxes[b,ntotal,4(xyxy)] grid coords
            loss[0], loss[2] = self.bbox_loss(
                pred_distri, self.proj, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask
            )
            
            loss[3], loss[4], loss[5] = self.ft_loss(#pred_ft[b,ntotal,reg_max(2+nf*4)] proj_ft[2+nf*4,reg_max] anchor_points[ntotal,2] tft[b,ntotal,2+nf*4] target_scores[b,ntotal,nc] fg_mask[b,ntotal]
                pred_ft, self.proj_ft, anchor_points, tft, target_scores, target_scores_sum, fg_mask, stride_tensor, imgsz, mask_line, self.ft_cgm,
                img=kwds.get('img', None) #, ft_gain=None
            )
            # weight = target_scores.sum(-1)[fg_mask].unsqueeze(-1)
            # iou = bbox_iou(pred_bboxes[fg_mask], target_bboxes[fg_mask], xywh=False, CIoU=True)
            # target_ltrb = self.bbox2dist(anchor_points, target_bboxes)
            # loss[0] = ((1.0 - iou) * weight).sum() / target_scores_sum
            # loss[2] = (self.dfl_loss(pred_distri, target_ltrb, fg_mask) * weight).sum() / target_scores_sum
            # loss[0], loss[2] = self.bbox_loss(
            #     pred_distri, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask
            # )#pred_distri[B,ntotal,64=16*4(ltrb)] pred_bboxes[B,ntotal,4(ltrb)]  anchor_points[ntotal,2] target_bboxes[b,ntotal,4] target_scores[b,ntotal,cls] fg_mask[b,ntotal]
        # torch.cuda.empty_cache()
        loss[0] *= self.hyp['box']  # box gain
        loss[1] *= self.hyp['cls']  # cls gain
        loss[2] *= self.hyp.get('dfl', 0.01)  # dfl gain
        loss[3] *= self.hyp.get('ftxy', 0.02)  # ftxy gain
        loss[4] *= self.hyp.get('ftcoef', 0.01) # ftcoef gain
        if self.ft_loss.GNF == 0:
            loss[5] *= self.hyp.get('ftdfl', 0.01)  # ftdfl gain
        else:
            assert loss[5]==0

        return loss.sum() * batch_size, loss.detach()  # loss(box, cls, dfl)

    def build_targets(self, p, targets):
        # p[list][b,a,gy,gx,4+1+cls]
        # targets[nt,6=(1(b)+1(cls)+4(box)]
        # targets = targets[max(targets[:, 4],targets[:, 5]).max(1)[0] > 0.01]
        # Build targets for compute_loss(), input targets(image,class,x,y,w,h)
        na, nt = self.na, targets.shape[0]  # number of anchors, targets
        tcls, tbox, indices, anch = [], [], [], []
        gain = torch.ones(7, device=targets.device)  # normalized to gridspace gain
        # gain[7] = {1,1,1,1,1,1,1}
        ai = torch.arange(na, device=targets.device).float().view(na, 1).repeat(1, nt)  # same as .repeat_interleave(nt)
        # ai[na,nt]
        targets = torch.cat((targets.repeat(na, 1, 1), ai[:, :, None]), 2)  # append anchor indices
        # targets[na,nt,7=(1(b)+1(cls)+4(box)+1(anchor))]

        g = 0.5  # bias
        off = torch.tensor([[0, 0],
                            [1, 0], [0, 1], [-1, 0], [0, -1],  # j,k,l,m
                            # [1, 1], [1, -1], [-1, 1], [-1, -1],  # jk,jm,lk,lm
                            ], device=targets.device).float() * g  # offsets
        # off[5,2]

        for i in range(self.nl):
            shape = p[i].shape
            # anchors[3,na,2]
            anchors = self.anchors[i]
            # anchors[na,2]
            # p[i][b,a,gy,gx,4+1+cls]
            gain[2:6] = torch.tensor(p[i].shape)[[3, 2, 3, 2]]  # xyxy gain
            # gain[7=(1(b)+1(cls)+4(box)+1(anchor))] = {1,1,gx,gy,gx,gy,1}

            # Match targets to anchors
            t = targets * gain
            # t[na,nt,7=(1(b)+1(cls)+4(box)+1(anchor))]
            if nt:
                # Matches
                # t[:, :, 4:6]的shape是    t      [na,nt,2]
                # anchors[:, None]的shape是anchors[na, ?,2]  得到?=nt
                #                                [na,nt,2]
                r = t[:, :, 4:6] / anchors[:, None]  # wh ratio
                # r[na,nt,2] / anchors[na,?,2] = r[na,nt,2]

                # r1 = torch.max(r, 1. / r)的shape是r1[na,nt,2]
                # r1.max(2)意思是[r和1/r]在编号(2)的维度找最大值[0]，求最大值后会把维度2去掉,shape变为[na,nt]
                # 得到r1.max(2)[0]是shape为[na,nt]的最大值
                # 得到r1.max(2)[1]是shape为[na,nt]的最大值对应的整数编号{0,1}
                j = torch.max(r, 1. / r).max(2)[0] < self.hyp['anchor_t']  # compare
                # 意思是[r和1/r]在编号(2)的维度找最大值[0],求最大值后会把维度2去掉，j的shape为[na,nt]的bool数组
                # r, 1. / r两者最大值都比较小，说明接近1，说明和相应anchor比较匹配

                # j = wh_iou(anchors, t[:, 4:6]) > model.hyp['iou_t']  # iou(3,n)=wh_iou(anchors(3,2), gwh(n,2))
                # j[na, nt]
                # t[na, nt, 7 = (1(b) + 1(cls) + 4(box) + 1(anchor))]
                t = t[j]  # filter
                # t[n_match_obj,7=(1(b)+1(cls)+4(box)+1(anchor))]

                # Offsets
                gxy = t[:, 2:4]  # grid xy
                # gxy[n_match_obj,2=(xy)]
                gxi = gain[[2, 3]] - gxy  # inverse
                # gxi[n_match_obj,2=(xy)]
                j, k = ((gxy % 1. < g) & (gxy > 1.)).T #j[n_match_obj], k[n_match_obj]
                l, m = ((gxi % 1. < g) & (gxi > 1.)).T #l[n_match_obj], m[n_match_obj]
                # j,k,l,m的shape全是[n_match_obj]
                j = torch.stack((torch.ones_like(j), j, k, l, m)) #j[5,n_match_obj]
                # j[5,n_match_obj] [第1行全1/目标中心x接近下限神经元j/目标中心y接近下限神经元k/目标中心x接近上限神经元l/目标中心y接近上限神经元m]
                # t.repeat((5, 1, 1))的shape是[5,n_match_obj,7 = (1(b) + 1(cls) + 4(box) + 1(anchor))]
                t = t.repeat((5, 1, 1))[j]
                # t[n_match_obj*3,7]  目标第1行全1，[目标x要么接近下限x，要么接近上限x],[目标y要么接近下限y，要么接近上限y],因此只有可能是选择3倍

                # gxy[n_match_obj, 2 = (xy)]
                # torch.zeros_like(gxy)[None]的shape是[?, n_match_obj, 2 = (xy)]
                # off[5,2]
                # off[:, None]的shape是[5, ?, 2]
                # [?1, n_match_obj, 2]和
                # [ 5,          ?2, 2]
                # 要能在一起计算，只有?1=5, ?2=n_match_obj  最终得到的shape是
                # [ 5, n_match_obj, 2]
                #得到(torch.zeros_like(gxy)[None] + off[:, None])的shape是[5, n_match_obj, 2]
                offsets = (torch.zeros_like(gxy)[None] + off[:, None])[j]
                #[5, n_match_obj, 2]经过j[5,n_match_obj]过滤得到offsets[n_match_obj * 3, 2]
                #相当于把n_match_obj*5的组合全部遍历了一遍,选择其中n_match_obj*3的就近的网格偏移
            else:
                t = targets[0] #targets[na=3,nt=0,7=(1(b)+1(cls)+4(box)+1(anchor))]->t[nt=0,7]
                offsets = 0

            # Define
            # t[:, :2]的shape是[3*n_match_obj,2]
            b, c = t[:, :2].long().T  # image, class
            # b[3*n_match_obj]  c[3*n_match_obj]
            # t[:, 2:4]的shape是[3*n_match_obj,2]
            gxy = t[:, 2:4]  # grid xy
            # gxy[3*n_match_obj,2]   得到3*n_match_obj个gxy网格(xy坐标复制了3倍)
            gwh = t[:, 4:6]  # grid wh
            # gwh[3*n_match_obj,2]   得到3*n_match_obj个gwh网格(wh坐标复制了3倍)
            gij = (gxy - offsets).long()
            # gij[3*n_match_obj,2]   得到3*n_match_obj个就近网格
            gi, gj = gij.T  # grid xy indices
            # gi[3*n_match_obj]  gj[3*n_match_obj]

            # Append
            a = t[:, 6].long()  # anchor indices
            # a[3*n_match_obj]
            indices.append((b, a, gj.clamp_(0, shape[2] - 1), gi.clamp_(0, shape[3] - 1)))  # image, anchor, grid indices
            tbox.append(torch.cat((gxy - gij, gwh), 1))  # box
            # gxy - gij才是网络真正要拟合的相对偏移！
            # anchors[3,2]   a[3*n_match_obj]
            # anchors[a] shape是[3*n_match_obj,2]
            anch.append(anchors[a])  # anchors
            tcls.append(c)  # class

        return tcls, tbox, indices, anch

    def call_ft_statistics(self, preds, targets, imgsz, **kwds):
        """Calculate the sum of the loss for box, cls and dfl multiplied by batch size."""
        # pred_distri, pred_scores, _ = preds
        
        feats, pred_ft = preds if isinstance(preds[0], list) else preds[2]
        pred_distri, pred_scores = torch.cat([xi.view(feats[0].shape[0], feats[0].shape[1], -1) for xi in feats], 2).split(
            (self.reg_max * 4, self.nc), 1
        )#feats[3][B,80=16*4(ltrb)+cls,H,W] -> pred_distri[b,64=16*4(ltrb),ntotal] + pred_scores[b,cls,ntotal]  ntotal=20*20+40*40+80*80
        #pred_ft[b,672=?,ntotal]

        pred_scores = pred_scores.permute(0, 2, 1).contiguous() #pred_scores[b,cls,ntotal]->pred_scores[b,ntotal,cls]
        pred_distri = pred_distri.permute(0, 2, 1).contiguous() #pred_distri[b,64=16*4(ltrb),ntotal]->pred_distri[b,ntotal,64=16*4(ltrb)]
        pred_ft = pred_ft.permute(0, 2, 1).contiguous()  # p, q, abc, xyz [b, ntotal, ne=reg_max(2+nf*4)]

        device = pred_scores.device
        dtype = pred_scores.dtype
        batch_size = pred_scores.shape[0]
        loss = torch.zeros(len(self.tags) - 4, device=device)  # lbox, lcls, ldfl, lpab, ldir, labc, lxy, lz
        anchor_points, stride_tensor = self.make_anchors(imgsz, self.strides, dtype, device, 0.5)# self.mdetect.anchor_points, self.mdetect.stride_tensor #anchor_points[ntotal,2]  stride_tensor[ntotal,1]
        imgsz = torch.tensor(imgsz, dtype=dtype, device=device)  # image size (h,w)

        # Targets
        # targets = torch.cat((batch["batch_idx"].view(-1, 1), batch["cls"].view(-1, 1), batch["bboxes"]), 1) #targets[nt,6=1(b)+1(cls)+4(xywh)]
        targets = self.preprocess_dfl(targets.to(device), batch_size, scale_tensor=imgsz[[1, 0, 1, 0]], device=device) #->targets[b,nt,5=1(cls)+4(xyxy)]
        gt_labels, gt_bboxes = targets.split((1, targets.shape[-1] - 1), 2)  # gt_labels[b,nt,1(cls)], gt_bboxes[b,nt,4(xyxy)]
        mask_gt = gt_bboxes.sum(2, keepdim=True).gt_(0.0) #mask_gt[b,nt,1] pad 0 at end

        # Pboxes
        pred_bboxes = dist2bbox(self.bbox_decode(pred_distri), anchor_points, xywh=False) #anchor_points[ntotal,2] + pred_distri[b,ntotal,16(ng)*4(ltrb)] -> pred_bboxes[b, ntotal, 4(xyxy)]
        # dfl_conf = pred_distri.view(batch_size, -1, 4, self.reg_max).detach().softmax(-1)
        # dfl_conf = (dfl_conf.amax(-1).mean(-1) + dfl_conf.amax(-1).amin(-1)) / 2

        _, target_bboxes, target_scores, fg_mask, _ = self.assigner(
            # pred_scores.detach().sigmoid() * 0.8 + dfl_conf.unsqueeze(-1) * 0.2,
            pred_scores.detach().sigmoid(), #pred_scores[b,ntotal,cls=16)]
            (pred_bboxes.detach() * stride_tensor).type(gt_bboxes.dtype), #pred_bboxes[b, ntotal, 4(xyxy)]
            anchor_points * stride_tensor, #anchor_points[ntotal,2]*stride_tensor[ntotal,1]->[ntotal,2]  anchor_coords*stride->pixel coords
            gt_labels, #gt_labels[b,nt,1(cls)]
            gt_bboxes, #mask_gt[b,nt,4(xyxy)]
            mask_gt, #mask_gt[b,nt,1]  pad 0 at end of mask_gt
        ) #->target_bboxes[b,ntotal,4(xyxy)+2+nf*4] target_scores[b,ntotal,cls] fg_mask[b,ntotal]  target_gt_idx[b,ntotal]

        target_scores_sum = max(target_scores.sum(), 1) #target_scores[b,ntotal,cls]
        # target_bboxes [b, ntotal, 4(xyxy)+2+nf*4]
        # target_bboxes [b, ntotal, 4(xyxy)+2+nf*4] --> target_bboxes [b, ntotal, 4(xyxy)] + tft [b, ntotal, 2+nf*4]
        target_bboxes, tft = torch.split(target_bboxes, [4, self.ft_coef_length], dim=-1)
        
        # Cls loss
        # loss[1] = self.varifocal_loss(pred_scores, target_scores, target_labels) / target_scores_sum  # VFL way
        loss[1] = self.bce(pred_scores, target_scores.to(dtype)).sum() / target_scores_sum #pred_scores[b,ntotal,cls] ~ target_scores[b,ntotal,cls]

        # Bbox loss
        if fg_mask.sum():
            target_bboxes /= stride_tensor #target_bboxes[b,ntotal,4(xyxy)] / stride_tensor[ntotal,1] -> target_bboxes[b,ntotal,4(xyxy)] grid coords
            loss[0], loss[2] = self.bbox_loss(
                pred_distri, self.proj, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask
            )
            loss[3], loss[4], loss[5], target_ft_stat = self.ft_loss(#pred_ft[b,ntotal,reg_max(2+nf*4)] proj_ft[2+nf*4,reg_max] anchor_points[ntotal,2] tft[b,ntotal,2+nf*4] target_scores[b,ntotal,nc] fg_mask[b,ntotal]
                pred_ft, self.proj_ft, anchor_points, tft, target_scores, target_scores_sum, fg_mask, stride_tensor, imgsz
            )
            # weight = target_scores.sum(-1)[fg_mask].unsqueeze(-1)
            # iou = bbox_iou(pred_bboxes[fg_mask], target_bboxes[fg_mask], xywh=False, CIoU=True)
            # target_ltrb = self.bbox2dist(anchor_points, target_bboxes)
            # loss[0] = ((1.0 - iou) * weight).sum() / target_scores_sum
            # loss[2] = (self.dfl_loss(pred_distri, target_ltrb, fg_mask) * weight).sum() / target_scores_sum
            # loss[0], loss[2] = self.bbox_loss(
            #     pred_distri, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask
            # )#pred_distri[B,ntotal,64=16*4(ltrb)] pred_bboxes[B,ntotal,4(ltrb)]  anchor_points[ntotal,2] target_bboxes[b,ntotal,4] target_scores[b,ntotal,cls] fg_mask[b,ntotal]
        # torch.cuda.empty_cache()
        else:
            target_ft_stat = torch.zeros([0, self.ft_coef_length], dtype=pred_scores.dtype, device=pred_scores.device)
        loss[0] *= self.hyp['box']  # box gain
        loss[1] *= self.hyp['cls']  # cls gain
        loss[2] *= self.hyp.get('dfl', 0.01)  # dfl gain
        loss[3] *= self.hyp.get('ftxy', 0.02)  # ftxy gain
        loss[4] *= self.hyp.get('ftcoef', 0.01) # ftcoef gain
        loss[5] *= self.hyp.get('ftdfl', 0.01)  # ftdfl gain

        return loss.sum() * batch_size, loss.detach(), target_ft_stat  # loss(box, cls, dfl)

    def call_ft_statistics_nomodel(self, preds, targets, imgsz, **kwds):
        """Calculate the sum of the loss for box, cls and dfl multiplied by batch size."""
        # pred_distri, pred_scores, _ = preds
        
        feats, pred_ft = preds if isinstance(preds[0], list) else preds[2]
        pred_distri, pred_scores = torch.cat([xi.view(feats[0].shape[0], feats[0].shape[1], -1) for xi in feats], 2).split(
            (self.reg_max * 4, self.nc), 1
        )#feats[3][B,80=16*4(ltrb)+cls,H,W] -> pred_distri[b,64=16*4(ltrb),ntotal] + pred_scores[b,cls,ntotal]  ntotal=20*20+40*40+80*80
        #pred_ft[b,672=?,ntotal]

        pred_scores = pred_scores.permute(0, 2, 1).contiguous() #pred_scores[b,cls,ntotal]->pred_scores[b,ntotal,cls]
        pred_distri = pred_distri.permute(0, 2, 1).contiguous() #pred_distri[b,64=16*4(ltrb),ntotal]->pred_distri[b,ntotal,64=16*4(ltrb)]
        pred_ft = pred_ft.permute(0, 2, 1).contiguous()  # p, q, abc, xyz [b, ntotal, ne=reg_max(2+nf*4)]

        device = pred_scores.device
        dtype = pred_scores.dtype
        batch_size = pred_scores.shape[0]
        loss = torch.zeros(len(self.tags) - 4, device=device)  # lbox, lcls, ldfl, lpab, ldir, labc, lxy, lz
        anchor_points, stride_tensor = self.make_anchors(imgsz, self.strides, dtype, device, 0.5)# self.mdetect.anchor_points, self.mdetect.stride_tensor #anchor_points[ntotal,2]  stride_tensor[ntotal,1]
        imgsz = torch.tensor(imgsz, dtype=dtype, device=device)  # image size (h,w)

        # Targets
        # targets = torch.cat((batch["batch_idx"].view(-1, 1), batch["cls"].view(-1, 1), batch["bboxes"]), 1) #targets[nt,6=1(b)+1(cls)+4(xywh)]
        targets = self.preprocess_dfl(targets.to(device), batch_size, scale_tensor=imgsz[[1, 0, 1, 0]], device=device) #->targets[b,nt,5=1(cls)+4(xyxy)]
        gt_labels, gt_bboxes = targets.split((1, targets.shape[-1] - 1), 2)  # gt_labels[b,nt,1(cls)], gt_bboxes[b,nt,4(xyxy)]
        mask_gt = gt_bboxes.sum(2, keepdim=True).gt_(0.0) #mask_gt[b,nt,1] pad 0 at end

        # Pboxes
        # pred_bboxes = dist2bbox(self.bbox_decode(pred_distri), anchor_points, xywh=False) #anchor_points[ntotal,2] + pred_distri[b,ntotal,16(ng)*4(ltrb)] -> pred_bboxes[b, ntotal, 4(xyxy)]
        max_value = 16
        if 0:
            anchor_bias = torch.rand(pred_distri.shape[0], pred_distri.shape[1], 4, device=device) * max_value  # [bs, ntotal, 4]
        else:
            anchor_bias = torch.abs(generate_anchor_bias((pred_distri.shape[0], pred_distri.shape[1], 4),max_value,percentile=0.97, device=device))
        anchor_points_fake = anchor_points.repeat(pred_distri.shape[0], 1, 1)  # [bs, ntotal, 2]
        pred_bboxes = torch.cat([anchor_points_fake - anchor_bias[..., :2], anchor_points + anchor_bias[..., 2:]], dim=-1) # 网格左上右下
        pred_scores[:] = 5.0    # sigmoid(5) = 0.993307
        # dfl_conf = pred_distri.view(batch_size, -1, 4, self.reg_max).detach().softmax(-1)
        # dfl_conf = (dfl_conf.amax(-1).mean(-1) + dfl_conf.amax(-1).amin(-1)) / 2

        _, target_bboxes, target_scores, fg_mask, _ = self.assigner(
            # pred_scores.detach().sigmoid() * 0.8 + dfl_conf.unsqueeze(-1) * 0.2,
            pred_scores.detach().sigmoid(), #pred_scores[b,ntotal,cls=16)]
            (pred_bboxes.detach() * stride_tensor).type(gt_bboxes.dtype), #pred_bboxes[b, ntotal, 4(xyxy)]
            anchor_points * stride_tensor, #anchor_points[ntotal,2]*stride_tensor[ntotal,1]->[ntotal,2]  anchor_coords*stride->pixel coords
            gt_labels, #gt_labels[b,nt,1(cls)]
            gt_bboxes, #mask_gt[b,nt,4(xyxy)]
            mask_gt, #mask_gt[b,nt,1]  pad 0 at end of mask_gt
        ) #->target_bboxes[b,ntotal,4(xyxy)+2+nf*4] target_scores[b,ntotal,cls] fg_mask[b,ntotal]  target_gt_idx[b,ntotal]

        target_scores_sum = max(target_scores.sum(), 1) #target_scores[b,ntotal,cls]
        # target_bboxes [b, ntotal, 4(xyxy)+2+nf*4]
        # target_bboxes [b, ntotal, 4(xyxy)+2+nf*4] --> target_bboxes [b, ntotal, 4(xyxy)] + tft [b, ntotal, 2+nf*4]
        target_bboxes, tft = torch.split(target_bboxes, [4, self.ft_coef_length], dim=-1)
        
        # Cls loss
        # loss[1] = self.varifocal_loss(pred_scores, target_scores, target_labels) / target_scores_sum  # VFL way
        # Bbox loss
        if fg_mask.sum():
            target_bboxes /= stride_tensor #target_bboxes[b,ntotal,4(xyxy)] / stride_tensor[ntotal,1] -> target_bboxes[b,ntotal,4(xyxy)] grid coords
            loss[0], loss[2] = self.bbox_loss(
                pred_distri, self.proj, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask
            )
            target_ft_stat = self.ft_loss(#pred_ft[b,ntotal,reg_max(2+nf*4)] proj_ft[2+nf*4,reg_max] anchor_points[ntotal,2] tft[b,ntotal,2+nf*4] target_scores[b,ntotal,nc] fg_mask[b,ntotal]
                pred_ft, self.proj_ft, anchor_points, tft, target_scores, target_scores_sum, fg_mask, stride_tensor, imgsz
            )
        else:
            target_ft_stat = torch.zeros([0, self.ft_coef_length], dtype=pred_scores.dtype, device=pred_scores.device)

        return target_ft_stat  # loss(box, cls, dfl)

    def preprocess_dfl(self, targets, batch_size, scale_tensor, device):
        """Preprocesses the target counts and matches with the input batch size to output a tensor."""
        nl, ne = targets.shape
        if nl == 0:
            out = torch.zeros(batch_size, 0, ne - 1, device=device)
        else:
            targets_wh = targets[:, 4:6].prod(-1).argsort(-1)
            targets = targets[targets_wh.long()]
            i = targets[:, 0]  # image index
            _, counts = i.unique(return_counts=True)
            counts = counts.to(dtype=torch.int32)
            out = torch.zeros(batch_size, counts.max(), ne - 1, device=device)
            for j in range(batch_size):
                matches = i == j
                n = matches.sum()
                if n:
                    out[j, :n] = targets[matches, 1:]
            out[..., 1:5] = xywh2xyxy(out[..., 1:5].mul_(scale_tensor))
        return out
    
    def make_anchors(self, hw, strides, dtype, device, grid_cell_offset=0.5):
        """Generate anchors from features."""
        anchor_points, stride_tensor = [], []
        # dtype, device = feats[0].dtype, feats[0].device
        ho, wo = hw
        for i, stride in enumerate(strides):
            # _, _, h, w = feats[i].shape
            h = torch.div(ho, stride, rounding_mode='trunc') #ho // stride
            w = torch.div(wo, stride, rounding_mode='trunc') #wo // stride
            sx = torch.arange(end=w, device=device, dtype=dtype) + grid_cell_offset  # shift x
            sy = torch.arange(end=h, device=device, dtype=dtype) + grid_cell_offset  # shift y
            if check_version(torch.__version__, '1.10.0'):  # torch>=1.10.0 meshgrid workaround for torch>=0.7 compatibility
                sy, sx = torch.meshgrid(sy, sx, indexing='ij')
            else:
                sy, sx = torch.meshgrid(sy, sx)
            anchor_points.append(torch.stack((sx, sy), -1).view(-1, 2))
            stride_tensor.append(torch.full((h * w, 1), stride, dtype=dtype, device=device))
        return torch.cat(anchor_points), torch.cat(stride_tensor)
    
    def bbox_decode(self, pred_dist):
        """Decode predicted object bounding box coordinates from anchor points and distribution."""
        b, a, c = pred_dist.shape  # batch, anchors, channels
        pred_dist = pred_dist.view(b, a, 4, c // 4).softmax(3).matmul(self.proj.type(pred_dist.dtype))
        # pred_dist = pred_dist.view(b, a, c // 4, 4).transpose(2,3).softmax(3).matmul(self.proj.type(pred_dist.dtype))
        # pred_dist = (pred_dist.view(b, a, c // 4, 4).softmax(2) * self.proj.type(pred_dist.dtype).view(1, 1, -1, 1)).sum(2)
        return pred_dist
    
    def reset_plot(self):
        self.ft_loss.debug_samples = self.debug_samples

class BboxLoss(nn.Module):
    """Criterion class for computing training losses during training."""

    def __init__(self, reg_max=16, key_loss=False):
        """Initialize the BboxLoss module with regularization maximum and DFL settings."""
        super().__init__()
        self.key_loss = key_loss
        self.reg_max = reg_max
        if self.key_loss:
            self.dfl_loss = self._dfl_loss
        else:
            self.dfl_loss = DFLoss(reg_max) if reg_max > 1 else None


    def forward(self, pred_dist, proj, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask):
        """IoU loss."""
        weight = target_scores.sum(-1)[fg_mask].unsqueeze(-1)
        iou = bbox_iou(pred_bboxes[fg_mask], target_bboxes[fg_mask], xywh=False, CIoU=True)
        loss_iou = ((1.0 - iou) * weight).sum() / target_scores_sum

        # DFL loss
        if self.dfl_loss:
            target_ltrb = bbox2dist(anchor_points, target_bboxes, self.reg_max - 1)
            if self.key_loss:
                loss_dfl = self.dfl_loss(pred_dist[fg_mask].view(-1, self.reg_max), target_ltrb[fg_mask], proj) * weight
            else:
                loss_dfl = self.dfl_loss(pred_dist[fg_mask].view(-1, self.reg_max), target_ltrb[fg_mask]) * weight
            loss_dfl = loss_dfl.sum() / target_scores_sum
        else:
            loss_dfl = torch.tensor(0.0).to(pred_dist.device)

        return loss_iou, loss_dfl

    def _dfl_loss(self, dist, gt, proj):
        # dist [nt_mask, ne]
        proj = proj.view(1, -1).repeat(4, 1)
        nt, (C, K) = gt.shape[0], proj.shape
        device = proj.device
        Kmin, Kmax = proj.min(-1)[0].repeat((gt.shape[0], 1)), proj.max(-1)[0].repeat((gt.shape[0], 1))
        # gt_clamped = torch.clamp(gt, min=channel_keys[0], max=channel_keys[-1])
        gt_clamped = torch.maximum(Kmin, torch.minimum(gt, Kmax)).transpose(1, 0).contiguous()  # [c, nt]
        pos = torch.stack([torch.searchsorted(proj[i], gt_clamped[i], right=False) for i in range(proj.shape[0])]).transpose(1, 0).contiguous()    # [nt, c]
        pos = torch.clamp(pos, 1, self.reg_max-1)
        left = pos - 1           # [nt, c]
        right= pos               # [nt, c]
        # [nt, c] --> [nt, c, 3(nt_idx, c_idx, k_idx)] --> [nt * c, 3] --> 3 * [nt*c]
        left = torch.cat([torch.arange(nt, device=device).view(-1, 1, 1).repeat(1, C, 1),
                          torch.arange(C, device=device).view(1, -1, 1).repeat(nt, 1, 1),
                          left.view(nt, C, 1)], dim=-1).long().view(-1, 3).split(1, dim=-1)

        # [nt, c] --> [nt, c, 3(nt_idx, c_idx, k_idx)] --> [nt * c, 3] --> 3 * [nt*c]
        right = torch.cat([torch.arange(nt, device=device).view(-1, 1, 1).repeat(1, C, 1),
                          torch.arange(C, device=device).view(1, -1, 1).repeat(nt, 1, 1),
                          right.view(nt, C, 1)], dim=-1).long().view(-1, 3).split(1, dim=-1)        
        
        left_val  = proj[left[1], left[2]].view(-1, C)   # [nt, c]
        right_val = proj[right[1], right[2]].view(-1, C)   # [nt, c]

        denom = (right_val - left_val).clamp_min(1e-8)  # 避免除0
        val_clamped = gt_clamped.transpose(1, 0).contiguous().detach()
        w_left  = (right_val - val_clamped) / denom
        w_right = (val_clamped - left_val) / denom
    
        ce_map_1 =(F.cross_entropy(dist.view(-1, K), left[2].view(-1), reduction="none").view(nt, C) * w_left
                   + F.cross_entropy(dist.view(-1, K), right[2].view(-1), reduction="none").view(nt, C) * w_right
                   ).mean(-1, keepdim=True)

        return ce_map_1

from utils.ft_utils import probiou_pts4,solve_cos_sin_closed_form,solve_cos_sin_closed_form2,rotate_high_orders,ft2pts_k,ft_correct_clockwise,angle_multiple,ft_rot_normlize
class FTLoss(nn.Module):
    """Criterion class for computing training losses during training."""

    def __init__(self, reg_max=16, n_loop=8, GNF=0, ftxy=0.0, ft_dec=0.8,pred_clockwise=1,rot_normlize=0,
                 debug_samples=0, save_dir=None):
        """Initialize the BboxLoss module with regularization maximum and DFL settings."""
        super().__init__()
        self.n_loop = n_loop
        self.reg_max = reg_max
        self.GNF = GNF
        self.ftxy = ftxy
        self.ft_dec = ft_dec
        self.SLloss = nn.SmoothL1Loss(reduction='none')
        self.pred_clockwise = pred_clockwise
        self.rot_normlize = rot_normlize
        self.debug_samples = debug_samples
        self.save_dir = save_dir

    def forward(self, pred_ft, proj, anchor_points, target_ft, target_scores, target_scores_sum, fg_mask, stride_tensor, imgsz, mask_line=None, ft_gain=None, img=None):
        #pred_ft[b,ntotal,672=(2+nf*4)*reg_max]
        #proj[2+nf*4,reg_max]
        #anchor_points[ntotal,2]
        #target_ft[b,ntotal,2+nf*4]
        #target_scores[b,ntotal,nc]
        #fg_mask[b,ntotal]
        #stride_tensor[ntotal,1]
        """IoU loss."""
        weight = target_scores.sum(-1)[fg_mask] #target_scores[b,ntotal,nc]->weight[nt]

        target_ft = target_ft[fg_mask] #target_ft[nt,2+nf*4]
        nt = target_ft.shape[0]
        batch_id, nt_id = fg_mask.nonzero().T #nt_id[nt]
        stride_tensor = stride_tensor[nt_id] #stride_tensor[nt,1]
        pred_ft = pred_ft[fg_mask] #pred_ft[nt,(2+nf*4)*reg_max]]
        anchor_points = anchor_points[nt_id] #anchor_points[nt,2]

        target_ft_mask = (target_ft[:, :2] != 0).any(-1) #target_ft_mask[nt]
        # target_ft = target_ft[target_ft_mask] #target_ft[nt,2+nf*4]
        # stride_tensor = stride_tensor[target_ft_mask] #stride_tensor[nt,1]
        # pred_ft = pred_ft[target_ft_mask] #pred_ft[nt,(2+nf*4)*reg_max]]
        # anchor_points = anchor_points[target_ft_mask]#anchor_points[nt,2]
        # weight = weight[target_ft_mask]
        if target_ft_mask.sum() > 0:
            assert torch.all(target_ft_mask)
            assert nt>0
            # ft-xy-coef
            nf = (target_ft.shape[-1] - 2) // 4
            scale_idx = [1, 0] + [1, 1, 0, 0] * nf #scale_idx[2+nf*4]~id(0,1)
            #gt归一化坐标->网格坐标
            target_ft = target_ft * imgsz[scale_idx] / stride_tensor
            target_ft_xy = target_ft[..., :2] - anchor_points  # grid -> offset
            pred_proj = self.dfl_ft(pred_ft, proj) #pred_ft[nt,(2+nf*4)*reg_max],proj[(2+nf*4),reg_max]-->pred_proj[nt,2+nf*4]
            #
            weight = weight.unsqueeze(-1) #weight[nt,1]
            loss_xy = (self.SLloss(pred_proj[..., :2], target_ft_xy) * weight).sum() / target_scores_sum #target_ft_xy[nt,2]
            if self.GNF > 0: #loss= 1-iou
                loss_dfl = torch.tensor(0.0).to(weight.device)
                #
                # pred_proj_det, pred_dir = ft_rot_normlize(pred_proj)
                target_ft_det = torch.cat([target_ft_xy,target_ft[:,2:]],dim = -1) #target_ft_det[nt,2+nf*4]

                if mask_line is None: #torch.zeros(0, 3, dtype=torch.float32).to(device)
                    mask_line = torch.zeros(target_ft_det.shape[0], dtype=torch.float32).bool()

                if self.pred_clockwise:
                    ft_correct_clockwise(pred_proj[~mask_line])
                if self.rot_normlize:
                    pred_proj[~mask_line], pred_dir = ft_rot_normlize(pred_proj[~mask_line])

                if self.GNF==1:
                    abcd1 = pred_proj[~mask_line,2:6].detach() #abcd1[mask_nt,4]
                    cos_sin_iou = solve_cos_sin_closed_form(target_ft_det[~mask_line,2:6],abcd1) #cos_sin_iou[mask_nt,2]
                else: #GNF==2
                    cos_sin_iou = solve_cos_sin_closed_form2(target_ft_det[~mask_line,2:], pred_proj[~mask_line,2:].detach()) #cos_sin_iou[nt,2]
                cos_sin_iou = angle_multiple(cos_sin_iou, nf) #cos_sin_iou[nt,2]->cos_sin_iou[nt,nf,2]
                
                if img is not None:
                    target_ft_det_ori = target_ft_det.clone()
                    
                target_ft_det[~mask_line] = rotate_high_orders(None,target_ft_det[~mask_line],cos_sin_iou) # target_ft_det[mask_nt,2+nf*4]

                # 画图pred/gt前后
                if img is not None:
                    random_choice = np.random.choice(target_ft_det.shape[0], 1)
                    img = img[batch_id[random_choice][0]]
                    img = np.ascontiguousarray((img.permute((1,2,0)).cpu().numpy() * 255.).astype(np.uint8)[:, :, ::-1])
                    stride = stride_tensor[random_choice]
                    gt_ori = target_ft_det_ori[random_choice] * stride
                    offset = torch.zeros_like(gt_ori)
                    offset[:, :2] = anchor_points[random_choice] * stride
                    gt_ori += offset
                    gt_aft = target_ft_det[random_choice] * stride + offset
                    pred_f = pred_proj[random_choice] * stride + offset

                    if self.debug_samples > 0 and self.save_dir is not None:
                        box_ = ft2pts(pred_f)[0].detach().cpu().numpy()
                        ft_image = img
                        xyxy_list = []
                        for label, box, color in zip([pred_f, gt_aft, gt_ori], [box_, None, None], [green, orange, red]):
                            box = None
                            ft_image, xyxy = show_ft_4loss(ft_image, box, label[0].detach().cpu().numpy(), color = color) #labels[:, 1:5]
                            xyxy_list.append(xyxy)
                        xyxy_list = np.stack(xyxy_list, axis=-1)
                        x1, y1 = max(0, min(xyxy_list[0]) - 10), max(0, min(xyxy_list[1]) - 10)
                        x2, y2 = min(ft_image.shape[1], max(xyxy_list[2]) + 10), min(ft_image.shape[0], max(xyxy_list[3]) + 10)
                        name = '%04d' % (self.debug_samples)
                        debug_samples_path = Path(self.save_dir) / 'debug_samples'
                        debug_samples_path.mkdir(exist_ok=True)
                        cv2.imencode('.jpg', ft_image[y1:y2, x1:x2])[1].tofile(debug_samples_path / f'closed_{name}.jpg')
                        self.debug_samples-=1

                # pred_proj = pred_proj_det
                
                # loss_dfl = torch.tensor(0.0).to(weight.device)
            else: #L1SmoothLoss
                target_ft_min = loop_loss(self.n_loop, target_ft[..., 2:], pred_proj[..., 2:].detach())           
                if mask_line is not None:
                    target_ft[~mask_line][..., 2:] = target_ft_min[~mask_line]
                else:
                    target_ft[..., 2:] = target_ft_min
                #target_ft[..., 2:][nt,nf*4]~pred_proj[..., 2:][nt,nf*4] --> target_ft[..., 2:][nt,nf*4]
                #
                loss_dfl = self.dfl_loss(pred_ft, target_ft, proj) * weight  #loss_dfl[nt,2+4*nf]
                target_ft_det = target_ft
                #
            assert pred_proj.shape[0]==target_ft_det.shape[0]
            assert pred_proj.shape[0]==nt
            assert target_scores_sum>0
            loss_coef = self.SLloss(pred_proj[..., 2:], target_ft_det[..., 2:]) * weight #loss_coef[nt,nf*4]
            if ft_gain is not None and self.ft_dec==0.0: #ft_gain[nf*4]
                if not hasattr(self,'ft_dec_tensor'):
                    self.ft_dec_tensor = (ft_gain[0] / ft_gain)[None] #ft_gain[nf*4]->[1,nf*4]
            else:
                if not hasattr(self,'ft_dec_tensor'): #ft_dec_tensor[nf]
                    if self.ft_dec>0:
                        ft_dec_tensor = torch.cat([torch.tensor([1.0]), self.ft_dec**torch.arange(1, nf, dtype=torch.float32)]).to(device=loss_dfl.device)
                    else:
                        ft_dec_tensor = torch.ones((nf), dtype=torch.float32).to(device=loss_dfl.device)
                    self.ft_dec_tensor = ft_dec_tensor.unsqueeze(-1).repeat(1,4).view(-1)[None]#ft_dec_tensor[nf]->ft_dec_tensor[nf,4]->ft_dec_tensor[1,nf*4]
            
            gain = self.ft_dec_tensor.repeat(nt,1) #ft_dec_tensor[1,nf*4] -> gain[nt,nf*4]
            assert gain.shape==loss_coef.shape
            loss_coef *= gain #[nt, nf*4]               
            #
            if self.GNF==0:
                if mask_line is not None: #torch.ones(loss_coef.shape, dtype=torch.float32, device=loss_coef.device)#
                    # gain = (torch.abs((pred_proj[..., 2:].detach() - target_ft[..., 2:]) / (target_ft[..., 2:] + 1e-6)) * 100).clamp(1, 50)
                    loss_coef[mask_line, 1::2] = 0.
                    # gain = gain / gain.sum(-1, keepdims=True) * loss_coef.shape[-1]
                    # loss_coef *= gain
                loss_dfl[:, 2:] *= gain
                loss_dfl = loss_dfl.mean(-1, keepdim=True).sum() / target_scores_sum
            loss_coef = loss_coef.sum() / target_scores_sum #mean

            return loss_xy, loss_coef, loss_dfl
        else:
            return torch.tensor(0.0).to(weight.device), torch.tensor(0.0).to(weight.device), torch.tensor(0.0).to(weight.device)
            # target_ft_xy = target_ft[..., :2] * imgsz[[1, 0]] / stride_tensor - anchor_points  # grid -> offset
    
    def forward_ft_statistics(self, pred_ft, proj, anchor_points, target_ft, target_scores, target_scores_sum, fg_mask, stride_tensor, imgsz):
        #pred_ft[b,ntotal,672=(2+nf*4)*reg_max]
        #proj[2+nf*4,reg_max]
        #anchor_points[ntotal,2]
        #target_ft[b,ntotal,2+nf*4]
        #target_scores[b,ntotal,nc]
        #fg_mask[b,ntotal]
        #stride_tensor[ntotal,1]
        """IoU loss."""
        weight = target_scores.sum(-1)[fg_mask].unsqueeze(-1) #weight[nt,1]

        target_ft = target_ft[fg_mask] #target_ft[nt,2+nf*4]
        _, nt_id = fg_mask.nonzero().T #nt_id[nt]
        stride_tensor = stride_tensor[nt_id] #stride_tensor[nt,1]
        pred_ft = pred_ft[fg_mask] #pred_ft[nt,(2+nf*4)*reg_max]]
        anchor_points = anchor_points[nt_id] #anchor_points[nt,2]

        target_ft_mask = (target_ft[:, :2] != 0).any(-1) #target_ft_mask[nt]
        # target_ft = target_ft[target_ft_mask] #target_ft[nt,2+nf*4]
        # stride_tensor = stride_tensor[target_ft_mask] #stride_tensor[nt,1]
        # pred_ft = pred_ft[target_ft_mask] #pred_ft[nt,(2+nf*4)*reg_max]]
        # anchor_points = anchor_points[target_ft_mask]#anchor_points[nt,2]
        # weight = weight[target_ft_mask] #weight[nt,1]
        if target_ft_mask.sum() > 0:
            assert torch.all(target_ft_mask)
            # ft-xy-coef
            scale_idx = [1, 0] + [1, 1, 0, 0] * ((target_ft.shape[-1] - 2) // 4) #scale_idx[2+nf*4]~id(0,1)
            #gt归一化坐标->网格坐标
            target_ft = target_ft * imgsz[scale_idx] / stride_tensor
            target_ft_xy = target_ft[..., :2] - anchor_points  # grid -> offset

            pred_proj = self.dfl_ft(pred_ft, proj) #pred_ft[nt,(2+nf*4)*reg_max],proj[(2+nf*4),reg_max]-->pred_proj[nt,2+nf*4]
            target_ft[..., 2:] = loop_loss(1, target_ft[..., 2:], pred_proj[..., 2:].detach()) #was self.n_loop
            #target_ft[..., 2:][nt,4n]~pred_proj[..., 2:][nt,4n] --> target_ft[..., 2:][nt,4n]

            return torch.cat([target_ft_xy, target_ft[..., 2:]], dim=1)
        else:
            return torch.zeros(0, target_ft.shape[-1])
            # target_ft_xy = target_ft[..., :2] * imgsz[[1, 0]] / stride_tensor - anchor_points  # grid -> offset
    
    def dfl_ft(self, x, proj):
        x = x.T.contiguous()
        a, nt_mask = x.shape  # batch, channels, anchors
        gs = a // self.reg_max
        x = F.conv2d(x.view(1, -1, self.reg_max, nt_mask).softmax(2).view(1, a, -1, nt_mask), proj.view(gs, -1, 1, 1), groups=gs).view(-1, nt_mask).T.contiguous()
        return x
    
    def dfl_loss(self, dist, gt, proj):
        # dist [nt_mask, ne]
        nt, (C, K) = gt.shape[0], proj.shape
        device = proj.device
        Kmin, Kmax = proj.min(-1)[0].repeat((gt.shape[0], 1)), proj.max(-1)[0].repeat((gt.shape[0], 1))
        # gt_clamped = torch.clamp(gt, min=channel_keys[0], max=channel_keys[-1])
        gt_clamped = torch.maximum(Kmin, torch.minimum(gt, Kmax)).transpose(1, 0).contiguous()  # [c, nt]
        pos = torch.stack([torch.searchsorted(proj[i], gt_clamped[i], right=False) for i in range(proj.shape[0])]).transpose(1, 0).contiguous()    # [nt, c]
        pos = torch.clamp(pos, 1, self.reg_max-1)
        left = pos - 1           # [nt, c]
        right= pos               # [nt, c]
        # [nt, c] --> [nt, c, 3(nt_idx, c_idx, k_idx)] --> [nt * c, 3] --> 3 * [nt*c]
        left = torch.cat([torch.arange(nt, device=device).view(-1, 1, 1).repeat(1, C, 1),
                          torch.arange(C, device=device).view(1, -1, 1).repeat(nt, 1, 1),
                          left.view(nt, C, 1)], dim=-1).long().view(-1, 3).split(1, dim=-1)

        # [nt, c] --> [nt, c, 3(nt_idx, c_idx, k_idx)] --> [nt * c, 3] --> 3 * [nt*c]
        right = torch.cat([torch.arange(nt, device=device).view(-1, 1, 1).repeat(1, C, 1),
                          torch.arange(C, device=device).view(1, -1, 1).repeat(nt, 1, 1),
                          right.view(nt, C, 1)], dim=-1).long().view(-1, 3).split(1, dim=-1)        
        
        left_val  = proj[left[1], left[2]].view(-1, C)   # [nt, c]
        right_val = proj[right[1], right[2]].view(-1, C)   # [nt, c]

        denom = (right_val - left_val).clamp_min(1e-8)  # 避免除0
        val_clamped = gt_clamped.transpose(1, 0).contiguous().detach()
        w_left  = (right_val - val_clamped) / denom
        w_right = (val_clamped - left_val) / denom
    
        ce_map_1 =(F.cross_entropy(dist.view(-1, K), left[2].view(-1), reduction="none").view(nt, C) * w_left
                   + F.cross_entropy(dist.view(-1, K), right[2].view(-1), reduction="none").view(nt, C) * w_right
                   )

        return ce_map_1

class DFLoss(nn.Module):
    """Criterion class for computing DFL losses during training."""

    def __init__(self, reg_max=16) -> None:
        """Initialize the DFL module."""
        super().__init__()
        self.reg_max = reg_max

    def __call__(self, pred_dist, target):
        """
        Return sum of left and right DFL losses.

        Distribution Focal Loss (DFL) proposed in Generalized Focal Loss
        https://ieeexplore.ieee.org/document/9792391
        """
        target = target.clamp_(0, self.reg_max - 1 - 0.01)
        tl = target.long()  # target left
        tr = tl + 1  # target right
        wl = tr - target  # weight left
        wr = 1 - wl  # weight right
        return (
            F.cross_entropy(pred_dist, tl.view(-1), reduction="none").view(tl.shape) * wl
            + F.cross_entropy(pred_dist, tr.view(-1), reduction="none").view(tl.shape) * wr
        ).mean(-1, keepdim=True)
    

def bbox2dist(anchor_points, bbox, reg_max):
    """Transform bbox(xyxy) to dist(ltrb)."""
    x1y1, x2y2 = bbox.chunk(2, -1)
    return torch.cat((anchor_points - x1y1, x2y2 - anchor_points), -1).clamp_(0, reg_max - 0.01)


def loop_loss(n_loop,ft_coefs_labels,ft_coef_pi):#ft_coefs_labels[nt,4*term]  ft_coef_min[nt, 4*term]
    if n_loop==0:
        return ft_coefs_labels
    #term = ft_coefs_labels.shape[1] // 4
    # a_ft -> [nt, term]
    nt = ft_coefs_labels.shape[0]
    #temp = torch.split(ft_coefs_labels.view(nt, -1, 4), 1, dim = -1)
    a_ft, b_ft, c_ft, d_ft = [coef.squeeze(-1) for coef in torch.split(ft_coefs_labels.view(nt, -1, 4), 1, dim = -1)] # 4| nt, term, 1
    
    ft_coef_loop = torch.zeros([n_loop, nt, ft_coefs_labels.shape[1]]).to(ft_coef_pi.device)#ft_coef_loop[n_loop, nt, term*4] ={8, nt, [k=4] * 4}
    # min_loss = 1e6s
    for t in range(n_loop):
        coef_num = a_ft.shape[-1]   # k  
        angle = torch.tensor(2*torch.pi*t/n_loop)
        for k in range(coef_num):
            k_angle = (k+1) * angle
            t_cos = torch.cos(k_angle)
            t_sin = torch.sin(k_angle)
            
            # temp = torch.cos(k_angle) * a_ft[:, k] + torch.sin(k_angle) * b_ft[:, k]
        
        #   ak` = cos(k*2pi*t/n_loop) * ak + sin(k*2pi*t/n_loop) * bk 
            ft_coef_loop[t, :, 4*k + 0] = t_cos * a_ft[:, k] + t_sin * b_ft[:, k] #[nt, 1]
        #   bk` = sin(k*2pi*t/n_loop) * ak - cos(k*2pi*t/n_loop) * bk
            ft_coef_loop[t, :, 4*k + 1] =-t_sin * a_ft[:, k] + t_cos * b_ft[:, k]

        #   ck` = cos(k*2pi*t/n_loop) * ck + sin(k*2pi*t/n_loop) * dk 
            ft_coef_loop[t, :, 4*k + 2] = t_cos * c_ft[:, k] + t_sin * d_ft[:, k]
        #   dk` = sin(k*2pi*t/n_loop) * ck - cos(k*2pi*t/n_loop) * dk
            ft_coef_loop[t, :, 4*k + 3] =-t_sin * c_ft[:, k] + t_cos * d_ft[:, k]
        #   4 [nt, 1]

    # ft_coef_loop - pi_f[:, 2:].detach().view(1, nt, term*4)  ({n_loop, nt, term*4} - {1, nt, term*4}).mean ->  {n_loop , nt}
    # ft_coef_loop[n_loop, nt, term*4]
    #pi_ft_coef = pi_f[:, 2:].clone()[None, ...]
    # ft_coef_loop = ft_coef_loop[1::2]
    loss_nt = torch.abs(ft_coef_loop - ft_coef_pi) # [n_loop, nt, term*4]
    loss_nt = loss_nt.mean(-1)  # [n_loop, nt]
    nt_indices = torch.argmin(loss_nt.T, dim=-1) # loss_nt.T[nt,n_loop] -> [nt]
    ft_coef_min = ft_coef_loop[nt_indices, torch.arange(ft_coefs_labels.shape[0])] # [nt, term*4]
    # ft_coef_loop[n_loop, nt, term*4] -> [nt_indices, :] -> ft_coef_min[nt, term*4]
    return ft_coef_min

import cv2

red = (0, 0, 255)        # 红
green = (0, 255, 0)      # 绿  
orange = (0, 165, 255)   # 橙
cyan = (255, 255, 0)     # 青绿

def show_ft_4loss(img, xy_rect=(),ft_label=(), color=None):
    # h, w, _ = img.shape
    new_img = img.copy()
    theta_fine = np.linspace(0, 2*np.pi, 200)
    an,bn,cn,dn = [abcd.reshape(-1) for abcd in np.split(ft_label[2:].reshape(-1, 4), 4, axis=-1)]
    x_approx = sum([an[i]*np.cos((i+1)*theta_fine) + bn[i]*np.sin((i+1)*theta_fine) for i in range(an.shape[0])])
    y_approx = sum([cn[i]*np.cos((i+1)*theta_fine) + dn[i]*np.sin((i+1)*theta_fine) for i in range(an.shape[0])])
    xy = np.vstack([x_approx + ft_label[0], y_approx + ft_label[1]]).T# * (w, h)
    xy = xy.astype(np.int32)
    cv2.polylines(new_img, [xy], True, color, 2)
    cv2.arrowedLine(new_img, (round(ft_label[0]), round(ft_label[1])), (xy[0][0], xy[0][1]), color, 2)
    cv2.circle(new_img, xy[0], 5, color, thickness=-1)
    cv2.circle(new_img, (round(ft_label[0]), round(ft_label[1])), 3, (255, 255, 255), thickness=-1)
    cv2.circle(new_img, xy[0], 3, (255, 255, 255), thickness=-1)
    
    if xy_rect is None:
        pass
    elif len(xy_rect)==4:
        cv2.rectangle(new_img, (int(xy_rect[0]), int(xy_rect[1])), (int(xy_rect[2]), int(xy_rect[3])), (0,255,0), 2)
        xy = np.concatenate([xy, xy_rect.reshape(-1,2)], axis=0)
    elif len(xy_rect)==8: # for pts
        pts_ = xy_rect.reshape([-1, 2]).astype(np.int32)
        cv2.polylines(new_img, [pts_], True, cyan, 2)
        xy = np.concatenate([xy, pts_], axis=0).astype(np.int32)

    xyxy = np.concatenate([np.min(xy, 0, keepdims=False), np.max(xy, 0, keepdims=False)])
    return new_img, xyxy