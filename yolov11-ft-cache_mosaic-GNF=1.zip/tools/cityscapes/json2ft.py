import os
import json
import numpy as np
import matplotlib.pyplot as plt
import cv2
from glob import glob

import shutil

from tools.fft.fftcurve import compute_coefficients_interp,inverse_fourier,inverse_fourier_gpt

from tqdm import tqdm

# from general.MyString import replace_path_part,remove_suffix
from pathlib import Path
# 原始路径
def replace_path_part(json_path,part_offset):
    path = Path(json_path)
    # 拆分路径
    parts = list(path.parts)
    # 替换倒数第3个部分（也就是 parts[-3]）
    parts[part_offset] = "leftImg8bit"
    # 拼接成新路径
    new_path = str(Path(*parts))
    return new_path
def remove_suffix(filename,suffix):
    if '.' in filename:
        name, ext = filename.rsplit('.', 1)
        new_name = name.replace(suffix, "") + '.' + ext
    else:
        new_name = filename.replace(suffix, "")
    return new_name

# 重新执行之前整理好的批量处理脚本，处理 JSON 标签并绘制傅里叶轮廓可视化图像
colors = [
        (54, 67, 244), (99, 30, 233), (176, 39, 156), (183, 58, 103), (181, 81, 63),
        (243, 150, 33), (212, 188, 0), (136, 150, 0), (80, 175, 76), (74, 195, 139),
        (57, 220, 205), (59, 235, 255), (0, 152, 255), (34, 87, 255), (72, 85, 121),
        (180, 105, 255), (255, 0, 0), (255, 127, 0), (255, 255, 0), (0, 255, 0),
        (0, 0, 255), (75, 0, 130), (238, 130, 238), (128, 0, 0), (128, 128, 0),
        (0, 128, 0), (128, 0, 128), (0, 128, 128), (0, 0, 128), (139, 69, 19),
        (210, 105, 30), (244, 164, 96), (255, 228, 181), (255, 255, 224), (173, 216, 230),
        (240, 230, 140), (250, 250, 210), (255, 239, 213), (255, 245, 238), (240, 255, 240),
        (255, 69, 0), (255, 165, 0), (255, 215, 0), (154, 205, 50), (0, 255, 127),
        (60, 179, 113), (32, 178, 170), (47, 79, 79), (0, 206, 209), (72, 61, 139),
        (123, 104, 238), (106, 90, 205), (135, 206, 250), (70, 130, 180), (176, 196, 222),
        (95, 158, 160), (100, 149, 237), (0, 191, 255), (30, 144, 255), (25, 25, 112),
        (75, 0, 130), (138, 43, 226), (148, 0, 211), (186, 85, 211), (153, 50, 204),
        (128, 0, 128), (216, 191, 216), (221, 160, 221), (238, 130, 238), (255, 0, 255),
        (139, 0, 139), (255, 20, 147), (199, 21, 133), (219, 112, 147), (255, 182, 193),
        (255, 160, 122), (255, 105, 180), (255, 69, 0), (255, 140, 0), (255, 165, 0)
    ]

# 处理单个 JSON 文件
def process_single_json(json_path, names, label2id, output_dir="labels", terms_export=4, hull=1, vis=True):
    with open(json_path, "r") as f:
        data = json.load(f)

    H, W = data["imgHeight"], data["imgWidth"]
    objects = data["objects"]

    base_name = os.path.splitext(os.path.basename(json_path))[0]
    labels_path = os.path.join(output_dir, 'labels')
    txt_path = os.path.join(labels_path, f"{base_name}.txt")
    txt_path = remove_suffix(txt_path,'_gtFine_polygons')
    assert not os.path.exists(txt_path)
    ft_path = os.path.join(labels_path, f"{base_name}.ft")
    ft_path = remove_suffix(ft_path,'_gtFine_polygons')
    assert not os.path.exists(ft_path)

    images_path_out = os.path.join(output_dir, 'images')

    # 尝试读取对应图像
    # 原始路径
    image_path = os.path.join(replace_path_part(os.path.dirname(json_path),-3),os.path.basename(json_path))
    image_path = image_path.replace("_gtFine_polygons.json", "_leftImg8bit.png")
    assert os.path.exists(image_path)

    #image_path->image_file_out
    dst_image_name = remove_suffix(os.path.basename(image_path),'_leftImg8bit')
    image_file_out = os.path.join(images_path_out,dst_image_name)
    shutil.copy2(image_path, image_file_out)

    vis_img = None
    if vis:
        # image_path = json_path.replace("_polygons.json", "_instanceIds.png")
        if os.path.exists(image_path):
            vis_img = cv2.imread(image_path, cv2.IMREAD_COLOR)
            vis_img = cv2.cvtColor(vis_img, cv2.COLOR_BGR2RGB)
        else:
            vis = False

    with open(txt_path, "w") as txtf, open(ft_path, "w") as ftf:
        for obj in objects:
            label = obj["label"]
            if label in names:
                class_id = label2id[label]
                polygon = obj["polygon"]
                xys = np.array(polygon, dtype=np.float32).reshape(-1, 2)

                # 使用凸包使轮廓更加饱满
                if hull:
                    xys = cv2.convexHull(xys).reshape(-1, 2)

                # 外接框
                x_min, y_min = xys.min(axis=0)
                x_max, y_max = xys.max(axis=0)
                xc = (x_min + x_max) / 2 / W
                yc = (y_min + y_max) / 2 / H
                w = (x_max - x_min) / W
                h = (y_max - y_min) / H
                txtf.write(f"{class_id} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}\n")

                # 傅里叶系数
                (an, bn, cn, dn), _ = compute_coefficients_interp(xys, terms=terms_export)
                ftf.write(f"{class_id} {an[0]/W:.6f} {cn[0]/H:.6f} ")
                for i in range(1, terms_export):
                    ftf.write(f"{an[i]/W:.6f} {bn[i]/W:.6f} {cn[i]/H:.6f} {dn[i]/H:.6f} ")
                ftf.write("\n")

                # 可视化轮廓
                if vis and vis_img is not None:
                    if 0:
                        recon_xy = inverse_fourier_gpt(an, bn, cn, dn, terms_export, num_points=200) #recon_xy[n,2]
                    else:
                        recon_xy = inverse_fourier((an, bn, cn, dn), terms_export, 200) #x_approx, y_approx
                    recon_xy = np.round(recon_xy).astype(np.int32)
                    recon_xy = recon_xy.reshape(-1, 1, 2)
                    color = colors[class_id%len(colors)]
                    cv2.polylines(vis_img, [recon_xy], isClosed=True, color=color, thickness=2)
                    if 1:
                        # 计算左上角和右下角
                        x1 = int((xc - w / 2)*W)
                        y1 = int((yc - h / 2)*H)
                        x2 = int((xc + w / 2)*W)
                        y2 = int((yc + h / 2)*H)
                        cv2.rectangle(vis_img, (x1, y1), (x2, y2), color=color, thickness=2)

    if vis and vis_img is not None:
        vis_out = os.path.join(output_dir, f"{remove_suffix(base_name,'_gtFine_polygons')}.png")
        plt.imsave(vis_out, vis_img)
        # print(f"✅ 可视化保存：{vis_out}")

    # print(f"✅ 完成标签生成: {txt_path}, {ft_path}")

# 遍历处理整个文件夹
def process_all_jsons(names, json_dir="gtFine", output_dir="cityscapes", terms_export=4, hull=1,max_vis=8):
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(os.path.join(output_dir,'labels'), exist_ok=True)
    os.makedirs(os.path.join(output_dir,'images'), exist_ok=True)
    #
    sorted_names = sorted(names)
    names_path = os.path.join(output_dir, "names.txt")
    with open(names_path, "w") as f:
        for label in sorted_names:
            f.write(f"{label}\n")
    # 类别映射
    label2id = {label: idx for idx, label in enumerate(sorted_names)}
    #
    json_files = glob(os.path.join(json_dir, "**/*_polygons.json"), recursive=True)
    # json_files = list(Path(json_dir).rglob("*_polygons.json"))
    print(f"🔍 共发现 {len(json_files)} 个 JSON 文件")
    for i,json_path in tqdm(enumerate(json_files),total=len(json_files)):
        process_single_json(json_path, names,label2id, output_dir=output_dir, terms_export=terms_export, hull=hull, vis=(i<max_vis))

if __name__ == '__main__':
    TARGET_LABELS = {"person", "car", "truck", "bicycle", "bus", "motorcycle", "rider"} #,"traffic light","traffic sign","ego vehicle","out of roi"
    # 示例运行（你可以根据需要修改 json_dir）
    json_dir=r"E:\datas\cityscapes\gtFine\val" #train,val,test
    data_path = r"E:\datas\cityscapes"
    #
    # 提取 json_dir 的最后一个目录名
    subdir_name = os.path.basename(os.path.normpath(json_dir))
    # 拼接为新的输出目录
    output_dir = os.path.join(data_path, subdir_name)
    process_all_jsons(TARGET_LABELS, json_dir=json_dir, output_dir=output_dir, terms_export=12,hull=1,max_vis=8)
