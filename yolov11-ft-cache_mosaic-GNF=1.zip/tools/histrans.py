import numpy as np
import bisect
import os
from pathlib import Path
from tqdm import tqdm

def LoadCamera(filename):
    camera = {}
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
            for line in lines:
                key, value = line.split("=")
                key = key.strip()
                value = value.strip().split('#')[0]
                camera[key.strip()] = float(value.strip())

        return camera
    except Exception:
        return None

def uv2vec_numpy(camera, uv):
    z1 = np.stack([
        (uv[:,0] - camera['cx']) / camera['fx'],
        (uv[:,1] - camera['cy']) / camera['fy'],
        np.ones(uv.shape[0])
        ],
        axis=1)  # nt, 3
    l2_z1 = np.linalg.norm(z1, ord=2, axis=-1, keepdims=True)   # nt, 1 === (z1[:, 0]^2 + z1[:, 1]^2 + z1[:, 2]^2) ^ (0.5)
    z1 /= l2_z1
    return z1, l2_z1

class Histrans:
    def __init__(self):
        self.histogram = None
        self.cumulative_distribution = None
        self.bin_edges = None

    def compute_histogram(self, data, bins=100):
        data.sort()
        self.histogram, self.bin_edges = np.histogram(data, bins=bins, density=True)
        self.cumulative_distribution = np.cumsum(self.histogram) * np.diff(self.bin_edges)

    def transform(self, v):
        if v < self.bin_edges[0]:
            return 0.0
        elif v > self.bin_edges[-1]:
            return 1.0
        else:
            bin_index = np.searchsorted(self.bin_edges, v, side='right') - 1
            if bin_index == len(self.cumulative_distribution):
                return 1.0
            elif bin_index == 0:
                s_low = 0
            else:
                s_low = self.cumulative_distribution[bin_index - 1]
            s_high = self.cumulative_distribution[bin_index]
            v_low = self.bin_edges[bin_index]
            v_high = self.bin_edges[bin_index + 1]
            # Linear interpolation
            return (s_low*(v_high-v) + s_high * (v - v_low)) / (v_high - v_low)
            #return s_low + (s_high - s_low) * (v - v_low) / (v_high - v_low)

    def inverse_transform(self, s):
        if self.histogram is None:
            return -1
        if s <= 0:
            return self.bin_edges[0]
        elif s >= 1:
            return self.bin_edges[-1]
        else:
            index = np.searchsorted(self.cumulative_distribution, s, side='right')# - 1
            if index == 0:
                s_low = 0
            else:
                s_low = self.cumulative_distribution[index - 1]
            s_high = self.cumulative_distribution[index]
            v_low = self.bin_edges[index]
            v_high = self.bin_edges[index + 1]
            # Linear interpolation
            return (v_low*(s_high-s) + v_high * (s - s_low)) / (s_high - s_low)
            #return v_low + (v_high - v_low) * (s - s_low) / (s_high - s_low)

    @staticmethod
    def load_data_from_file(filename, index=0, dz=False, camera=None):
        # Load data from a file
        datas = []
        rect_box = []
        if not isinstance(filename, list):
            filename = [filename]
        if dz:
            camera = LoadCamera(camera)
            assert camera is not None, '需要提供Camera参数'
        for file in tqdm(filename, desc='Load data from files'):
            file = Path(file)
            with open(file, 'r') as fr:
                values = np.array([x.split(' ')[index] for x in fr.read().splitlines() if x.strip != ''], dtype=np.float32)
            if dz:
                with open(file.with_suffix('.txt'), 'r') as fr:
                    rect_box = np.array([x.split(' ') for x in fr.read().splitlines() if x.strip != ''], dtype=np.float32)
                _, l2_z1 = uv2vec_numpy(camera=camera, uv=rect_box[:, 1:3])
                l2_z1 = l2_z1.reshape(-1)
            else:
                l2_z1 = np.ones_like(values)
            datas.extend(values * l2_z1)
        return np.stack(datas, axis=0)
        
    def save_labels(self, filename, index=0, dz=False, camera=None):
        # Save data to a file
        if not isinstance(filename, list):
            filename = [filename]
        if dz:
            camera = LoadCamera(camera)
            assert camera is not None, '需要提供Camera参数'
        os.makedirs('labels_output', exist_ok=True)
        for file in tqdm(filename, desc='Save data to ./labels_output'):
            file = Path(file)
            with open(file, 'r') as fr:
                data = np.array([x.split(' ') for x in fr.read().splitlines() if x.strip != ''], dtype=np.float32)
            if dz:
                with open(file.with_suffix('.txt'), 'r') as fr:
                    rect_box = np.array([x.split(' ') for x in fr.read().splitlines() if x.strip != ''], dtype=np.float32)
                _, l2_z1 = uv2vec_numpy(camera=camera, uv=rect_box[:, 1:3])
                l2_z1 = l2_z1.reshape(-1)
            else:
                l2_z1 = np.ones_like(data)
            data[:, index] /= l2_z1
            for i in range(data.shape[0]):
                # print(f'Original:{data[i, index]}, Transformed: {self.transform(data[i, index])}, Inversed:  {self.inverse_transform(self.transform(data[i, index]))}')
                data[i, index] = self.transform(data[i, index])
            
            with open(Path('./labels_output') / file.name, 'w') as fw:
                for value in data:
                    fw.write(' '.join([f"{v:.6f}" for v in value.tolist()])+"\n")

    def save_hist(self, hist_path):
        assert self.histogram is not None
        assert self.cumulative_distribution is not None
        assert self.bin_edges is not None
        hist_npy = np.zeros([3, self.bin_edges.shape[0]], dtype=np.float64)
        hist_npy[0, :-1] = self.histogram
        hist_npy[1, :-1] = self.cumulative_distribution
        hist_npy[2, :] = self.bin_edges
        np.save(hist_path, hist_npy)

    def load_hist(self, hist_path):
        hist_npy = np.load(hist_path)
        self.histogram = hist_npy[0, :-1]
        self.cumulative_distribution = hist_npy[1, :-1]
        self.bin_edges = hist_npy[2, :]


if __name__ == '__main__':
    # Create an instance of Histrans and load random data
    htrans = Histrans()
    label_path = r'E:\DATA\kitti\labels'
    camera_path = r'E:\DATA\kitti\Camera.txt'
    xyz_file = [os.path.join(label_path, f) for f in os.listdir(label_path) if f.endswith('.xyz')]
    datas = htrans.load_data_from_file(xyz_file, -1, dz=True, camera=camera_path)
    htrans.compute_histogram(data=datas, bins=100)
    # htrans.save_labels(xyz_file, -1, dz=True, camera=camera_path)
    htrans.save_hist('hist.npy')
    htrans_new = Histrans()
    htrans_new.load_hist('hist.npy')
    # htrans_new.save_labels(xyz_file, -1, dz=True, camera=camera_path)

    # Example usage
    # htrans = Histrans()
    # htrans.load('data.txt')
    # htrans.compute_histogram(bins=100)
    # print(htrans.transform(0.5))  # Transform a value
    # print(htrans.inverse_transform(0.5))  # Inverse transform
    # htrans.save('output.txt')
