import torch
import math

def fourier_to_points(ft, num_points=100):
    """
    ft: [2 + nf*4]  单个多边形傅里叶系数
    返回: [num_points,2] 多边形采样点
    """
    nf = (ft.shape[0] - 2) // 4
    t = torch.linspace(0, 2*math.pi, num_points, device=ft.device).unsqueeze(1)  # [num_points,1]
    x = ft[0] + torch.zeros_like(t)
    y = ft[1] + torch.zeros_like(t)
    for n in range(1, nf+1):
        a, b, c, d = ft[2 + (n-1)*4 : 2 + n*4]
        x = x + a * torch.cos(n*t) + b * torch.sin(n*t)
        y = y + c * torch.cos(n*t) + d * torch.sin(n*t)
    points = torch.cat([x, y], dim=1)  # [num_points,2]
    return points

def point_in_polygon_soft(points, polygon, k=10.0):
    # Soft membership score: 点在多边形内部的概率（可微）
    # points: [P,2]
    # polygon: [V,2]
    V = polygon.shape[0]
    p1 = polygon
    p2 = torch.roll(polygon, shifts=-1, dims=0)
    edge = p2 - p1  # [V,2]
    vec = points[:, None, :] - p1[None, :, :]  # [P,V,2]
    cross = edge[None, :, 0] * vec[:, :, 1] - edge[None, :, 1] * vec[:, :, 0]  # [P,V]
    score = torch.sigmoid(-k * cross)
    return score.prod(dim=1)  # [P]

def polygon_iou_soft_aligned(pred_pts, gt_pts, k=10.0):
    """
    输入：
        pred_pts: [nt, npts, 2] 每个预测多边形采样点
        gt_pts:   [nt, npts, 2] 每个GT多边形采样点
    输出：
        ious: [nt] 每个对齐多边形的 soft IoU
    """
    nt, npts, _ = pred_pts.shape
    ious = []
    for i in range(nt):
        # 每个 polygon 的 bounding box 内采样点
        min_xy = torch.min(torch.cat([pred_pts[i], gt_pts[i]], dim=0), dim=0).values
        max_xy = torch.max(torch.cat([pred_pts[i], gt_pts[i]], dim=0), dim=0).values
        xs = torch.linspace(min_xy[0], max_xy[0], int(npts**0.5), device=pred_pts.device)
        ys = torch.linspace(min_xy[1], max_xy[1], int(npts**0.5), device=pred_pts.device)
        grid_x, grid_y = torch.meshgrid(xs, ys, indexing='xy')
        points = torch.stack([grid_x.flatten(), grid_y.flatten()], dim=-1)  # [npts,2]

        score_pred = point_in_polygon_soft(points, pred_pts[i], k)
        score_gt   = point_in_polygon_soft(points, gt_pts[i], k)

        intersection = (score_pred * score_gt).sum()
        union = (score_pred + score_gt - score_pred*score_gt).sum() + 1e-6
        ious.append(intersection / union)
    return torch.stack(ious, dim=0)  # [nt]

# ===== 批量傅里叶 IoU 入口 =====
def fourier_ious_aligned(ft1, ft2, npts=100, k=10.0):
    """
    ft1: [nt, 2+nf*4] 预测傅里叶系数
    ft2: [nt, 2+nf*4] GT傅里叶系数
    输出: [nt] 对齐多边形的 soft IoU
    """
    nt = ft1.shape[0]
    pred_pts = torch.stack([fourier_to_points(ft1[i], npts) for i in range(nt)], dim=0)  # [nt,npts,2]
    gt_pts   = torch.stack([fourier_to_points(ft2[i], npts) for i in range(nt)], dim=0)  # [nt,npts,2]
    return polygon_iou_soft_aligned(pred_pts, gt_pts, k=k)

if __name__ == "__main__":
    nt = 4
    nf = 2
    ft_pred = torch.rand(nt, 2+nf*4, requires_grad=True)
    ft_gt   = torch.rand(nt, 2+nf*4)

    ious = fourier_ious_aligned(ft_pred, ft_gt, npts=200, k=10.0)
    print(ious)   # [nt]
    ious.sum().backward()
    print(ft_pred.grad.shape)


# elif self.GNF==3:
#     #loss_xy
#     loss_xy = torch.tensor(0.0).to(weight.device)
#     loss_dfl = torch.tensor(0.0).to(weight.device)
#     #
#     # pred_proj_det, pred_dir = ft_rot_normlize(pred_proj)
#     target_ft_det = torch.cat([target_ft_xy,target_ft[:,2:]],dim = -1) #target_ft_det[nt,2+nf*4]

#     if mask_line is None: #torch.zeros(0, 3, dtype=torch.float32).to(device)
#         mask_line = torch.zeros(target_ft_det.shape[0], dtype=torch.float32).bool()

#     if self.pred_clockwise:
#         ft_correct_clockwise(pred_proj[~mask_line])

#     #pred_proj[nt,2+nf*4] ~ target_ft_det[nt,2+nf*4]) -> loss_coef[nt,2+nf*4]
#     loss_coef = (1 - fourier_ious_aligned(pred_proj, target_ft_det, npts=100, k=10.0)) * weight[:,0] #loss_coef[nt,nf*4]
