import os
import shutil
from tqdm import tqdm
import glob

def filter_coco_animals(original_root, new_root, animal_keywords):
    # 原始路径
    images_dir = os.path.join(original_root, "images")
    labels_dir = os.path.join(original_root, "labels")
    names_path = os.path.join(original_root, "names.txt")

    # 新路径
    new_images_dir = os.path.join(new_root, "images")
    new_labels_dir = os.path.join(new_root, "labels")
    os.makedirs(new_images_dir, exist_ok=True)
    os.makedirs(new_labels_dir, exist_ok=True)

    # 读取原始 names.txt
    with open(names_path, "r", encoding="utf-8") as f:
        orig_names = [line.strip() for line in f if line.strip()]

    # 找出属于动物的类别 id
    animal_ids = [i for i, name in enumerate(orig_names) if name.lower() in animal_keywords]
    ids2new = {orig_id: new_id for new_id, orig_id in enumerate(animal_ids)}

    # 新的 names.txt（动物类名）
    new_names = [orig_names[i] for i in animal_ids]
    with open(os.path.join(new_root, "names.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(new_names) + "\n")

    # 遍历 labels_dir 下所有 .txt 文件
    txt_files = glob.glob(os.path.join(labels_dir, "*.txt"))

    for txt_path in tqdm(txt_files, desc="Filtering labels", unit="file"):
        ft_path = os.path.splitext(txt_path)[0] + ".ft"
        txt_file = os.path.basename(txt_path)

        # 读取标签
        with open(txt_path, "r", encoding="utf-8") as f:
            txt_lines = [line.strip() for line in f if line.strip()]
        with open(ft_path, "r", encoding="utf-8") as f:
            ft_lines = [line.strip() for line in f if line.strip()]

        new_txt_lines = []
        new_ft_lines = []

        for t_line, f_line in zip(txt_lines, ft_lines):
            parts_txt = t_line.split()
            parts_ft = f_line.split()
            cls_id = int(parts_txt[0])
            if cls_id in ids2new:
                new_cls = ids2new[cls_id]
                parts_txt[0] = str(new_cls)
                new_txt_lines.append(" ".join(parts_txt))
                parts_ft[0] = str(new_cls)
                new_ft_lines.append(" ".join(parts_ft))

        if new_txt_lines:
            # 复制图像
            img_file = txt_file.replace(".txt", ".jpg")
            src_img_path = os.path.join(images_dir, img_file)
            dst_img_path = os.path.join(new_images_dir, img_file)
            shutil.copy2(src_img_path, dst_img_path)

            # 写入新的 txt / ft
            new_txt_path = os.path.join(new_labels_dir, txt_file)
            new_ft_path = os.path.join(new_labels_dir, txt_file.replace(".txt", ".ft"))
            with open(new_txt_path, "w", encoding="utf-8") as f:
                f.write("\n".join(new_txt_lines) + "\n")
            with open(new_ft_path, "w", encoding="utf-8") as f:
                f.write("\n".join(new_ft_lines) + "\n")

    return ids2new, new_names
# def filter_coco_animals(original_root, new_root, animal_keywords):
#     # 原始路径
#     images_dir = os.path.join(original_root, "images")
#     labels_dir = os.path.join(original_root, "labels")
#     names_path = os.path.join(original_root, "names.txt")

#     # 新路径
#     new_images_dir = os.path.join(new_root, "images")
#     new_labels_dir = os.path.join(new_root, "labels")
#     os.makedirs(new_images_dir, exist_ok=True)
#     os.makedirs(new_labels_dir, exist_ok=True)

#     # 读取原始 names.txt
#     with open(names_path, "r", encoding="utf-8") as f:
#         orig_names = [line.strip() for line in f if line.strip()]

#     # 找出属于动物的类别 id
#     animal_ids = [i for i, name in enumerate(orig_names) if name.lower() in animal_keywords]
#     ids2new = {orig_id: new_id for new_id, orig_id in enumerate(animal_ids)}

#     # 新的 names.txt（动物类名）
#     new_names = [orig_names[i] for i in animal_ids]
#     with open(os.path.join(new_root, "names.txt"), "w", encoding="utf-8") as f:
#         f.write("\n".join(new_names) + "\n")

#     # 遍历所有标签
#     for txt_file in os.listdir(labels_dir):
#         if not txt_file.endswith(".txt"):
#             continue
#         txt_path = os.path.join(labels_dir, txt_file)
#         ft_path = os.path.splitext(txt_path)[0] + ".ft"

#         # 读取标签
#         with open(txt_path, "r", encoding="utf-8") as f:
#             txt_lines = [line.strip() for line in f if line.strip()]
#         with open(ft_path, "r", encoding="utf-8") as f:
#             ft_lines = [line.strip() for line in f if line.strip()]

#         new_txt_lines = []
#         new_ft_lines = []

#         for t_line, f_line in zip(txt_lines, ft_lines):
#             parts_txt = t_line.split()
#             parts_ft = f_line.split()
#             cls_id = int(parts_txt[0])
#             if cls_id in ids2new:
#                 new_cls = ids2new[cls_id]
#                 # 替换 txt 行的 cls
#                 parts_txt[0] = str(new_cls)
#                 new_txt_lines.append(" ".join(parts_txt))
#                 # 替换 ft 行的 cls
#                 parts_ft[0] = str(new_cls)
#                 new_ft_lines.append(" ".join(parts_ft))

#         if new_txt_lines:
#             # 复制图像
#             img_file = txt_file.replace(".txt", ".jpg")
#             src_img_path = os.path.join(images_dir, img_file)
#             dst_img_path = os.path.join(new_images_dir, img_file)
#             shutil.copy2(src_img_path, dst_img_path)

#             # 写入新的 txt / ft
#             new_txt_path = os.path.join(new_labels_dir, txt_file)
#             new_ft_path = os.path.join(new_labels_dir, txt_file.replace(".txt", ".ft"))
#             with open(new_txt_path, "w", encoding="utf-8") as f:
#                 f.write("\n".join(new_txt_lines) + "\n")
#             with open(new_ft_path, "w", encoding="utf-8") as f:
#                 f.write("\n".join(new_ft_lines) + "\n")

#     return ids2new, new_names


if __name__ == "__main__":
    original_root = "/home/yyy/zhou/datas/coco2017/train"   # 原数据集路径
    new_root = os.path.join(original_root,"out_animals3")  # 新数据集路径
    # 这里定义哪些是动物（可以改成直接读取 COCO 动物类）
    animal_keywords = {
        'bird', 'cat', 'dog', 'horse', 'sheep', 'cow', 'elephant',
        'bear', 'zebra', 'giraffe'
    }

    ids2new, new_names = filter_coco_animals(original_root, new_root, animal_keywords)
    print("原始ID到新ID映射：", ids2new)
    print("新的 names.txt：", new_names)
