# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Wuqiang Li∗, Huan Li, Biyin Zhang, Yaorong Cen, Zhenfeng Shao",
#     title   = "Group-Normalized Fourier Detection for Arbitrary-Shaped Objects",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }
import argparse
import json
import os
import sys
from pathlib import Path
from threading import Thread

import numpy as np
import torch
from tqdm import tqdm
import matplotlib.pyplot as plt

FILE = Path(__file__).absolute()
sys.path.append(FILE.parents[0].as_posix())  # add yolov5/ to path

from models.experimental import attempt_load
from models.yolo import OUT_LAYER
from utils.datasets import create_dataloader
from utils.general import coco80_to_coco91_class, check_dataset, check_file, check_img_size, check_requirements, \
    box_iou, scale_coords, xyxy2xywh, xywh2xyxy, set_logging, increment_path, colorstr, \
    PROCESS_BATCH_DICT, process_batch_line
from utils.post_process import non_max_suppression, non_max_suppression_dfl,non_max_suppression_ft
from utils.metrics import ap_per_class, ConfusionMatrix, process_batch_ft
from utils.plots import plot_images, output_to_target, plot_study_txt
from utils.torch_utils import select_device, time_sync
from utils.callbacks import Callbacks
import csv
from utils.loss import loop_loss

from copy import deepcopy

import csv # save classes_map to excel
from tools.histrans import Histrans
import pickle
import cv2
from utils.plots import Annotator, colors
from tools.plotbox import plot_one_box_with_ft
import shutil
from utils.augmentations import letterbox

from utils.ft_utils import scale_coords_ft

torch.set_printoptions(linewidth=320, precision=4, profile="default")
np.set_printoptions(linewidth=320, formatter={"float_kind": "{:11.5g}".format})  # format short g, %precision=5

def save_one_txt(predn, save_conf, shape, file):
    # Save one txt result
    gn = torch.tensor(shape)[[1, 0, 1, 0]]  # normalization gain whwh
    for *xyxy, conf, cls in predn.tolist():
        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
        line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
        with open(file, 'a') as f:
            f.write(('%g ' * len(line)).rstrip() % line + '\n')

def save_one_json(predn, jdict, path, class_map):
    # Save one JSON result {"image_id": 42, "category_id": 18, "bbox": [258.15, 41.29, 348.26, 243.78], "score": 0.236}
    image_id = int(path.stem) if path.stem.isnumeric() else path.stem
    box = xyxy2xywh(predn[:, :4])  # xywh
    box[:, :2] -= box[:, 2:] / 2  # xy center to top-left corner
    for p, b in zip(predn.tolist(), box.tolist()):
        jdict.append({'image_id': image_id,
                      'category_id': class_map[int(p[5])],
                      'bbox': [round(x, 3) for x in b],
                      'score': round(p[4], 5)})

@torch.no_grad()
def run(data,
        weights=None,  # model.pt path(s)
        batch_size=32,  # batch size
        imgsz=640,  # inference size (pixels)
        conf_thres=0.001,  # confidence threshold
        iou_thres=0.6,  # NMS IoU threshold
        task='val',  # train, val, test, speed or study
        device='',  # cuda device, i.e. 0 or 0,1,2,3 or cpu
        single_cls=False,  # treat as single-class dataset
        augment=False,  # augmented inference
        verbose=True,  # verbose output
        save_txt=False,  # save results to *.txt
        save_hybrid=False,  # save label+prediction hybrid results to *.txt
        save_conf=False,  # save confidences in --save-txt labels
        save_json=False,  # save a COCO-JSON results file
        project='runs/val',  # save to project/name
        name='exp',  # save to project/name
        exist_ok=False,  # existing project/name ok, do not increment
        half=False,  # use FP16 half-precision inference
        model=None,
        dataloader=None,
        save_dir=Path(''),
        plots=True,
        callbacks=Callbacks(),
        compute_loss=None,
        save_nms = 0,
        workers=2,
        hist=None,
        hist_path = None,
        hyp=None,
        map_hv = False,
        polygon=False,
        nms_polygon=1,
        map_dist=True,
        plot_debug = False,
        opt=None,
        ):
    # Initialize/load model and set device
    training = model is not None
    if training:  # called by train.py
        device = next(model.parameters()).device  # get model device

    else:  # called directly
        device = select_device(device, batch_size=batch_size)

        # Directories
        save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
        (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

        # Load model
        model = attempt_load(weights, map_location=device)  # load FP32 model
        gs = max(int(model.stride.max()), 32)  # grid size (max stride)
        imgsz = check_img_size(imgsz, s=gs)  # check image size

        # Multi-GPU disabled, incompatible with .half() https://github.com/ultralytics/yolov5/issues/99
        # if device.type != 'cpu' and torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)

        # Data
        data = check_dataset(data)  # check

    # 判断模型类别    
    for mname in OUT_LAYER.keys():
        m = model.get_module_byname(mname)
        if m is not None:
            dfl_flag = mname in ['DetectDFL', 'DetectDFL_FT']
            break
    _process_batch = PROCESS_BATCH_DICT[mname]
    mname = OUT_LAYER[mname]

    # Half
    half &= device.type != 'cpu'  # half precision only supported on CUDA
    if half:
        model.half()

    # Configure
    model.eval()
    is_coco = type(data['val']) is str and data['val'].endswith('coco/val2017.txt')  # COCO dataset
    nc = 1 if single_cls else int(data['nc'])  # number of classes
    iouv = torch.linspace(0.5, 0.95, 10).to(device)  # iou vector for mAP@0.5:0.95
    niou = iouv.numel()

    mask_line = getattr(model,'mask_line',None)
    # Dataloader
    if not training:
        if device.type != 'cpu':
            imgsz2 = [imgsz,imgsz] if isinstance(imgsz,int) else imgsz    
            model(torch.zeros(1, 3, imgsz2[0], imgsz2[1]).to(device).type_as(next(model.parameters())))  # run once
        task = task if task in ('train', 'val', 'test') else 'val'  # path to train/val/test images

        # Data
        data = check_dataset(data)  # check
        if hyp is not None:
            import yaml
            with open(hyp) as f:
                hyp = yaml.safe_load(f)  # load hyps dict
        val_count = data.get('val_count',0)
        
        ft_coef = (model.model[-1].ft_coef_length - 2) // 4

        dataloader = create_dataloader(data[task], imgsz2, batch_size, gs, single_cls, pad=0.5, rect=False,
                                       hyp=hyp,
                                       prefix=colorstr(f'{task}: '),
                                       save_dir=save_dir,
                                       workers=workers,
                                       sample_count=val_count,
                                       debug_samples=0,
                                       ft_coef = ft_coef,
                                       mask_line=mask_line.cpu().tolist() if mask_line is not None else None
                                    #    hist=hist
                                       )[0]
    seen = 0
    confusion_matrix = ConfusionMatrix(nc=nc)
    names = {k: v for k, v in enumerate(model.names if hasattr(model, 'names') else model.module.names)}
    s = ('%20s' + '%11s' * 8) % ('Class', 'Images', 'Labels', 'P', 'R', 'mAP@.5', 'mAP@.5:.95', 'f1', 'thresh')
    dt, p, r, f1, mp, mr, map50, map = [0.0, 0.0, 0.0], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    tags = getattr(compute_loss, 'tags', None)
    loss = torch.zeros(3 if tags is None else (len(tags) - 4), device=device)
    jdict, stats, ap, ap_class = [], [], [], []
    if map_dist:
        distv = 1 - torch.linspace(0.9, 0.99, 10).to(device)  # iou vector for mAP@0.5:0.95
    for batch_i, (img, targets, paths, shapes) in enumerate(tqdm(dataloader, desc=s, ncols=max(shutil.get_terminal_size().columns - 40, 10), dynamic_ncols=False)):
        t_ = time_sync() #targets[nt,1(b)+1(c)+4(xywh) + 2+nf*4]
        img = img.to(device, non_blocking=True)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        targets = targets.to(device) #targets[nt,1(b)+1(c)+4(xywh) + 2+nf*4]
        ##把targets_all中间的4(box)删掉了！变成了targets[nobj,10+cms+cms_mask]
        targets6 = targets[..., :6].clone().to(device)#targets6[nt,1(b)+1(cls)+4(xywh)]  targets6 means 2D information
        nb, _, height, width = img.shape  # batch size, channels, height, width
        t = time_sync()
        dt[0] += t - t_

        # Run model
        out, ft_out, train_out = model(img, augment=augment)  # inference and training outputs
        dt[1] += time_sync() - t

        # Compute loss
        if compute_loss:
            if dfl_flag:
                loss += compute_loss(train_out, targets, img.shape[2:])[1]  # loss scaled by batch_size
            else:
                loss += compute_loss([x.float() for x in train_out], targets)[1]  # box, obj, cls

        # Run NMS
        targets6[:, 2:] *= torch.Tensor([width, height, width, height]).to(device)  # to pixels
        lb = [targets[targets[:, 0] == i, 1:] for i in range(nb)] if save_hybrid else []  # for autolabelling
        t = time_sync()

        #j[b,H*W,na,1 + 4 + 3 + xyz]
        bD, hwD, _ = ft_out.shape
        pFt = ft_out
        # b, h, w, no, na

        if mname == 1:
            out = non_max_suppression_dfl(out, conf_thres, iou_thres, labels=lb, multi_label=True, agnostic=single_cls)
        elif mname in [2, 3]:
            if nms_polygon != 0:
                # 使用polygon算NMS
                out, _, indices = non_max_suppression_ft(out, pFt, conf_thres, iou_thres, labels=lb, 
                                                         multi_label=True, 
                                                         agnostic=single_cls, 
                                                         return_indices=True, 
                                                         polygon = nms_polygon==2,
                                                         mask_line=mask_line)
            else:
                out, indices = non_max_suppression_dfl(out, conf_thres, iou_thres, labels=lb, multi_label=True, agnostic=single_cls, return_indices=True)
        elif mname == 0:
            # 水平框nms
            out = non_max_suppression(out, conf_thres, iou_thres, labels=lb, multi_label=True, agnostic=single_cls,paths=paths if save_nms else None,imgsz=imgsz)

        dt[2] += time_sync() - t

        # Statistics per image
        for si, pred in enumerate(out):
            labels = targets6[targets6[:, 0] == si, 1:]#targets6[gnt,6=1(b)+1(c)+4(xywh)]-->labels[gnt,5=1(c)+4(xywh)] is objects for this b image
            nl = len(labels)
            tcls = labels[:, 0].tolist() if nl else []  # target class
            path, shape = Path(paths[si]), shapes[si][0]
            seen += 1
            nt = len(pred)
            if nt == 0:
                if nl:
                    stats.append((torch.zeros(0, niou, dtype=torch.bool), torch.Tensor(), torch.Tensor(), tcls))
                continue

            # Predictions
            if single_cls:
                pred[:, -1] = 0
            predn = pred.clone()#pred_xyxy[nt,6=4(xyxy)+1(conf)+1(cls)]
            pftn = pFt[si].clone()
            scale_coords(img[si].shape[1:], predn[:, :4], shape, shapes[si][1])#model-letterbox shape:img[si].shape[1:] -> 原图shape:shape
            #   pred:640, 640 -> ori image  x,y,w,h (abs)
            # Evaluate
            if nl:
                pad_w, pad_h = shapes[si][1][1]
                height_no_letter, width_no_letter = img[si].shape[-2] - 2 * pad_h, img[si].shape[-1] - 2 * pad_w
                height0, width0 = shape     # origin img shape
                tbox = xywh2xyxy(labels[:, 1:5])  # target boxes
                scale_coords(img[si].shape[1:], tbox, shape, shapes[si][1])  # native-space labels
                labelsn = torch.cat((labels[:, 0:1], tbox), 1)  # native-space labels
                
                # labels_ft [/wh]
                labels_ft = targets[targets6[:, 0] == si, 6:].clone()
                labels_ft[:, 0]  = (labels_ft[:, 0] * img[si].shape[-1] - pad_w) / width_no_letter * width0   # [letter box] to [origin]
                labels_ft[:, 1]  = (labels_ft[:, 1] * img[si].shape[-2] - pad_h) / height_no_letter * height0
                w_r, h_r = width0 / width_no_letter, height0 / height_no_letter
                labels_ft[:, 2:] = labels_ft[:, 2:] * torch.Tensor([width, width, height, height]).to(device).repeat((labels_ft.shape[-1]-2) // 4).view(1, -1) \
                                    * torch.Tensor([w_r, w_r, h_r, h_r]).to(device).repeat((labels_ft.shape[-1]-2) // 4).view(1, -1)
                
                # pftn
                pftn = pftn[indices[si]]
                pftn = scale_coords_ft(img[si].shape[1:], pftn, shape, None)
                # w_r, h_r = width0 / width_no_letter, height0 / height_no_letter
                # # pftn[:, :2] = pftn[:, :2] * torch.Tensor([w_r, h_r]).to(device)
                # pftn[:, 0]  = (pftn[:, 0] - pad_w) / width_no_letter * width0    # [letter box] to [origin]
                # pftn[:, 1]  = (pftn[:, 1] - pad_h) / height_no_letter * height0
                # pftn[:, 2:] = pftn[:, 2:] * torch.Tensor([w_r, w_r, h_r, h_r]).to(device).repeat((labels_ft.shape[-1]-2) // 4).view(1, -1)
                
                line_flag = False
                if mask_line is not None:
                    line_mask_gt = torch.gather(mask_line, 0, labelsn[:, 0].long()).bool()    # bool
                    if line_mask_gt.sum() > 0:
                        labelsn_line = labelsn[line_mask_gt]
                        labelsn = labelsn[~line_mask_gt]
                        labels_ft_line = labels_ft[line_mask_gt]
                        labels_ft = labels_ft[~line_mask_gt]
                    line_mask = torch.gather(mask_line, 0, predn[:, -1].long()).bool()    # bool
                    if line_mask.sum() > 0:
                        predn_line = predn[line_mask]
                        predn = predn[~line_mask]
                        pftn_line = pftn[line_mask]
                        pftn_line[:, 3::2] = 0.
                        pftn = pftn[~line_mask]
                        if map_dist:
                            correct_line, matches_line = process_batch_line(pftn_line, labels_ft_line,
                                                                            d_c=predn_line[:, 5], 
                                                                            l_c=labelsn_line[:, 0:1],
                                                                            distv=distv)
                        else:
                            correct_line, matches_line = _process_batch(predn_line, labelsn_line, iouv)
                    else:
                        correct_line = torch.zeros(0, niou, dtype=torch.bool).to(device)
                        matches_line = torch.zeros(0, 3, dtype=torch.float32).to(device)
                    line_flag = True
                if len(predn) == 0:
                    # 无封闭类的预测框
                    correct = torch.zeros(0, niou, dtype=torch.bool).to(device)
                    matches = torch.zeros(0, 3, dtype=torch.float32).to(device)
                else:
                    if len(labelsn) == 0:
                        # 无封闭类的GT框
                        correct = torch.zeros(predn.shape[0], niou, dtype=torch.bool).to(device)
                        matches = torch.zeros(0, 3, dtype=torch.float32).to(device)
                    else:
                        if map_hv:
                            correct, matches = _process_batch(predn, labelsn, iouv)
                        # 傅里叶的map
                        else:
                            correct, matches = process_batch_ft(detections_ft=pftn, 
                                                                    labels_ft=labels_ft, 
                                                                    d_c=predn[:, 5], 
                                                                    l_c=labelsn[:, 0],
                                                                    iouv=iouv,
                                                                    polygon=polygon)   
                if line_flag:
                    correct = torch.cat([correct, correct_line], dim=0)
                    matches = torch.cat([matches, matches_line], dim=0)

                
                if plot_debug:
                    name = os.path.splitext(os.path.basename(path))[0]
                    debug_samples_path = save_dir / 'visual'
                    debug_samples_path.mkdir(exist_ok=True)
                    f_name = f'{debug_samples_path}/LgtRval_{name}.jpg'
                    if line_flag:
                        pcls_plot = torch.cat([predn[:, -1], predn_line[:, -1]], dim=0)
                        pbox = torch.cat([predn[:, :4], predn_line[:, :4]], dim=0)
                        pred_ft = torch.cat([pftn, pftn_line], dim=0)
                        conf = torch.cat([predn[:, 4], predn_line[:, 4]], dim=0)
                        labels_ft = torch.cat([labels_ft, labels_ft_line], dim=0)
                        tcls_plot = torch.cat([labelsn[:, 0], labelsn_line[:, 0]], dim=0)
                        tbox = torch.cat([labelsn[:, 1:], labelsn_line[:, 1:]], dim=0)
                    else:
                        pcls_plot = predn[:, -1]
                        pbox = predn[:, :4]
                        pred_ft = pftn
                        conf = predn[:, 4]
                        tcls_plot = labelsn[:, 0]

                    if not Path(f_name).exists():
                        im0 = cv2.imdecode(np.fromfile(path, dtype=np.uint8),cv2.IMREAD_COLOR)#cv2.imread(path)  # BGR
                        # img = letterbox(im0, shape)
                        im1 = im0.copy()
                        for i_, ((xyxy), ft_label) in enumerate(zip(pbox.cpu().numpy(), pred_ft.cpu().numpy())):
                            cls_ = int(pcls_plot[i_])
                            conf_ = conf[i_].item()
                            # if conf_ < 0.05:     ##### 不画阈值太低的 #####
                            #     continue
                            # print(ft_label)
                            # pred
                            label = '{} {:.2f}'.format(names[cls_], conf_)
                            plot_one_box_with_ft(np.array(xyxy), im1, 
                                                color=colors(cls_), 
                                                label=label, line_thickness=3,
                                                ft_label=ft_label,
                                                show_amp=0,
                                                show_box=True)
                            
                        # gt
                        for i_, (xyxy, ft_label) in enumerate(zip(tbox.cpu().numpy(), labels_ft.cpu().numpy())):
                            cls_ = int(tcls_plot[i_])
                            label = '{}'.format(names[cls_])
                            plot_one_box_with_ft(np.array(xyxy), im0, 
                                                color=colors(cls_), 
                                                label=label, line_thickness=3,
                                                ft_label=ft_label,
                                                show_amp=0,
                                                show_box=True)
                        im0 = np.concatenate([im0, im1], axis=1) # 在横向拼接
                        cv2.imencode('.jpg', im0)[1].tofile(f_name)
                if plots:
                    confusion_matrix.process_batch(predn, labelsn)
            else:
                correct = torch.zeros(pred.shape[0], niou, dtype=torch.bool)
            stats.append((correct.cpu(), pred[:, 4].cpu(), pred[:, 5].cpu(), tcls))  # (correct, conf, pcls, tcls)
            # Save/log
            if save_txt:
                save_one_txt(predn, save_conf, shape, file=save_dir / 'labels' / (path.stem + '.txt'))
            callbacks.on_val_image_end(pred, predn, path, names, img[si])

        # Plot images
        if False and plots and batch_i < 3:
            f = save_dir / f'val_batch{batch_i}_labels.jpg'  # labels
            Thread(target=plot_images, args=(img, targets, paths, f, names), daemon=True).start()
            f = save_dir / f'val_batch{batch_i}_pred.jpg'  # predictions
            Thread(target=plot_images, args=(img, output_to_target(out), paths, f, names), daemon=True).start()
    # Compute statistics
    # Print results
    pf = '%20s' + '%11i' * 2 + '%11.4g' * 6  # print format
    # Compute metrics
    stats = [np.concatenate(x, 0) for x in zip(*stats)]  # to numpy

    if len(stats) and stats[0].any():
        p, r, ap, f1, ap_class, threshs,py = ap_per_class(*stats, plot=plots, save_dir=save_dir, names=names, cut=True)
        #p[nc] r[nc] ap[nc,10] f1[nc] ap_class[nc] threshs[nc]
        # 保存到文件
        with open(save_dir / 'status.pkl', 'wb') as f:
            pickle.dump([py,ap,names], f)
        ap50, ap = ap[:, 0], ap.mean(1)  # AP@0.5, AP@0.5:0.95
        mp, mr, map50, map = p.mean(), r.mean(), ap50.mean(), ap.mean()
        nt = np.bincount(stats[3].astype(np.int64), minlength=nc)  # number of targets per class
        train_path = weights.parent.parent if not training and not isinstance(weights, str) else save_dir
        np.save(train_path / 'threshs.npy', threshs)
        #np.save(train_path / 'stats.npy', stats)
    else:
        nt = torch.zeros(1)
        f1 = torch.zeros(1)
        threshs = torch.zeros(1)

    print('\033[32m',pf % ('all', seen, nt.sum(), mp, mr, map50, map, f1.mean(), threshs.mean()),'\033[0m',sep='')
    # Print results per classc
    if (verbose or (nc < 50 and not training)) and nc >= 1 and len(stats):
        for i, c in enumerate(ap_class):
            if nt[c] > 0:
                color_arg = '\033[44m' if mask_line is not None and int(mask_line[c]) == 1 else '\033[32m'
                print(color_arg, pf % (names[c], seen, nt[c], p[i], r[i], ap50[i], ap[i], f1[i], threshs[i]),'\033[0m',sep='')
        with open(save_dir / 'classes_map.csv', 'w', newline='') as file_map:
            writer = csv.writer(file_map)
            writer.writerow(['Class', 'Images', 'Labels', 'P', 'R', 'mAP@.5', 'mAP@.5:.95', 'f1', 'thresh'])
            writer.writerow([f'{a:.6f}' if not isinstance(a, str) else a for a in ["all", seen, nt.sum(), mp, mr, map50, map, f1.mean(), threshs.mean()] ])
            # Print results per class
            for i, c in enumerate(ap_class):
                class_name = names.get(c, "Unknown")  # 如果 c 不在 names 中，返回 "Unknown"
                writer.writerow([f'{a:.6f}' if not isinstance(a, str) else a for a in [class_name, seen, nt[c], p[i], r[i], ap50[i], ap[i], f1[i], threshs[i]]])



    # Print speeds
    t = tuple(x / seen * 1E3 for x in (dt[0], dt[1], dt[2]))  # speeds per image
    if not training:
        shape = (batch_size, 3, imgsz, imgsz)
        print(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {shape}' % t)

    # Plots
    if plots:
        confusion_matrix.plot(save_dir=save_dir, names=list(names.values()))
        callbacks.on_val_end()

    # Save JSON
    if save_json and len(jdict):
        w = Path(weights[0] if isinstance(weights, list) else weights).stem if weights is not None else ''  # weights
        anno_json = str(Path(data.get('path', '../coco')) / 'annotations/instances_val2017.json')  # annotations json
        pred_json = str(save_dir / f"{w}_predictions.json")  # predictions json
        print(f'\nEvaluating pycocotools mAP... saving {pred_json}...')
        with open(pred_json, 'w') as f:
            json.dump(jdict, f)

        try:  # https://github.com/cocodataset/cocoapi/blob/master/PythonAPI/pycocoEvalDemo.ipynb
            check_requirements(['pycocotools'])
            from pycocotools.coco import COCO
            from pycocotools.cocoeval import COCOeval

            anno = COCO(anno_json)  # init annotations api
            pred = anno.loadRes(pred_json)  # init predictions api
            eval = COCOeval(anno, pred, 'bbox')
            if is_coco:
                eval.params.imgIds = [int(Path(x).stem) for x in dataloader.dataset.img_files]  # image IDs to evaluate
            eval.evaluate()
            eval.accumulate()
            eval.summarize()
            map, map50 = eval.stats[:2]  # update results (mAP@0.5:0.95, mAP@0.5)
        except Exception as e:
            print(f'pycocotools unable to run: {e}')

    # Return results
    model.float()  # for training
    if not training:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        print(f"Results saved to {colorstr('bold', save_dir)}{s}")
    maps = np.zeros(nc) + map
    for i, c in enumerate(ap_class):
        maps[c] = ap[i]
    return (mp, mr, map50, map, f1.mean(), *(loss.cpu() / len(dataloader)).tolist()), maps, t


def parse_opt():
    parser = argparse.ArgumentParser(prog='val.py')
    parser.add_argument('--data', type=str, default='data/coco128.yaml', help='dataset.yaml path')
    parser.add_argument('--weights', nargs='+', type=str, default='yolov5s.pt', help='model.pt path(s)')
    parser.add_argument('--batch-size', type=int, default=16, help='batch size')
    parser.add_argument('--imgsz', '--img', '--img-size', type=list, default=[640,640], help='inference size (pixels)')
    parser.add_argument('--conf-thres', type=float, default=0.001, help='confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.6, help='NMS IoU threshold')
    parser.add_argument('--task', default='val', help='train, val, test, speed or study')
    parser.add_argument('--device', default='0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--single-cls', action='store_true', help='treat as single-class dataset')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--verbose', action='store_true', help='report mAP by class')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-hybrid', action='store_true', help='save label+prediction hybrid results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--save-json', action='store_true', help='save a COCO-JSON results file')
    parser.add_argument('--project', default='runs/val', help='save to project/name')
    parser.add_argument('--name', default='exp', help='save to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')
    parser.add_argument('--save_nms', type=int, default=0, help='save_nms')
    parser.add_argument('--hyp', type=str, default='hyps/hyp.scratch.yaml', help='hyperparameters path')
    parser.add_argument('--map_hv', action='store_true', help='use hv coefs to calc map')
    parser.add_argument('--polygon', default=True, action='store_true', help='use polygon to calc map')
    parser.add_argument('--nms_polygon', type=int, default=1, help='use polygon for NMS') #2 = poly nms, 1 = 1 order nms, 0=HBox nms
    parser.add_argument('--map_dist', action='store_true', help='map dist')
    parser.add_argument('--plot_debug', action='store_true', help='plot_debug')
    
    opt = parser.parse_args()
    #general
    # opt.weights = 'runs/train/exp5/weights/last.pt' #'weights/yolov5s.pt'
    # if 0:
    #     opt.data = 'data/coco2017.yaml'
    #     opt.imgsz = [640, 640]
    # else:
    #     opt.data = 'data/road_dlsb417-total.yaml'
    #     opt.imgsz = [896,896]
    #coco2017
    # opt.hyp = 'hyps/hyp.scratch-dfl-H.yaml'
    # opt.data = 'data/coco_ft.yaml'
    # opt.weights = '../models/coco_ft/coco_ft-yolov11m-ft-bs16-61.63-27.05-epo99-640x640/weights/best.pt'
    # opt.imgsz = [640, 640]
    # opt.nms_polygon = 0

    #coco128
    # opt.hyp = 'hyps/hyp.scratch-dfl.yaml'
    # opt.data = r'data/coco_ft.yaml'
    # opt.weights = r'weights/best.pt'
    # opt.imgsz = [640, 640]

    #track-345
    # opt.weights = '../models/track-345/track-345-yolov11s-obb-bs16-99.36-93.26-epo99-640x640-11/weights/best.pt'
    # opt.weights = 'runs/train/exp2/weights/best.pt'
    # opt.imgsz = [896,896]
    # opt.data = 'data/track-345.yaml' #get_source('','data/track-345.yaml')
    # opt.nms_polygon = 1

    #road_lines
    # opt.hyp = 'hyps/hyp.scratch-dfl.yaml'
    # opt.data = r'data/road_lines.yaml'
    # # opt.weights = r'../models/road_lines/road_lines-90.58-62.18/weights/best_map50.pt'
    # opt.weights = '/home/liu/workspace/yolov5/yolov5-dfl-ft/yolov5-ftv11-mask_line/runs/train/road_lines-yolov11s-ft-bs16-94.97-75.91-epo70-2-640x640/weights/best.pt'
    # opt.imgsz = [640, 640]
    # opt.polygon = True
    # opt.nms_polygon = 0
    # opt.iou_thres = 0.6
    # opt.map_dist = True
    # opt.task = 'val'
    # opt.device = '3'

    #voc_segment
    # opt.data = 'data/voc_segment_ft.yaml'
    # # opt.weights = '../models/voc_segment/voc_segment_ft-yolov11l-ft-bs16-70.32-37.74/weights/best.pt'
    # opt.weights = '../models/voc_segment/voc_segment_ft-yolov11s-ft-bs16-69.18-44.23-epo99-640x640/weights/best_map50.pt'
    # opt.imgsz = [640, 640]

    #cityscapes
    # opt.hyp = 'hyps/hyp.scratch-dfl.yaml'
    # opt.data = r'data/cityscapes_ft.yaml'
    # # opt.weights = r'../models/cityscapes/cityscapes_ft-yolov11l-ft-bs16-56.15-31.07-a0c0+coef/weights/last.pt'
    # # opt.weights = r'../models/cityscapes/cityscapes_ft-yolov11s-ft-bs16-50.15-20.11-epo99-640x640-ft_gain=True/weights/last.pt'
    # # opt.weights = 'runs/train/cityscapes_ft-yolov11s-ft-bs16-53.06-27.91-epo99-2-640x640/weights/best.pt'
    # # opt.imgsz = [640, 640]
    # opt.polygon = True
    # # opt.plot_debug = False
    # opt.nms_polygon = 0
    # opt.iou_thres = 0.7
    # opt.device = '2'

    #isAID
    # opt.hyp = 'hyps/hyp.scratch-dfl.yaml'
    # opt.data = 'data/isAID-hull_ft.yaml'
    # # opt.weights = '../models/isAID/isAID-hull_ft-yolov11s-ft-bs16-71.85-39.12-gauss8/weights/best.pt'
    # # opt.weights = '../models/isAID/isAID-hull3_ft-yolov11s-ft-bs16-71.75-37.90-epo99-5-640x640/weights/best.pt'
    # # opt.weights = '../models/isAID/isAID-hull_ft-yolov11s-ft-bs16-71.98-40.54-epo99-640x640/weights/best.pt'
    # opt.weights = 'runs/train/isAID-hull_ft-yolov11s-ft-bs16-71.53-38.86-epo99-640x640/weights/best_map50.pt'
    # # opt.weights = 'runs/train/exp2/weights/last.pt'
    # opt.imgsz = [640, 640]
    # opt.nms_polygon = 1
    # opt.polygon = True

    #
    #Chikusei_JPG
    opt.data = 'data/Chikusei_JPG-ft.yaml'
    # opt.weights = '../models/Chikusei_JPG/Chikusei_JPG-ft-yolov5s-guge_ft-bs16-81.38-47.67-epo499-_Chikusei_JPG-ft2-GNF=1/weights/best.pt'
    opt.weights = 'runs/train/exp/weights/best.pt'
    opt.imgsz = [640,640]
    opt.nms_polygon = 1
    #
    
    #hrsid
    # opt.data = 'data/hrsid_ft.yaml'
    # opt.weights = '../models/hrsid/hrsid_ft-yolov11s-ft-bs16-86.20-48.57-800x800-hist-gauss-abs/weights/best.pt'
    # opt.imgsz = [800, 800]

    #mstar
    # opt.data = 'data/mstar_ft.yaml'
    # opt.weights = '../models/mstar/mstar_ft-yolov11m-ft-bs16-78.32-58.87-epo149-KAF/weights/best_map50.pt'
    # opt.imgsz = [640, 640]
    # opt.nms_polygon = 1

    # infared-pol
    # opt.data = 'data/infared_ft.yaml'
    # opt.weights = r'../models/infared/infared_ft-yolov11s-ft-bs16-96.11-46.73-val400/weights/best.pt'
    # opt.imgsz = [640, 640]

    # OTCBVS_D1_ft
    # opt.data = 'data/OTCBVS_D1_ft.yaml'
    # opt.weights = r'runs/train/exp2/weights/best.pt'
    # opt.imgsz = [640, 640]

    # road_seg
    # opt.data = 'data/road_seg_ft.yaml'
    # opt.imgsz = [640, 896] #[640, 640]
    # opt.batch_size = 16
    # opt.weights = 'runs/train/exp37/weights/best.pt'

    #hrsc2016
    # opt.data = 'data/hrsc2016_ft.yaml'
    # opt.weights = r'../models/hrsc2016/hrsc2016_ft-yolov11s-ft12-bs16-89.43-50.13-epo299/weights/best.pt' #'yolov11s.pt'#'weights/yolov5m.pt'

    opt.save_json |= opt.data.endswith('coco.yaml')
    opt.save_txt |= opt.save_hybrid
    opt.data = check_file(opt.data)  # check file
    return opt


def main(opt):
    set_logging()
    print(colorstr('val: ') + ', '.join(f'{k}={v}' for k, v in vars(opt).items()))
    # check_requirements(requirements=FILE.parent / 'requirements.txt', exclude=('tensorboard', 'thop'))

    if opt.task in ('train', 'val', 'test'):  # run normally
        run(**vars(opt))

    elif opt.task == 'speed':  # speed benchmarks
        for w in opt.weights if isinstance(opt.weights, list) else [opt.weights]:
            run(opt.data, weights=w, batch_size=opt.batch_size, imgsz=opt.imgsz, conf_thres=.25, iou_thres=.45,
                save_json=False, plots=False)

    elif opt.task == 'study':  # run over a range of settings and save/plot
        # python val.py --task study --data coco.yaml --iou 0.7 --weights yolov5s.pt yolov5m.pt yolov5l.pt yolov5x.pt
        x = list(range(256, 1536 + 128, 128))  # x axis (image sizes)
        for w in opt.weights if isinstance(opt.weights, list) else [opt.weights]:
            f = f'study_{Path(opt.data).stem}_{Path(w).stem}.txt'  # filename to save to
            y = []  # y axis
            for i in x:  # img-size
                print(f'\nRunning {f} point {i}...')
                r, _, t = run(opt.data, weights=w, batch_size=opt.batch_size, imgsz=i, conf_thres=opt.conf_thres,
                              iou_thres=opt.iou_thres, save_json=opt.save_json, plots=False)
                y.append(r + t)  # results and times
            np.savetxt(f, y, fmt='%10.4g')  # save
        os.system('zip -r study.zip study_*.txt')
        plot_study_txt(x=x)  # plot


if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
