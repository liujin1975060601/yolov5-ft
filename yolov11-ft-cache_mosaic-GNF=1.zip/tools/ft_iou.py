from shapely.geometry import Polygon
import os
import numpy as np
import torch
import warnings

# def is_valid_coords(pts):
#     return all(not (np.isnan(x) and not (np.isinf(x)) for pt in pts for x in pt))

def polygon_iou(poly1_pts, poly2_pts):
    # poly1_pts, poly2_pts: list of (x, y) tuples representing polygon vertices.
    poly1 = Polygon(poly1_pts)
    poly2 = Polygon(poly2_pts)

    # 修复无效多边形
    # if not poly1.is_valid:
    poly1 = poly1.buffer(0)
    # if not poly2.is_valid:
    poly2 = poly2.buffer(0)

    if poly1.is_valid and poly2.is_valid: # and is_valid_coords(poly1) and is_valid_coords(poly2):
        try:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=RuntimeWarning) 
                inter_area = poly1.intersection(poly2).area
            union_area = poly1.union(poly2).area
            if union_area > 0:
                return inter_area / union_area
            else:
                print('# 交集为空')
                return 0.0
        except:
            return 0.0
    else:
        print('# 无效多边形')
        return 0.0  # 无效多边形


def read_ft(ft_file):
    if os.path.exists(ft_file):
        with open(ft_file) as f: #.dir (4)
            l_ft = [x.split() for x in f.read().strip().splitlines() if len(x)]#l_ft[nt][str[4]]
            l_ft = np.array(l_ft, dtype=np.float32)#list转np矩阵 l_ft[nt][str[4]]-->l_ft[nt,4])
    else:
        return None
    return l_ft

def get_curve(ft_label,num=200):
    theta_fine = np.linspace(0, 2*np.pi, num)
    an,bn,cn,dn = np.split(ft_label[2:].reshape(-1, 4), 4, axis=-1)
    an,bn,cn,dn = np.insert(an,0,ft_label[0]),np.insert(bn,0,0),np.insert(cn,0,ft_label[1]),np.insert(dn,0,0)

    def ft2xy(an,bn,cn,dn,theta_fine,term):
        term = an.shape[0] if term<=0 else term
        x_approx = sum([an[i]*np.cos(i*theta_fine) + bn[i]*np.sin(i*theta_fine) for i in range(term)])
        y_approx = sum([cn[i]*np.cos(i*theta_fine) + dn[i]*np.sin(i*theta_fine) for i in range(term)])
        return x_approx,y_approx
    
    x_approx,y_approx = ft2xy(an,bn,cn,dn,theta_fine,0)#an.shape[0]
    contour_approx = np.array(list(zip(x_approx, y_approx))).reshape((-1, 2))
    # cv2.polylines(img, [contour_approx], isClosed=True, color=color, thickness=2)
    return contour_approx       # 200, 1, 2

def box_iou(box1, box2):
    """
    Return intersection-over-union (Jaccard index) of boxes.
    Both sets of boxes are expected to be in (x1, y1, x2, y2) format.
    
    Arguments:
        box1 (np.ndarray[N, 4])
        box2 (np.ndarray[M, 4])
    
    Returns:
        iou (np.ndarray[N, M]): the NxM matrix containing the pairwise
            IoU values for every element in boxes1 and boxes2
    """
    def box_area(box):
        return (box[:, 2] - box[:, 0]) * (box[:, 3] - box[:, 1])
    
    area1 = box_area(box1)  # (N,)
    area2 = box_area(box2)  # (M,)
    
    # Calculate intersection areas
    lt = np.maximum(box1[:, np.newaxis, :2], box2[:, :2])  # (N, M, 2)
    rb = np.minimum(box1[:, np.newaxis, 2:], box2[:, 2:])  # (N, M, 2)
    
    wh = (rb - lt).clip(min=0)       # (N, M, 2)
    inter = wh[:, :, 0] * wh[:, :, 1]  # (N, M)
    
    # Calculate union areas
    union = area1[:, None] + area2 - inter  # (N, M)
    
    # Avoid division by zero
    iou = inter / np.maximum(union, 1e-7)
    return iou

def polygon_iou_ft(ft_1, ft_2, classes_1=None, classes_2=None):
    ft_1 = ft_1.cpu().numpy().astype(np.float64)
    ft_2 = ft_2.cpu().numpy().astype(np.float64)
    ft_1_curve = np.stack([get_curve(ft) for ft in ft_1])
    ft_2_curve = np.stack([get_curve(ft) for ft in ft_2])
    ft_1_xyxy = np.concatenate([np.amin(ft_1_curve, axis=1), np.amax(ft_1_curve, axis=1)], axis=-1)
    ft_2_xyxy = np.concatenate([np.amin(ft_2_curve, axis=1), np.amax(ft_2_curve, axis=1)], axis=-1)

    bbox_iou = box_iou(ft_1_xyxy, ft_2_xyxy)

    # import torch
    # import sys
    # sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # from utils.general import box_iou_ft
    # ft_1_torch = torch.from_numpy(ft_1)
    # ft_2_torch = torch.from_numpy(ft_1)
    # for labels_ft in [ft_1_torch, ft_2_torch]:
    #     labels_ft[:, :2] = labels_ft[:, :2] * torch.Tensor([w, h])
    #     labels_ft[:, 2:] = labels_ft[:, 2:] * torch.Tensor([w, w, h, h]).repeat((labels_ft.shape[-1]-2) // 4).view(1, -1)
    # bbox_iou = box_iou_ft(ft_1_torch, ft_2_torch).numpy()

    if (classes_1 is not None) and (classes_2 is not None):
        assert classes_1.shape[0] == ft_1.shape[0]
        assert classes_2.shape[0] == ft_2.shape[0]
        bbox_iou[(classes_1.reshape(-1, 1) != classes_2.reshape(1, -1)).detach().cpu().numpy()] = 0.
    for i in range(bbox_iou.shape[0]):
        for j in range(bbox_iou.shape[1]):
            if bbox_iou[i, j] > 0:
                bbox_iou[i, j] = polygon_iou(ft_1_curve[i], ft_2_curve[j])
    return bbox_iou
    

def xywh2xyxy(x):
    """
    Convert bounding box coordinates from (x, y, width, height) format to (x1, y1, x2, y2) format where (x1, y1) is the
    top-left corner and (x2, y2) is the bottom-right corner. Note: ops per 2 channels faster than per channel.

    Args:
        x (np.ndarray | torch.Tensor): The input bounding box coordinates in (x, y, width, height) format.

    Returns:
        y (np.ndarray | torch.Tensor): The bounding box coordinates in (x1, y1, x2, y2) format.
    """
    assert x.shape[-1] == 4, f"input shape last dimension expected 4 but input shape is {x.shape}"
    xy = x[..., :2]  # centers
    wh = x[..., 2:] / 2  # half width-height
    return (np.concatenate if isinstance(x, np.ndarray) else torch.cat)((xy - wh, xy + wh), -1)


def polygon_iou_hv(ft_1, hv_2, classes_1=None, classes_2=None, xywh=False):
    ft_1 = ft_1.cpu().numpy().astype(np.float64)
    if xywh:
        hv_2 = xywh2xyxy(hv_2)
    hv_2 = hv_2.cpu().numpy().astype(np.float64)
    # ft_2 = ft_2.cpu().numpy().astype(np.float64)
    ft_1_curve = np.stack([get_curve(ft) for ft in ft_1])
    # ft_2_curve = np.stack([get_curve(ft) for ft in ft_2])
    ft_1_xyxy = np.concatenate([np.amin(ft_1_curve, axis=1), np.amax(ft_1_curve, axis=1)], axis=-1)
    # ft_2_xyxy = np.concatenate([np.amin(ft_2_curve, axis=1), np.amax(ft_2_curve, axis=1)], axis=-1)
    hv_2_curve = np.stack([np.array(hv[[0,1,0,3,2,3,2,1]]).reshape(-1, 2) for hv in hv_2])

    bbox_iou = box_iou(ft_1_xyxy, hv_2)

    # import torch
    # import sys
    # sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # from utils.general import box_iou_ft
    # ft_1_torch = torch.from_numpy(ft_1)
    # ft_2_torch = torch.from_numpy(ft_1)
    # for labels_ft in [ft_1_torch, ft_2_torch]:
    #     labels_ft[:, :2] = labels_ft[:, :2] * torch.Tensor([w, h])
    #     labels_ft[:, 2:] = labels_ft[:, 2:] * torch.Tensor([w, w, h, h]).repeat((labels_ft.shape[-1]-2) // 4).view(1, -1)
    # bbox_iou = box_iou_ft(ft_1_torch, ft_2_torch).numpy()

    if (classes_1 is not None) and (classes_2 is not None):
        assert classes_1.shape[0] == ft_1.shape[0]
        assert classes_2.shape[0] == hv_2_curve.shape[0]
        bbox_iou[(classes_1.reshape(-1, 1) != classes_2.reshape(1, -1)).detach().cpu().numpy()] = 0.
    for i in range(bbox_iou.shape[0]):
        for j in range(bbox_iou.shape[1]):
            if bbox_iou[i, j] > 0:
                bbox_iou[i, j] = polygon_iou(ft_1_curve[i], hv_2_curve[j])
    return bbox_iou
    
def polygon_nms_ft(fts, scores, cls, thresh=0.45, cls_offset=0, h_thresh_dec=0.6,dif_cls_iou_thresh=1.1): #fts[np,2+4n]  cls[np]  scores[np]
    fts = fts.cpu().numpy().astype(np.float64)
    if cls_offset:
        fts[:, :2] = fts[:, :2] + cls[:,None] * 4096
    fts_curve = np.stack([get_curve(ft) for ft in fts]) #fts_curve[np,npts,2(xy)]
    fts_xyxy = np.concatenate([np.amin(fts_curve, axis=1), np.amax(fts_curve, axis=1)], axis=-1) #fts_xyxy[np,4(xyxy)]

    order = scores.cpu().numpy().argsort()[::-1].copy() #order[np]
    keep = []
    while order.size > 0:
        order_i = order[0]
        keep.append(order_i)
        cls_i = cls[order_i]

        if order.size == 1:
            break
        
        next_order = order[1:] #next_order[np-1]
        hbb_ord_iou = box_iou(fts_xyxy[order_i:order_i+1], fts_xyxy[next_order])[0] #iou[1,np-1]-->hbb_ord_iou[np-1] 注:这里1:是后面+1的原因
        cls_ord = cls[next_order] #cls_ord[np-1]
        assert hbb_ord_iou.shape[0]==cls_ord.shape[0]
        h_ord_ids = np.where(hbb_ord_iou > h_thresh_dec * thresh)[0]  #与第order_i框hbb有重叠的框order索引  h_ord_ids[nh]
        ids = next_order[h_ord_ids] #注意前面是order[1:]，所以+1 -->ids[nh]

        iou = [polygon_iou(fts_curve[order_i], fts_curve[tmp]) for tmp in ids] #iou[nh]
        hbb_ord_iou[h_ord_ids] = np.array(iou) #list可以复制给一个等大的numpy  hbb_ord_iou[nh]-->hbb_ord_iou[np-1]
        #
        same_cls_mask = cls_ord==cls_i #same_cls[np-1]
        if dif_cls_iou_thresh >= 1.0:
            # 类别逻辑：同类 IoU > thresh 删除，其他保留
            keep_mask = (~same_cls_mask) | (hbb_ord_iou <= thresh)
        else:
            diff_cls_mask = ~same_cls_mask
            # 初始化全保留
            keep_mask = np.ones_like(hbb_ord_iou, dtype=bool)
            # 相同类：Polygon IOU > thresh 就去掉
            keep_mask[same_cls_mask] = hbb_ord_iou[same_cls_mask] <= thresh
            # 不同类：Polygon IOU > dif_cls_iou_thresh 也去掉
            keep_mask[diff_cls_mask] = hbb_ord_iou[diff_cls_mask] <= dif_cls_iou_thresh
            #
            # ord_inds_same = np.where(hbb_ord_iou[ same_cls] <= thresh)[0] #hbb_ord_iou[np]-> ord_inds[nids] 留下iou小的就是不重复的框
            # ord_inds_diff = np.where(hbb_ord_iou[~same_cls] <= 1.0)[0] #hbb_ord_iou[np]-> ord_inds[nids] 留下iou小的就是不重复的框
            # ord_inds = np.concatenate([ord_inds_same, ord_inds_diff])
            # # order = order[ord_inds + 1] #注意前面是order[1:]，所以+1
            # order = next_order[ord_inds]

        # 更新剩余顺序
        order = next_order[keep_mask]
            
    return np.asarray(keep, dtype=int)

def polygon_nms_ft_ok(fts, scores, cls, thresh=0.45):
    fts = fts.cpu().numpy().astype(np.float64)
    scores = scores.cpu().numpy()

    fts_curve = np.stack([get_curve(ft) for ft in fts])  # [N, npts, 2]
    fts_xyxy = np.concatenate([
        np.amin(fts_curve, axis=1), np.amax(fts_curve, axis=1)
    ], axis=-1)  # [N, 4]

    order = scores.argsort()[::-1].copy()
    keep = []

    while order.size > 0:
        order_i = order[0]
        keep.append(order_i)
        cls_i = cls[order_i]

        if order.size == 1:
            break

        next_order = order[1:]
        hbb_ord_iou = box_iou(fts_xyxy[order_i:order_i+1], fts_xyxy[next_order])[0]
        cls_ord = cls[next_order]

        h_ord_ids = np.where(hbb_ord_iou > 0)[0]
        ids = next_order[h_ord_ids]

        iou = [polygon_iou(fts_curve[order_i], fts_curve[tmp]) for tmp in ids]
        hbb_ord_iou[h_ord_ids] = np.array(iou)

        # 类别逻辑：同类 IoU > thresh 删除，其他保留
        keep_mask = (cls_ord != cls_i) | (hbb_ord_iou <= thresh)
        order = next_order[keep_mask]

    return np.asarray(keep, dtype=int)



if __name__ == '__main__':
    from pathlib import Path
    ft_file = Path('~/workspace/datas/coco2017/train/labels/000000000009.ft').expanduser().resolve()
    img_file = Path('~/workspace/datas/coco2017/train/images/000000000009.jpg').expanduser().resolve()
    from PIL import Image, ImageDraw
    import cv2
    img = Image.open(img_file)
    w, h = img.size
    draw = ImageDraw.Draw(img)
    ft = read_ft(ft_file)

    ious = polygon_iou_ft(ft[:, 1:], ft[:, 1:], ft[:, :1], ft[:, :1])
    print()
    # import torch
    
    # import sys
    # sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    # from utils.general import box_iou_ft

    # if ft.shape[0] > 0:
    #     ft = ft[0][1:]
    #     assert ft.shape[0] % 2 == 0
    #     ft1 = ft.copy()
    #     ft1[:2] +=  np.asarray([10 / w, 50 / h])
    #     cont = get_curve(ft).reshape((-1, 2)) * np.asarray([[w, h]])
    #     cont1 = get_curve(ft1).reshape((-1, 2)) * np.asarray([[w, h]])

    #     # 将多边形的坐标提取出来
    #     poly1 = Polygon(cont).buffer(0)
    #     exterior_coords = list(poly1.exterior.coords)
    #     # 绘制多边形
    #     draw.polygon(exterior_coords, outline=(255, 0, 0), fill=(200, 200, 0))

    #     # 将多边形的坐标提取出来
    #     poly1 = Polygon(cont1).buffer(0)
    #     exterior_coords = list(poly1.exterior.coords)
    #     # 绘制多边形
    #     draw.polygon(exterior_coords, outline=(0, 255, 0), fill=(0, 200, 200))
        
    #     img.save('test.jpg')
    #     iou = polygon_iou(cont, cont1)
    #     iou1 = box_iou_ft(torch.from_numpy(ft).view(1, -1), torch.from_numpy(ft1).view(1, -1))
    #     print("IoU:", iou)
    #     print("IoU1:", iou1)