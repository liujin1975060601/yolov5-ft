# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
Image augmentation functions
"""

import logging
import math
import random

import cv2
import numpy as np

from utils.general import colorstr, segment2box, resample_segments, check_version,xywhr2xyxyxyxy
from utils.metrics import bbox_ioa, bbox_ioas
from DOTA_devkit.polyiou_cpu import poly_iou_cpu64
from utils.ft_utils import ffts_1,ffts_1_slow
import torch

def augment_ft(ft_labels,A23): #ft_labels[n,2+4coef]->ft_coef[n,2+4coef]
    is_numpy = isinstance(ft_labels, (np.ndarray,))
    if is_numpy:
        n = ft_labels.shape[0]
        ft_xy = np.split(ft_labels[:, :2], 2, axis=-1) #ft_xy[[n,1],[n,1]]
        # mask = np.all(ft_labels[:, :2] == 0, axis=-1) #mask[n]
        ft_coef = np.split(ft_labels[:, 2:].reshape(ft_labels.shape[0], -1, 4), 4, axis=-1)  # n, coef*4 -> ft_coef[a[n,coef,1],b[n,coef,1],c[n,coef,1],d[n,coef,1]]
        x_coef = np.concatenate([ft_xy[0], ft_coef[0].squeeze(-1), ft_coef[1].squeeze(-1)], dtype=np.float32, axis=-1) #x_coef[n,1+2coef]
        y_coef = np.concatenate([ft_xy[1], ft_coef[2].squeeze(-1), ft_coef[3].squeeze(-1)], dtype=np.float32, axis=-1) #y_coef[n,1+2coef]
        ft = np.zeros((n, x_coef.shape[-1], 3)) #ft[n,1+2coef,3(xy1)]
        ft[:, :, 0] = x_coef
        ft[:, :, 1] = y_coef
        ft[:, 0, 2] = 1
        ft = ft.reshape([-1, 3]) #ft[n,1+2coef,3(xy1)]-->ft[n*(1+2coef),3(xy1)]
        ft = (ft @ A23.T).reshape(n, x_coef.shape[-1], 2) # n*(1+2*coef), 2 -> [n, 1+2*coef, 2]
        ft_xy = ft[:, 0] #ft_xy[n,2]
        ft_coef = [ft_t.squeeze(-1) for ft_t in np.split(ft[:, 1:], 2, axis=-1)] #ft_coef[ab[n,2coef],cd[n,2coef]]
        ft_ab, ft_cd = [[ft_t[..., None] for ft_t in np.split(ft_c, 2, axis=-1)] for ft_c in ft_coef]  #ft_ab[n,coef,1], ft_cd[n,coef,1]
        ft_coef = np.concatenate([ft_ab[0], ft_ab[1], ft_cd[0], ft_cd[1]], axis=-1).reshape(n, -1)  # n, 4*coef
        ft_coef = np.concatenate([ft_xy, ft_coef], axis=-1) # ft_coef[n, 2 + 4*coef]
        assert ft_coef.shape==ft_labels.shape
        return ft_coef #ft_coef[n,2+4coef]
    else:
        n = ft_labels.shape[0]
        device, dtype = ft_labels.device, ft_labels.dtype

        # 保证 A23 与 ft_labels 同 device/dtype
        A23 = A23.to(device=device, dtype=dtype)

        # 等价 np.split(ft_labels[:, :2], 2, axis=-1)
        ft_xy_x, ft_xy_y = torch.split(ft_labels[:, :2], 1, dim=-1)  # [n,1], [n,1]

        # 等价 reshape(n, -1, 4) 再按 axis=-1 分成 4 份
        coef_blocks = ft_labels[:, 2:].reshape(n, -1, 4)            # [n, coef, 4]
        a, b, c, d = [t.squeeze(-1) for t in torch.split(coef_blocks, 1, dim=-1)]  # 四个 [n, coef]

        # 组装 x/y 系数：各为 [n, 1 + 2*coef]
        x_coef = torch.cat([ft_xy_x, a, b], dim=-1)
        y_coef = torch.cat([ft_xy_y, c, d], dim=-1)

        # 构造齐次坐标 [x, y, 1]，仅第 0 行的齐次项置 1
        ft = torch.zeros((n, x_coef.shape[-1], 3), dtype=dtype, device=device)  # [n, 1+2*coef, 3]
        ft[:, :, 0] = x_coef
        ft[:, :, 1] = y_coef
        ft[:, 0, 2] = 1

        # 仿射变换，期望输出最后维度为 2
        ft = (ft.reshape(-1, 3) @ A23.t()).reshape(n, x_coef.shape[-1], -1)     # [n, 1+2*coef, ?]
        if ft.shape[-1] != 2:
            ft = ft[..., :2]  # 若多于 2 维，截到前两维 (xy)

        # 取变换后的起点与系数
        ft_xy = ft[:, 0, :]                              # [n, 2]
        abcd_split = torch.split(ft[:, 1:, :], 1, dim=-1)  # 两个 [n, 2*coef, 1]，分别对应 x/y 的系数
        ab = torch.chunk(abcd_split[0].squeeze(-1), 2, dim=-1)  # 两块 [n, coef]
        cd = torch.chunk(abcd_split[1].squeeze(-1), 2, dim=-1)  # 两块 [n, coef]

        # 还原为 [n, coef, 4] 再展平到 [n, 4*coef]
        coef_restored = torch.cat(
            [ab[0].unsqueeze(-1), ab[1].unsqueeze(-1), cd[0].unsqueeze(-1), cd[1].unsqueeze(-1)],
            dim=-1
        ).reshape(n, -1)  # [n, 4*coef]

        # 拼接得到最终输出
        ft_coef = torch.cat([ft_xy, coef_restored], dim=-1)  # [n, 2 + 4*coef]

        assert ft_coef.shape==ft_labels.shape
        return ft_coef #ft_coef[n,2+4coef]

def augment_hsv(im, hgain=0.5, sgain=0.5, vgain=0.5):
    # HSV color-space augmentation
    if hgain or sgain or vgain:
        r = np.random.uniform(-1, 1, 3) * [hgain, sgain, vgain] + 1  # random gains
        hue, sat, val = cv2.split(cv2.cvtColor(im, cv2.COLOR_BGR2HSV))
        dtype = im.dtype  # uint8

        x = np.arange(0, 256, dtype=r.dtype)
        lut_hue = ((x * r[0]) % 180).astype(dtype)
        lut_sat = np.clip(x * r[1], 0, 255).astype(dtype)
        lut_val = np.clip(x * r[2], 0, 255).astype(dtype)

        im_hsv = cv2.merge((cv2.LUT(hue, lut_hue), cv2.LUT(sat, lut_sat), cv2.LUT(val, lut_val)))
        cv2.cvtColor(im_hsv, cv2.COLOR_HSV2BGR, dst=im)  # no return needed


def hist_equalize(im, clahe=True, bgr=False):
    # Equalize histogram on BGR image 'im' with im.shape(n,m,3) and range 0-255
    yuv = cv2.cvtColor(im, cv2.COLOR_BGR2YUV if bgr else cv2.COLOR_RGB2YUV)
    if clahe:
        c = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        yuv[:, :, 0] = c.apply(yuv[:, :, 0])
    else:
        yuv[:, :, 0] = cv2.equalizeHist(yuv[:, :, 0])  # equalize Y channel histogram
    return cv2.cvtColor(yuv, cv2.COLOR_YUV2BGR if bgr else cv2.COLOR_YUV2RGB)  # convert YUV image to RGB


def replicate(im, labels):
    # Replicate labels
    h, w = im.shape[:2]
    boxes = labels[:, 1:].astype(int)
    x1, y1, x2, y2 = boxes.T
    s = ((x2 - x1) + (y2 - y1)) / 2  # side length (pixels)
    for i in s.argsort()[:round(s.size * 0.5)]:  # smallest indices
        x1b, y1b, x2b, y2b = boxes[i]
        bh, bw = y2b - y1b, x2b - x1b
        yc, xc = int(random.uniform(0, h - bh)), int(random.uniform(0, w - bw))  # offset x, y
        x1a, y1a, x2a, y2a = [xc, yc, xc + bw, yc + bh]
        im[y1a:y2a, x1a:x2a] = im[y1b:y2b, x1b:x2b]  # im4[ymin:ymax, xmin:xmax]
        labels = np.append(labels, [[labels[i, 0], x1a, y1a, x2a, y2a]], axis=0)

    return im, labels


def letterbox(im, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleFill=False, scaleup=True, stride=32):
    # Resize and pad image while meeting stride-multiple constraints
    shape = im.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better val mAP)
        r = min(r, 1.0)

    # Compute padding
    ratio = r, r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding
    elif scaleFill:  # stretch
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
    return im, ratio, (dw, dh)


def random_perspective(im, targets=(), segments=(), degrees=10, translate=.1, scale=.1, shear=10, perspective=0.0, flip = [0.5,0.5],
                       border=(0, 0), iou_thr = 0.3, auto_aug_pts=1, clip_rate=0.2, clip_robx=False):
    mosaic_mode = border[0]<0 and border[1]<0
    nf = (targets.shape[-1] - 5 - 2) // 4
    # torchvision.transforms.RandomAffine(degrees=(-10, 10), translate=(0.1, 0.1), scale=(0.9, 1.1), shear=(-10, 10))
    # targets = [cls, xyxy]
    height = im.shape[0] + border[0] * 2  # shape(h,w,c)
    width = im.shape[1] + border[1] * 2

    # Center
    C = np.eye(3)
    C[0, 2] = -im.shape[1] / 2  # x translation (pixels)
    C[1, 2] = -im.shape[0] / 2  # y translation (pixels)

    # Perspective
    P = np.eye(3)
    P[2, 0] = random.uniform(-perspective, perspective)  # x perspective (about y)
    P[2, 1] = random.uniform(-perspective, perspective)  # y perspective (about x)

    # Rotation and Scale
    R = np.eye(3)
    a = random.uniform(-degrees, degrees)
    # a += random.choice([-180, -90, 0, 90])  # add 90deg rotations to small rotations
    s = random.uniform(1 - scale, 1 + scale)
    # s = 2 ** random.uniform(-scale, scale)
    R[:2] = cv2.getRotationMatrix2D(angle=a, center=(0, 0), scale=s)

    # Shear
    S = np.eye(3)
    S[0, 1] = math.tan(random.uniform(-shear, shear) * math.pi / 180)  # x shear (deg)
    S[1, 0] = math.tan(random.uniform(-shear, shear) * math.pi / 180)  # y shear (deg)

    # Translation
    T = np.eye(3)
    T[0, 2] = random.uniform(0.5 - translate, 0.5 + translate) * width  # x translation (pixels)
    T[1, 2] = random.uniform(0.5 - translate, 0.5 + translate) * height  # y translation (pixels)

    # Flip (mirror) transformation
    Fud = np.eye(3)
    Fud_flag = random.uniform(0,1) < flip[1]
    Flr_flag = random.uniform(0,1) < flip[0]
    if Fud_flag:#flipud
        Fud[1, 1] = -1  # flip horizontally
        Fud[1, 2] = height  # adjust translation to keep image within bounds
    Flr = np.eye(3)
    if Flr_flag:#fliplr
        Flr[0, 0] = -1  # flip horizontally
        Flr[0, 2] = width  # adjust translation to keep image within bounds

    # Combined rotation matrix
    M_9D = T @ S @ R @ P @ C
    M =  M_9D # order of operations (right to left) is IMPORTANT
    if (border[0] != 0) or (border[1] != 0) or (M != np.eye(3)).any():  # image changed
        if perspective:
            im = cv2.warpPerspective(im, M, dsize=(width, height), borderValue=(114, 114, 114))
        else:  # affine
            im = cv2.warpAffine(im, M[:2], dsize=(width, height), borderValue=(114, 114, 114))
    # Visualize
    # import matplotlib.pyplot as plt
    # ax = plt.subplots(1, 2, figsize=(12, 6))[1].ravel()
    # ax[0].imshow(im[:, :, ::-1])  # base
    # ax[1].imshow(im2[:, :, ::-1])  # warped

    # Transform label coordinates
    n = len(targets)
    if n:
        ft_labels = targets[:,5:]    # a0, c0, abcd..n -> a0, c0 | an, bn | cn, dn
        ft_coef = augment_ft(ft_labels,M[:2]) #ft_labels[n,2+4coef]->ft_coef[n,2+4coef]

        if auto_aug_pts==0:
            npts = 4
            xy = np.ones((n * npts, 3))
            #
            xyf = targets[:, [1, 2, 1, 4, 3, 4, 3, 2]].reshape(n * npts, 2) #xyf[n*npts, 2]
            #
            xy[:, :2] = xyf  #xyf[n*npts, 2]->xy[n*npts, 3]
            xy = xy @ M.T  # transform
            xy = (xy[:, :2] / xy[:, 2:3] if perspective else xy[:, :2]).reshape(n, npts*2) #[n*npts, 3]-->[n*npts, 2]-->xy[n, npts*2]

            # create new boxes
            i,ioa = out_range_filt_new(xy, (im.shape[1], im.shape[0]), iou_thr)
        else:
            npts = 64
            xy = np.ones((n * npts, 3)) #xy[n * npts, 3]
            #
            xf,yf = ffts_1(ft_coef,npts) #ft_coef[n,2+4coef]->xf[n,npts],yf[n,npts]
            xy = np.stack([xf, yf], axis=-1).reshape(-1, 2*npts)  #(xf[n,npts],yf[n,npts]) -> [n, npts, 2]->xy[n, npts*2]
            
            # create new boxes
            from .polygon import out_range_filt_poly_batch
            i,ioa = out_range_filt_poly_batch(xy, (im.shape[1], im.shape[0]), iou_thr) #xy[nt, npts*2]->i[nt2]
            
        if i.shape[0] > 0:
            xy,ioa = xy[i],ioa[i]
            if clip_robx:
                xy = clip_xywhr_rboxes(xy, 0, 0, width, height, clip_rate) #xy[nt,8(xyxyxyxy)]

            # create new boxes
            xy = xy.reshape(i.shape[0],npts,2)
            x = xy[:, :, 0] #x[n,npts]
            y = xy[:, :, 1] #y[n,npts]

            hbox = np.concatenate((x.min(1), y.min(1), x.max(1), y.max(1))).reshape(4, -1).T #hbox[nt,4]
            # clip
            # hbox[:, [0, 2]] = hbox[:, [0, 2]].clip(0, width)
            # hbox[:, [1, 3]] = hbox[:, [1, 3]].clip(0, height)
            targets = targets[i]
            ft_coef = ft_coef[i]
            n = targets.shape[0]
        else:
            targets = np.zeros((0, 5 + 2 + 4*nf),dtype=np.float32) #targets[0, 5 + 2+4coef]
            ft_coef = np.zeros((0, 2 + 4*nf),dtype=np.float32) #ft_coef[0, 2+4coef]
            hbox = np.zeros((0,4),dtype=np.float32)
            n = 0

        if n>0:
            # ft_coef[mask, :] = 0.
            # filter candidates
            if mosaic_mode==0:
                i = box_candidates_old(boxes=targets[:, 1:5] * s, boxes_aug=hbox, area_thr=0.10, width=width, height=height)
                #i = box_candidates(boxes=hbox, width=width, height=height)
                #i = box_candidates_ioa(boxes=hbox, width=width, height=height, iou_thr=0.1)
                targets = targets[i]
                targets[:, 1:5] = hbox[i]
                targets[:, 5:] = ft_coef[i]
            else:
                targets[:, 1:5] = hbox
                targets[:, 5:] = ft_coef
    return im, targets


def copy_paste(im, labels, segments, p=0.5):
    # Implement Copy-Paste augmentation https://arxiv.org/abs/2012.07177, labels as nx5 np.array(cls, xyxy)
    n = len(segments)
    if p and n:
        raise RuntimeError("未适配")
        h, w, c = im.shape  # height, width, channels
        im_new = np.zeros(im.shape, np.uint8)
        for j in random.sample(range(n), k=round(p * n)):
            l, s = labels[j], segments[j]
            box = w - l[3], l[2], w - l[1], l[4]
            ioa = bbox_ioa(box, labels[:, 1:5])  # intersection over area
            if (ioa < 0.30).all():  # allow 30% obscuration of existing labels
                labels = np.concatenate((labels, [[l[0], *box]]), 0)
                segments.append(np.concatenate((w - s[:, 0:1], s[:, 1:2]), 1))
                cv2.drawContours(im_new, [segments[j].astype(np.int64)], -1, (255, 255, 255), cv2.FILLED)

        result = cv2.bitwise_and(src1=im, src2=im_new)
        result = cv2.flip(result, 1)  # augment segments (flip left-right)
        i = result > 0  # pixels to replace
        # i[:, :] = result.max(2).reshape(h, w, 1)  # act over ch
        im[i] = result[i]  # cv2.imwrite('debug.jpg', im)  # debug

    return im, labels, segments


def cutout(im, labels, p=0.5):
    # Applies image cutout augmentation https://arxiv.org/abs/1708.04552
    if random.random() < p:
        h, w = im.shape[:2]
        scales = [0.5] * 1 + [0.25] * 2 + [0.125] * 4 + [0.0625] * 8 + [0.03125] * 16  # image size fraction
        for s in scales:
            mask_h = random.randint(1, int(h * s))  # create random masks
            mask_w = random.randint(1, int(w * s))

            # box
            xmin = max(0, random.randint(0, w) - mask_w // 2)
            ymin = max(0, random.randint(0, h) - mask_h // 2)
            xmax = min(w, xmin + mask_w)
            ymax = min(h, ymin + mask_h)

            # apply random color mask
            im[ymin:ymax, xmin:xmax] = [random.randint(64, 191) for _ in range(3)]

            # return unobscured labels
            if len(labels) and s > 0.03:
                box = np.array([xmin, ymin, xmax, ymax], dtype=np.float32)
                ioa = bbox_ioa(box, labels[:, 1:5])  # intersection over area
                labels = labels[ioa < 0.60]  # remove >60% obscured labels

    return labels


def mixup(im, labels, im2, labels2):
    # Applies MixUp augmentation https://arxiv.org/pdf/1710.09412.pdf
    r = np.random.beta(32.0, 32.0)  # mixup ratio, alpha=beta=32.0
    im = (im * r + im2 * (1 - r)).astype(np.uint8)
    labels = np.concatenate((labels, labels2), 0)
    return im, labels


def box_candidates_old(boxes, boxes_aug, width, height, wh_thr=2, ar_thr=20, area_thr=0.1, eps=1e-16):  # boxes(4,n), boxes_aug(4,n)
    boxes = np.copy(boxes).T #boxes(n,4)->boxes(4,n)
    # clip
    boxes_aug = np.copy(boxes_aug)
    boxes_aug[:, [0, 2]] = boxes_aug[:, [0, 2]].clip(0, width)
    boxes_aug[:, [1, 3]] = boxes_aug[:, [1, 3]].clip(0, height)
    boxes_aug=boxes_aug.T#boxes_aug(n,4)->boxes_aug(4,n)
    #
    cx,cy = (boxes[2] + boxes[0])/2, (boxes[3] + boxes[1])/2
    # Compute candidate boxes: boxes before augment, boxes_aug after augment, wh_thr (pixels), aspect_ratio_thr, area_ratio
    w1, h1 = boxes[2] - boxes[0], boxes[3] - boxes[1]
    w2, h2 = boxes_aug[2] - boxes_aug[0], boxes_aug[3] - boxes_aug[1]
    ar = np.maximum(w2 / (h2 + eps), h2 / (w2 + eps))  # aspect ratio
    return (cx>=0) & (cx<=width) & (cy>=0) & (cy<=height) & (w2 > wh_thr) & (h2 > wh_thr) & (w2 * h2 / (w1 * h1 + eps) > area_thr) & (ar < ar_thr)  # candidates


def box_candidates(boxes, width, height):  # box1(n,4), box2(n,4)
    cx,cy = (boxes[:,2] + boxes[:,0])/2, (boxes[:,3] + boxes[:,1])/2 #cx[n],cy[n]
    return (cx>=0) & (cx<=width) & (cy>=0) & (cy<=height)# candidates

#bbox_ioas
def box_candidates_ioa(boxes, width, height, iou_thr=0.2, w_min=0, h_min=0):  # boxes(n,4)
    image_box = np.array([w_min,h_min, width,height], dtype=np.float64)#image_poly[8]
    iou = bbox_ioas(image_box,boxes) #boxes[nt,4] -> iou[nt]
    assert np.all((iou >= 0) & (iou <= 1.0001)), "iou 中存在不在 [0, 1] 范围内的值"
    return iou>iou_thr #(cx>=0) & (cx<=width) & (cy>=0) & (cy<=height)# candidates

def out_range_filt_new(poly_ptses, shape, iou_thresh=0.2,ioa4=None): #poly_ptses[nt,8=4*2(xyxyxyxy)]
    assert ioa4 is None or ioa4.shape[0]==poly_ptses.shape[0]
    if len(shape) == 2:
        shape = [0, 0, shape[0], shape[1]]  # x1y1x2y2
    image_poly = np.array([shape[0], shape[1], shape[2], shape[1], shape[2],shape[3], shape[0],shape[3]], dtype=np.float32).reshape(1, -1)#image_poly[8]
    image_area = (shape[2] - shape[0]) * (shape[3] - shape[1])
    # v11
    # image_poly = xyxyxyxy2xywhr(image_poly.astype(np.float32))
    # poly_ptses = xyxyxyxy2xywhr(poly_ptses.astype(np.float32))
    # iou = batch_probiou(poly_ptses, image_poly).cpu().numpy().reshape(-1)
    # obj_area = poly_ptses[:, 2] * poly_ptses[:, 3]
    # v5
    iou = poly_iou_cpu64(poly_ptses.astype(np.float64), image_poly.astype(np.float64)).reshape(-1) #iou[nt] for image shape
    obj_area = cal_poly_area_array(poly_ptses) # obj_area[nt] 要排好顺序才行

    sec_area = iou * (image_area + obj_area) / (1 + iou) #sec_area[nt] for image shape
    tmp = obj_area <= 0
    sec_area[tmp] = 0
    obj_area[tmp] = 1
    ioa = sec_area / obj_area #ioa[nt]
    if ioa4 is not None:
        assert ioa4.shape[0]==ioa.shape[0]
        ioa = np.minimum(ioa,ioa4)
    polys_out_ids = np.where(ioa > iou_thresh)[0] #polys_out_ids[nt]
    return polys_out_ids,ioa #polys_out_ids[nt] ioa[nt]

def cal_poly_area_array(ptses):
    points = ptses.reshape(-1,4,2)
    # 在数组末尾添加第一个点
    points = np.concatenate([points, points[:, 0:1, :]], axis=-2)
    # 计算顺时针和逆时针相邻点乘积之和
    clockwise_sum = np.sum(points[:, :-1, 0] * points[:, 1:, 1], axis=-1)
    counterclockwise_sum = np.sum(points[:, :-1, 1] * points[:, 1:, 0], axis=-1)
    # 计算围成的面积
    area = abs(clockwise_sum - counterclockwise_sum) / 2
    return area

def resample_segments_v11(segments, n=100):
    """
    Inputs a list of segments (n,2) and returns a list of segments (n,2) up-sampled to n points each.

    Args:
        segments (list): a list of (n,2) arrays, where n is the number of points in the segment.
        n (int): number of points to resample the segment to. Defaults to 1000

    Returns:
        segments (list): the resampled segments.
    """
    for i, s in enumerate(segments):
        s = np.concatenate((s, s[0:1, :]), axis=0)
        x = np.linspace(0, len(s) - 1, n)
        xp = np.arange(len(s))
        segments[i] = (
            np.concatenate([np.interp(x, xp, s[:, i]) for i in range(2)], dtype=np.float32).reshape(2, -1).T
        )  # segment xy
    return segments

def clip_xywhr_rboxes(xy, x1, y1, x2, y2, clip_rate=0.0):
    margin = int(clip_rate * min(x2-x1,y2-y1))
    assert margin>=0
    assert x1<x2 and y1<y2
    segments = [x for x in xy.copy().reshape(-1, 4, 2)]
    segments = resample_segments_v11(segments)
    bboxes = []
    for segment in segments:
        # NOTE: Use cv2.minAreaRect to get accurate xywhr,
        # especially some objects are cut off by augmentations in dataloader.
        segment = segment.reshape(-1, 2)
        # if np.array([x.min() < 0, y.min() < 0, x.max() > x2, y.max() > y2]).sum() >= 3:
        x, y = segment.T  # segment xy
        inside = (x >= x1-margin) & (y >= y1-margin) & (x <= x2+margin) & (y <= y2+margin)
        if inside.sum() > 0:
            points_inside = segment[inside]
            x1a, x2a, y1a, y2a = points_inside[:, 0].min(), points_inside[:, 0].max(), points_inside[:, 1].min(), points_inside[:, 1].max()
            
            segment[:, 0] = segment[:, 0].clip(x1a, x2a)
            segment[:, 1] = segment[:, 1].clip(y1a, y2a)

            (cx, cy), (w, h), angle = cv2.minAreaRect(segment)
            bboxes.append([cx, cy, w, h, angle / 180 * np.pi] if (w * h) > 0 else [0, 0, 0, 0, 0])
        else:
            bboxes.append([0, 0, 0, 0, 0])
    xy = xywhr2xyxyxyxy(np.array(bboxes, dtype=np.float32)).reshape(-1, 8)
    return xy