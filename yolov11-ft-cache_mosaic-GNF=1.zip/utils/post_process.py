
import os
import time
from subprocess import check_output

import numpy as np
import torch
import torchvision

from utils.metrics import box_iou

from utils.general import xywh2xyxy
from utils.ft_utils import ft2pts
from DOTA_devkit.polyiou_cpu import poly_nms_cpu64
from utils.ft_iou import polygon_iou_ft, polygon_nms_ft

def check_descending(x, col_idx=4, strict=False):
    # 检查张量 x 的第 col_idx 列是否按从大到小排序
    # 参数：
    #     x : torch.Tensor
    #         形状为 (N, M) 的二维张量
    #     col_idx : int
    #         要检查的列索引（默认第4列）
    #     strict : bool
    #         是否要求严格递减（True 表示必须严格 >）
    # 返回：
    #     bool : 如果满足从大到小排序，返回 True，否则 False
    col = x[:, col_idx]
    if strict:
        result = torch.all(col[:-1] > col[1:])
    else:
        result = torch.all(col[:-1] >= col[1:])
    return result.item()

def non_max_suppression_dfl(prediction, conf_thres=0.25, iou_thres=0.45, classes=None, agnostic=False, multi_label=False,
                        labels=(), max_det=300, return_indices=False):
    # Runs Non-Maximum Suppression (NMS) on inference results
    # prediction[batch, ntotal, 4+nc]
    # Returns:
    #      list of detections, on (n,6) tensor per image [xyxy, conf, cls]
    # output indices  
    indices_grid = torch.arange(0,prediction.shape[1], device=prediction.device).long()

    nc = prediction.shape[2] - 4  # number of classes
    if isinstance(conf_thres, float):
        conf_thres = torch.ones(nc, device=prediction.device) * conf_thres
    else:
        conf_thres = conf_thres.to(prediction.device) #conf_thres[nc]
    xc = prediction[..., 4:].max(-1)[0] > conf_thres.min() #xc[batch, ntotal]  candidates

    # Checks
    assert ((0 <= conf_thres) & (conf_thres <= 1)).all(), f'Invalid Confidence threshold [{conf_thres.min()}, {conf_thres.max()}], valid values are between 0.0 and 1.0'
    assert 0 <= iou_thres <= 1, f'Invalid IoU {iou_thres}, valid values are between 0.0 and 1.0'

    # Settings
    min_wh, max_wh = 2, 7680  # (pixels) minimum and maximum box width and height
    max_nms = 30000  # maximum number of boxes into torchvision.ops.nms()
    time_limit = 10.0  # seconds to quit after
    redundant = True  # require redundant detections
    multi_label &= nc > 1  # multiple labels per box (adds 0.5ms/img)
    merge = False  # use merge-NMS

    t = time.time()
    output = [torch.zeros((0, 6), device=prediction.device)] * prediction.shape[0]
    output_indices = [torch.zeros((0), device=prediction.device, dtype=torch.long)] * prediction.shape[0]
    for xi, x in enumerate(prediction): # image index, x[ntotal, 4+nc]   prediction[batch, ntotal, 4+nc]
        # xc[xi][ntotal]
        # x[((x[..., 2:4] < min_wh) | (x[..., 2:4] > max_wh)).any(1), 4] = 0  # width-height
        # assert xc[xi].shape[0] == x.shape[0]
        # assert xc[xi].shape[0] == indices_grid.shape[0]
        x = x[xc[xi]] #x[nt, 4+nc]
        grid = indices_grid[xc[xi]]

        # Cat apriori labels if autolabelling
        if labels and len(labels[xi]):
            l = labels[xi]
            v = torch.zeros((len(l), nc + 5), device=x.device)
            v[:, :4] = l[:, 1:5]  # box
            v[range(len(l)), l[:, 0].long() + 4] = 1.0  # cls
            x = torch.cat((x, v), 0)

        # If none remain process next image
        if not x.shape[0]:
            continue

        # Compute conf
        # x[:, 5:] *= x[:, 4:5]  # conf = obj_conf * cls_conf
        # x[nobj,4(xywh)+1(obj)+cls]

        # Box (center x, center y, width, height) to (x1, y1, x2, y2)
        box = xywh2xyxy(x[:, :4]) #box[nt,4]
        # x[:,:4(xywh)] -> box[nobj,4(xyxy)]

        # Detections matrix nx6 (xyxy, conf, cls)
        if multi_label: #x[:, 4:]->x[nt, nc]
            i, j = (x[:, 4:] > conf_thres[None]).nonzero(as_tuple=False).T #i[nobj]目标行号, j[nobj]类列号
            x = torch.cat((box[i], x[i, j + 4, None], j[:, None].float()), 1) #[nonj,4(box)] [nobj,1(conf)] [nobj,1(cls)]->[nobj,4(box)+1(conf)+1(cls)]
            grid = grid[i]
        else: # x[nt, 4+nc]   best class only
            conf, j = x[:, 4:].max(1, keepdim=True) #conf[nt,1] j[nt,1(cls)]
            filter_conf = (conf > conf_thres[j]).view(-1) #filter_conf[nt2]
            x = torch.cat((box[filter_conf], conf[filter_conf], j[filter_conf].float()), 1) #[nt2,4(box)] [nt2,1(conf)] [nt2,1(cls)]->[nt2,6=4(box)+1(conf)+1(cls)]
            # assert filter_conf.shape[0] == x.shape[0]
            # assert filter_conf.shape[0] == grid.shape[0]
            # x = x[filter_conf] # [nobj,6=4(box)+1(conf)+1(cls)]->x[nt2, 6=4(box)+1(conf)+1(cls)]]
            grid = grid[filter_conf] #grid[nt2]

        # Filter by class
        if classes is not None:
            grid = grid[(x[:, 5:6] == torch.tensor(classes, device=x.device)).any(1)]
            x = x[(x[:, 5:6] == torch.tensor(classes, device=x.device)).any(1)]

        # Apply finite constraint
        # if not torch.isfinite(x).all():
        #     x = x[torch.isfinite(x).all(1)]

        # Check shape
        n = x.shape[0]  # number of boxes
        if not n:  # no boxes
            continue
        elif n > max_nms:  # excess boxes
            grid = grid[x[:, 4].argsort(descending=True)[:max_nms]]  # sort by confidence
            x = x[x[:, 4].argsort(descending=True)[:max_nms]]  # sort by confidence

        # Batched NMS
        c = x[:, 5:6] * (0 if agnostic else max_wh)  # classes
        boxes, scores = x[:, :4] + c, x[:, 4]  # boxes (offset by class), scores
        i = torchvision.ops.nms(boxes, scores, iou_thres)  # NMS
        # i = i[scores[i].argsort(descending=True)]
        # ✅ val 按置信度从大到小排序 # x[n,6=4(xywh)+1(conf)+1(cls)]
        # x[:,4] #conf
        assert check_descending(x[i],4)

        if i.shape[0] > max_det:  # limit detections
            i = i[:max_det]      
        # assert i.max() < boxes.shape[0]
        if merge and (1 < n < 3E3):  # Merge NMS (boxes merged using weighted mean)
            # update boxes as boxes(i,4) = weights(i,n) * boxes(n,4)
            iou = box_iou(boxes[i], boxes) > iou_thres  # iou matrix
            weights = iou * scores[None]  # box weights [i, n] [1, n]
            x[i, :4] = torch.mm(weights, x[:, :4]).float() / weights.sum(1, keepdim=True)  # merged boxes
            if redundant:
                i = i[iou.sum(1) > 1]  # require redundancy
        output_indices[xi] = grid[i].long()
        output[xi] = x[i]
        # if (time.time() - t) > time_limit:
        #     print(f'WARNING: NMS time limit {time_limit}s exceeded')
        #     break  # time limit exceeded
    return (output, output_indices) if return_indices else output

def non_max_suppression_ft(prediction, prediction_ft, conf_thres=0.25, iou_thres=0.45, classes=None, agnostic=False, multi_label=False,
                        labels=(), max_det=300, return_indices=False, polygon=True, mask_line=None):
    """Runs Non-Maximum Suppression (NMS) on inference results
    prediction: [batch, all_grid, 5+nc]ft
    Returns:
         list of detections, on (n,6) tensor per image [xyxy, conf, cls]
    """      
    # output indices  
    indices_grid = torch.arange(0,prediction.shape[1], device=prediction.device).long() #indices_grid[nt0]


    nc = prediction.shape[2] - 4  # number of classes
    if isinstance(conf_thres, float):
        conf_thres = torch.ones(nc, device=prediction.device) * conf_thres
    else:
        conf_thres = conf_thres.to(prediction.device)
    xc = prediction[..., 4:].max(-1)[0] > conf_thres.min()  # candidates

    # Checks
    assert ((0 <= conf_thres) & (conf_thres <= 1)).all(), f'Invalid Confidence threshold [{conf_thres.min()}, {conf_thres.max()}], valid values are between 0.0 and 1.0'
    assert 0 <= iou_thres <= 1, f'Invalid IoU {iou_thres}, valid values are between 0.0 and 1.0'

    # Settings
    min_wh, max_wh = 2, 4096  # (pixels) minimum and maximum box width and height
    max_nms = 30000  # maximum number of boxes into torchvision.ops.nms()
    time_limit = 10.0  # seconds to quit after
    redundant = True  # require redundant detections
    multi_label &= nc > 1  # multiple labels per box (adds 0.5ms/img)
    merge = False  # use merge-NMS

    t = time.time()
    output = [torch.zeros((0, 6), device=prediction.device)] * prediction.shape[0]
    output_ft = [torch.zeros((0, prediction_ft.shape[-1]), device=prediction.device)] * prediction.shape[0]
    output_indices = [torch.zeros((0, 1), device=prediction.device)] * prediction.shape[0]
    #prediction[batch,nt,5+c]  prediction_ft[batch,nt,2+4*term]
    for xi, (x,x_ft) in enumerate(zip(prediction, prediction_ft)):  # image index, image inference
        #x[nt0,5+c]  x_ft[nt0,2+4*term]  (xc[xi])[nt0]
        # Apply constraints
        # x[((x[..., 2:4] < min_wh) | (x[..., 2:4] > max_wh)).any(1), 4] = 0  # width-height
        x = x[xc[xi]]# x[nt0,5+c]-->x[nt,5+c]
        x_ft = x_ft[xc[xi]]# x_ft[nt0,2+4*term]-->x_ft[nt,2+4*term]
        grid = indices_grid[xc[xi]] #indices_grid[nt]->grid[nt]

        # Cat apriori labels if autolabelling
        if labels and len(labels[xi]):
            l = labels[xi]
            v = torch.zeros((len(l), nc + 5), device=x.device)
            v[:, :4] = l[:, 1:5]  # box
            v[:, 4] = 1.0  # conf
            v[range(len(l)), l[:, 0].long() + 5] = 1.0  # cls
            x = torch.cat((x, v), 0)

        # If none remain process next image
        if x.shape[0] > 0:
            # Compute conf
            # x[:, 5:] *= x[:, 4:5]  # conf = obj_conf * cls_conf  x[nt,5+c]
            # x[nobj,4(xywh)+1(conf)+cls]

            # Box (center x, center y, width, height) to (x1, y1, x2, y2)
            box = xywh2xyxy(x[:, :4])
            # x[:, :4(xywh)] -> box[nobj,4(xyxy)]

            # Detections matrix nx6 (xyxy, conf, cls)
            if multi_label:
                i, j = (x[:, 4:] > conf_thres[None]).nonzero(as_tuple=False).T #i[nobj]目标行号, j[nobj]类列号
                #依据前面的x[i, j + 5, None]，x[i, 5 + j, None]表示乘到第j列的class可信度
                x = torch.cat((box[i], x[i, 4 + j, None], j[:, None].float()), 1)#x[nobj,4(xyxy)+1(conf)+cls]->x[nobj,6=4(xyxy)+1(conf)+1(cls)
                x_ft = x_ft[i]
                grid = grid[i]
            else:  # best class only
                # x[nobj,4(xywh)+1(conf)+1(cls)]
                conf, j = x[:, 4:].max(1, keepdim=True)#选择class输出最大的conf作为最终可信度，j作为识别类标签
                # x[:, 5:]shape = [nobj,cls]
                # conf[nobj,1]
                # j[nobj,1]
                obj_filt = (conf > conf_thres[j]).view(-1) #class的可信度再过滤一轮
                x = torch.cat((box, conf, j.float()), 1)[obj_filt]  #后面x[:, 5:6]表示类id
                #x[nobj_filt_cls,6==4(box)+1(conf)+1(j.float()==cls)]  在1号维度拼起来[box+conf+cls]，再经过cls的conf过滤
                x_ft = x_ft[obj_filt]#x_ft[nt,2+4*term]->x_ft[nobj_filt_cls,2+4*term]  x_ft use the same filter as x
                grid = grid[obj_filt]#grid[nt]->grid[nobj_filt_cls]

            # Filter by class
            if classes is not None:#classes非空的话，就只检测classes所包含的类
                clsid = x[:, 5:6]
                grid = grid[(clsid == torch.tensor(classes, device=x.device)).any(1)]
                x = x[(clsid == torch.tensor(classes, device=x.device)).any(1)]
                x_ft = x_ft[(clsid == torch.tensor(classes, device=x.device)).any(1)]
            # x[n,6=4(xywh)+1(conf)+1(cls)]
            # x_ft[n,2+4*term]

            # Apply finite constraint
            # if not torch.isfinite(x).all():
            #     x = x[torch.isfinite(x).all(1)]

            # Check shape
            n = x.shape[0]  # number of boxes
            if n > max_nms:  # delete small score boxes
                filter_ = x[:, 4].argsort(descending=True)[:max_nms]
                grid = grid[filter_]  # sort by confidence
                x_ft = x_ft[filter_]  # sort by confidence
                x = x[filter_]  # sort by confidence
            # x[n,6=4(xywh)+1(conf)+1(cls)]
            
            # Batched NMS
            c = x[:, 5] #c[n]  classes  c[nt] as class id

            # use ft_predict iou
            ft, scores = x_ft, x[:, 4]
            # ft[:, :2] = ft[:, :2] + c

            if x_ft.shape[0]>0:
                # mask_line 区分类别：True -> 使用水平框NMS；False -> 使用polygon NMS
                if mask_line is not None:
                    c_int = c.long()
                    mask_bool = mask_line[c_int]  # [n] -> bool
                    mask_rect = mask_bool.bool()        # True部分用水平框NMS
                    mask_poly = ~mask_bool.bool()       # False部分用polygon NMS
                else:
                    # 如果没有mask_line，则全部使用polygon路径
                    mask_poly = torch.ones_like(c, dtype=torch.bool)
                    mask_rect = torch.zeros_like(c, dtype=torch.bool)
                i_all = []

                # --- 1️⃣ polygon NMS部分（mask_poly == True） ---
                if mask_poly.any():
                    ft_poly = ft[mask_poly]
                    scores_poly = scores[mask_poly]
                    c_poly = c[mask_poly]

                    if polygon:
                        i_poly = polygon_nms_ft(ft_poly, scores_poly, c_poly.cpu().numpy(),
                                                iou_thres, cls_offset=0, dif_cls_iou_thresh=1.1)
                    else:
                        polys, scores_np = (ft2pts(ft_poly) + c_poly[:, None] * max_wh).cpu().numpy().astype(np.float64), scores_poly
                        polys2 = np.concatenate([polys, scores_np.cpu().numpy().astype(np.float64).reshape(-1, 1)], axis=-1)
                        i_poly = poly_nms_cpu64(polys2, iou_thres)

                    # 映射回原始索引
                    i_all.append(mask_poly.nonzero(as_tuple=False).view(-1)[torch.from_numpy(i_poly).to(c.device)])

                # --- 2️⃣ 水平框 NMS部分（mask_rect == True） ---
                if mask_rect.any():
                    x_rect = x[mask_rect]
                    c_rect = c[mask_rect]
                    # 普通水平框NMS（带类别偏移）
                    c_offset = c_rect * (0 if agnostic else max_wh)
                    boxes, scores_rect = x_rect[:, :4] + c_offset[:, None], x_rect[:, 4]
                    i_rect = torchvision.ops.nms(boxes, scores_rect, iou_thres)
                    # 映射回原始索引
                    i_all.append(mask_rect.nonzero(as_tuple=False).view(-1)[i_rect])

                # --- 合并NMS结果 ---
                assert len(i_all) > 0
                i = torch.cat(i_all)
                assert i.shape[0] <= x_ft.shape[0]
                if len(i_all)>=2:
                    i = i[scores[i].argsort(descending=True)]
                # ✅ val 按置信度从大到小排序 # x[n,6=4(xywh)+1(conf)+1(cls)]
                # x[:,4] #conf
                assert check_descending(x[i],4)
                # if polygon: #polygon_nms==2
                #     i = polygon_nms_ft(ft, scores, c.cpu().numpy(), iou_thres, cls_offset=0, dif_cls_iou_thresh=1.1)
                # else:
                #     polys, scores = (ft2pts(x_ft) + c[:, None] * max_wh).cpu().numpy().astype(np.float64), x[:, 4] #x_ft[n2,2+4*term]->polys[n2,8] x[n2,4]->scores[n2]
                #     polys2 = np.concatenate([polys, scores.cpu().numpy().astype(np.float64).reshape(-1, 1)], axis=-1)#polys2[n2,9=8(polys)+1(conf)]
                #     i = poly_nms_cpu64(polys2, iou_thres)
            else:
                i = np.array([], dtype=int)   # 返回空序列

            # polys, scores = (ft2pts(x_ft) + c).cpu().numpy().astype(np.float64), x[:, 4] #x_ft[n2,2+4*term]->polys[n2,8] x[n2,4]->scores[n2]

            # polys2 = np.concatenate([polys, scores.cpu().numpy().astype(np.float64).reshape(-1, 1)], axis=-1)#polys2[n2,9=8(polys)+1(conf)]
            # i = poly_nms_cpu64(polys2, iou_thres)

            if i.shape[0] > max_det:  # limit detections
                i = i[:max_det]
            output_indices[xi] = grid[i]
            output[xi] = x[i] #x[n,6]->x[i][n2,6]
            output_ft[xi] = x_ft[i] #x_ft[n,2+4*term]->x_ft[i][n2,2+4*term]
    if (time.time() - t) > time_limit:
        print(f'WARNING: NMS time limit {time_limit}s exceeded')
            # break  # time limit exceeded
    # return (output, output_ft, output_indices) if return_indices else (output, output_ft)
    return (output, output_ft, output_indices) if return_indices else (output, output_ft)



def non_max_suppression(prediction, conf_thres=0.25, iou_thres=0.45, classes=None, agnostic=False, multi_label=False,
                        labels=(), max_det=300, paths=None, imgsz=0):
    """Runs Non-Maximum Suppression (NMS) on inference results

    Returns:
         list of detections, on (n,6) tensor per image [xyxy, conf, cls]
    """

    assert paths==None or len(paths)==prediction.shape[0]

    # prediction[b,nt,4(xywh)+1(obj)+cls] so prediction.shape[2]==cls
    nc = prediction.shape[2] - 5  # number of classes

    if isinstance(conf_thres, float):
        conf_thres = torch.ones(nc, device=prediction.device) * conf_thres
    else:
        conf_thres = conf_thres.to(prediction.device)
    xc = prediction[..., 4] > conf_thres.min()  # candidates
    
    # xc[b,nt]
    # xc[b,nt]

    # Checks
    assert ((0 <= conf_thres) & (conf_thres <= 1)).all(), f'Invalid Confidence threshold [{conf_thres.min()}, {conf_thres.max()}], valid values are between 0.0 and 1.0'
    assert 0 <= iou_thres <= 1, f'Invalid IoU {iou_thres}, valid values are between 0.0 and 1.0'

    # Settings
    min_wh, max_wh = 2, 4096  # (pixels) minimum and maximum box width and height
    max_nms = 30000  # maximum number of boxes into torchvision.ops.nms()
    time_limit = 200.0  # seconds to quit after
    redundant = True  # require redundant detections
    multi_label &= nc > 1  # multiple labels per box (adds 0.5ms/img)
    merge = False  # use merge-NMS

    t = time.time()
    output = [torch.zeros((0, 6), device=prediction.device)] * prediction.shape[0]
    #box_array = []  # [n_imgs, n_boxes, xyxy=4 + obj_conf=1 + class=1 + mns_label=1]
    #for循环是对prediction[b,nt,4(xywh)+1(obj)+cls]0维度b进行循环
    for xi, x in enumerate(prediction):  # image index, image inference
        # xi=0,..,b-1  实际上这里推理b=1只有一次循环
        # x[nt,4(xywh)+1(obj)+cls] == prediction[xi=0,nt,4(xywh)+1(obj)+cls]
        # Apply constraints
        # x[((x[..., 2:4] < min_wh) | (x[..., 2:4] > max_wh)).any(1), 4] = 0  # width-height
        # xc[1,nt]  # xc[xi] is [nt]
        x = x[xc[xi]]  # confidence过滤
        # x[nobj,4(xywh)+1(obj)+cls]

        # Cat apriori labels if autolabelling
        if labels and len(labels[xi]):
            l = labels[xi]
            v = torch.zeros((len(l), nc + 5), device=x.device)
            v[:, :4] = l[:, 1:5]  # box
            v[:, 4] = 1.0  # conf
            v[range(len(l)), l[:, 0].long() + 5] = 1.0  # cls
            x = torch.cat((x, v), 0)

        # If none remain process next image
        if not x.shape[0]:#nobj
            continue

        # Compute conf
        x[:, 5:] *= x[:, 4:5]  # conf = obj_conf * cls_conf
        # x[nobj,4(xywh)+1(obj)+cls]

        # Box (center x, center y, width, height) to (x1, y1, x2, y2)
        box = xywh2xyxy(x[:, :4])
        # x[:, :4(xywh)] -> box[nobj,4(xyxy)]

        # Detections matrix nx6 (xyxy, conf, cls)
        if multi_label:#同一个框可能对应好多个类，只要conf超过conf_thres
            i, j = (x[:, 5:] > conf_thres[None]).nonzero(as_tuple=False).T #i[nobj]目标行号, j[nobj]类列号
            x = torch.cat((box[i], x[i, 5 + j, None], j[:, None].float()), 1) #x[nobj,4(xyxy)+1(obj)+cls]->x[nobj,4(xyxy)+1(conf)+1(cls)]
        else:  # best class only
            # x[nobj,4(xywh)+1(obj)+1(cls)]
            conf, j = x[:, 5:].max(1, keepdim=True) #选择class输出最大的conf作为最终可信度，j作为识别类标签
            # x[:, 5:]shape = [nobj,cls]
            # conf[nobj,1]
            # j[nobj,1]
            filter_conf = (conf > conf_thres[j]).view(-1)
            x = torch.cat((box, conf, j.float()), 1)[filter_conf]
            #x[nobj_filt_cls,6==4(box)+1(conf)+1(j.float()==cls)]  在1号维度拼起来[box+conf+cls]，再经过cls的conf过滤
        #x[nobj_filt_cls,6==4(box)+1(conf)+1(j.float()==cls)]

        # Filter by class
        if classes is not None:
            x = x[(x[:, 5:6] == torch.tensor(classes, device=x.device)).any(1)]

        # Apply finite constraint
        # if not torch.isfinite(x).all():
        #     x = x[torch.isfinite(x).all(1)]

        # Check shape
        n = x.shape[0]  # number of boxes
        if not n:  # no boxes
            continue
        elif n > max_nms: # 砍掉可信度较低的,超过max_nms部分的boxes
            x = x[x[:, 4].argsort(descending=True)[:max_nms]]  # sort by confidence
            #x[:, 4].argsort(descending=True)[:max_nms]返回一个按[4]排序从大到小排序的整数id list

        # x[nobj_filt_cls,6==4(xyxy)+1(conf)+1(j.float()==cls)]
        # 上面是过滤,下面才是真正的nms

        # Batched NMS
        #x[nobj,4(xyxy)+1(conf)+1(cls)]
        c = x[:, 5:6]  # classes
        #c[nobj,1]
        scores = x[:, 4] #scores
        #

        if paths==None:
            if 0:
                boxes = x[:, :4]# boxes (offset by class)
                i_list=[]
                for ic in range(nc):
                    jc = (c==ic)
                    indices = torch.where(jc)[0]
                    # boxes[nobj,4]  scores[nobj]
                    idc = torchvision.ops.nms(boxes[indices], scores[indices], iou_thres)  # NMS
                    # idc[nobj] filt id
                    if idc.shape[0] > max_det:  # limit detections
                        idc = idc[:max_det]
                    # x[nobj, 6 == 4(xyxy) + 1(conf) + 1(cls)]
                    i_list.append(indices[idc])
                i = torch.cat(i_list,dim=0)
            else:
                boxes = x[:, :4] + c * (0 if agnostic else max_wh)   # boxes (offset by class)
                # boxes[nobj,4]  scores[nobj]
                i = torchvision.ops.nms(boxes, scores, iou_thres)  # NMS
                # i[nobj] filt id
                if i.shape[0] > max_det:  # limit detections
                    i = i[:max_det]
                if merge and (1 < n < 3E3):  # Merge NMS (boxes merged using weighted mean)
                    # update boxes as boxes(i,4) = weights(i,n) * boxes(n,4)
                    iou = box_iou(boxes[i], boxes) > iou_thres  # iou matrix
                    weights = iou * scores[None]  # box weights
                    x[i, :4] = torch.mm(weights, x[:, :4]).float() / weights.sum(1, keepdim=True)  # merged boxes
                    if redundant:
                        i = i[iou.sum(1) > 1]  # require redundancy
            # x[nobj, 6 == 4(box) + 1(conf) + 1(cls)]
        else:
            boxes = x[:, :4]# boxes (offset by class)
            i_list=[]
            for ic in range(nc):
                jc = (c==ic)
                indices = torch.where(jc)[0]
                nt = indices.shape[0]
                if nt:
                    # boxes[nobj,4]  scores[nobj]
                    idc = torchvision.ops.nms(boxes[indices], scores[indices], iou_thres)  # NMS
                    # idc[nobj] filt id
                    if idc.shape[0] > max_det:  # limit detections
                        idc = idc[:max_det]
                    # x[nobj, 6 == 4(xyxy) + 1(conf) + 1(cls)]
                    idc0 = indices[idc]
                    i_list.append(idc0)
                    #
                    # 保存boxes训练数据
                    nms_labels = torch.zeros(nt).to(x.device)   # x.shape[0] = n_boxes
                    nms_labels[idc] = 1  #nms_labels[nb]
                    #nms_labels = torch.unsqueeze(nms_labels, axis=1).to(x.device)#nms_labels[nb]->#nms_labels[nb,1]
                    #nms_labels = torch.tensor(nms_labels)
                    cx = (x[indices, 0] + x[indices, 2])/ 2 / imgsz
                    cy = (x[indices, 1] + x[indices, 3])/ 2 / imgsz
                    w  = (x[indices, 2] - x[indices, 0])/imgsz
                    h  = (x[indices, 3] - x[indices, 1])/imgsz
                    img_boxes_data = torch.cat((cx[:,None],cy[:,None],w[:,None],h[:,None], scores[indices,None], nms_labels[:,None]), dim=1)
                    #box_array.append(img_boxes_data)
                    file_name = os.path.basename(paths[xi]).rsplit('.', 1)[0]
                    save_path = './save_boxes/'
                    if not os.path.exists(save_path):
                        os.mkdir(save_path)
                    save_full_name = save_path + file_name + f'_{ic}' + '.txt'
                    np.savetxt(f'{save_full_name}', img_boxes_data.to('cpu').numpy(), fmt="%.4f %.4f %.4f %.4f %.4f %.d")
            i = torch.cat(i_list,dim=0)

        output[xi] = x[i]
        if (time.time() - t) > time_limit:
            print(f'WARNING: NMS time limit {time_limit}s exceeded')
            break  # time limit exceeded

    return output