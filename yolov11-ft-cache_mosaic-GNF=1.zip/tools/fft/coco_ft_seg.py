# import json
import ujson as json
import copy
import cv2
from pathlib import Path
from tqdm import tqdm
import numpy as np
from multiprocessing import Pool
from itertools import repeat
import networkx as nx
from scipy.spatial import distance
import matplotlib.pyplot as plt

from fftcurve import compute_coefficients_interp

# hull[n, 2] 是点集，n 是点的数量，hull[:, 0] 是 x 坐标，hull[:, 1] 是 y 坐标
def polygon_area(hull): #hull[n,2]->area
    x = hull[:, 0]  # 获取所有的 x 坐标
    y = hull[:, 1]  # 获取所有的 y 坐标
    # 应用 Shoelace 公式计算面积
    area = 0.5 * np.abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))   
    return area#[n]
def fft_area_abcd(an,bn,cn,dn):
    an, bn, cn, dn = an.squeeze(), bn.squeeze(), cn.squeeze(), dn.squeeze()
    #Sum(k*(ak*dk-bk*ck))
    assert an.shape[0]==len(an)==bn.shape[0]==cn.shape[0]==dn.shape[0]
    return np.pi * ((an*dn-bn*cn)*np.arange(1,1+an.shape[0])).sum()
def fft_area(ft_label):
    an,bn,cn,dn = np.split(ft_label[2:].reshape(-1, 4), 4, axis=-1) #[4n]->[n,4]->an[n,1],bn[n,1],cn[n,1],dn[n,1]
    return fft_area_abcd(an,bn,cn,dn)

def gen_curve(points, terms): #points[n,2]
    # 输入points点集[n, 2], 返回傅里叶曲线点
    coefs = np.array(compute_coefficients_interp(points, terms=terms, return_list=True)).astype(np.float32)
    c_num = (coefs.shape[-1] - 2) // 4 + 1  # c_num = k + 1, a0~ak
    theta_fine = np.linspace(0, 2*np.pi, 100)
    xy = coefs[:2]
    coef = coefs[2:]
    an,bn,cn,dn = np.split(coef.reshape([-1, 4]), 4, axis=-1)
    x_approx = sum([an[i-1]*np.cos(i*theta_fine) + bn[i-1]*np.sin(i*theta_fine) for i in range(1, c_num)])
    y_approx = sum([cn[i-1]*np.cos(i*theta_fine) + dn[i-1]*np.sin(i*theta_fine) for i in range(1, c_num)])
    x_approx += xy[0]
    y_approx += xy[1]
    xy2 = np.vstack([x_approx, y_approx]).T.astype(np.int32)
    return xy2,(an,bn,cn,dn)

# dict image_id {image name, w,h,cls, xywh, segments}
def read_json(coco_json):
    with open(coco_json, 'r') as fp:
        coco_dict = json.load(fp)
    r_dict = {}
    images = coco_dict['images']
    for image in images:
        r_dict[image['id']] = {
            'file_name': image['file_name'],
            'height': image['height'],
            'width': image['width'],
            'bbox': [], # xywh, xy 为中心点
            'segmentation': [],
            'categories': []    # 0~...
        }
    annotations = coco_dict['annotations']
    categories = coco_dict['categories']
    cls_ = {}
    names = []
    for i, category in enumerate(categories):
        cls_[category['id']] = i
        names.append(category['name'])
    for label in tqdm(annotations):
        # coco json bbox xywh, xy 为左上角
        r_dict[label['image_id']]['bbox'].append(np.array(label['bbox'], dtype=np.float32))
        r_dict[label['image_id']]['bbox'][-1][0] += r_dict[label['image_id']]['bbox'][-1][2] / 2
        r_dict[label['image_id']]['bbox'][-1][1] += r_dict[label['image_id']]['bbox'][-1][3] / 2
        r_dict[label['image_id']]['segmentation'].append(copy.deepcopy(label['segmentation']))
        r_dict[label['image_id']]['categories'].append(copy.deepcopy(cls_[label['category_id']]))
    return r_dict, names

def save_segment_label(coco_path, r_dict, name=None, terms=32, write_img=1):
    show_path = coco_path.parent / 'show_samples'
    show_path.mkdir(exist_ok=True)
    save_dir = ['origin', 'yuyi', 'shili', 'ft', 'ft-seg', 'mark']
    for d in save_dir:
        (show_path/Path(d)).mkdir(exist_ok=True)

    coco_path = Path(coco_path)        
    background = (32, 178, 170)
    line_color = (0, 0, 0)
    colors = [
        (54, 67, 244), (99, 30, 233), (176, 39, 156), (183, 58, 103), (181, 81, 63),
        (243, 150, 33), (212, 188, 0), (136, 150, 0), (80, 175, 76), (74, 195, 139),
        (57, 220, 205), (59, 235, 255), (0, 152, 255), (34, 87, 255), (72, 85, 121),
        (180, 105, 255), (255, 0, 0), (255, 127, 0), (255, 255, 0), (0, 255, 0),
        (0, 0, 255), (75, 0, 130), (238, 130, 238), (128, 0, 0), (128, 128, 0),
        (0, 128, 0), (128, 0, 128), (0, 128, 128), (0, 0, 128), (139, 69, 19),
        (210, 105, 30), (244, 164, 96), (255, 228, 181), (255, 255, 224), (173, 216, 230),
        (240, 230, 140), (250, 250, 210), (255, 239, 213), (255, 245, 238), (240, 255, 240),
        (255, 69, 0), (255, 165, 0), (255, 215, 0), (154, 205, 50), (0, 255, 127),
        (60, 179, 113), (32, 178, 170), (47, 79, 79), (0, 206, 209), (72, 61, 139),
        (123, 104, 238), (106, 90, 205), (135, 206, 250), (70, 130, 180), (176, 196, 222),
        (95, 158, 160), (100, 149, 237), (0, 191, 255), (30, 144, 255), (25, 25, 112),
        (75, 0, 130), (138, 43, 226), (148, 0, 211), (186, 85, 211), (153, 50, 204),
        (128, 0, 128), (216, 191, 216), (221, 160, 221), (238, 130, 238), (255, 0, 255),
        (139, 0, 139), (255, 20, 147), (199, 21, 133), (219, 112, 147), (255, 182, 193),
        (255, 160, 122), (255, 105, 180), (255, 69, 0), (255, 140, 0), (255, 165, 0)
    ]
    area_groups = []
    for k, v in tqdm(r_dict.items()):
        
        bbox = np.array(v['bbox'])
        if bbox.shape[0] == 0:
            continue
        seg = v['segmentation']
        # 计算宽高乘积
        area = bbox[:, -2] * bbox[:, -1]

        # 根据面积排序索引
        sorted_indices = sorted(range(len(area)), key=lambda i: area[i], reverse=True)

        # 根据排序索引重新排列 bbox 和 seg
        v['bbox'] = [v['bbox'][i] for i in sorted_indices]
        v['segmentation'] = [v['segmentation'][i] for i in sorted_indices]
        v['categories'] = [v['categories'][i] for i in sorted_indices]

        file = coco_path / v['file_name']
        flag = False
        i = 0
        seg0 = None
        mask = None
        for i, seg in enumerate(v['segmentation']):
            if isinstance(seg, list):
                if len(seg) >= 2:
                    flag = True
                    continue
            if isinstance(seg, dict):
                flag = False
                break
        if not file.exists():
            continue
        if flag:
            img = cv2.imread(str(file))
            img_ori = img.copy()
            img_ft = img.copy()
            img = (np.ones_like(img) * background).astype(np.int8)
            img_yuyi = img.copy()   # 语义
            img_shili = img.copy()  # 实例

            s = []
            for i, seg in enumerate(v['segmentation']):
                flag_rle = False
                if isinstance(seg, list):
                    if len(seg) >= 2:
                        seg0 = seg
                    else:
                        seg0 = [seg]
                if isinstance(seg, dict):
                    size = seg['size']
                    counts = seg['counts']
                    mask = np.zeros(size[0]*size[1]).astype(np.uint8)
                    start = 0
                    for j, c in enumerate(counts):
                        mask[start:start + c] = 255 * (j % 2)
                        start += c
                    mask = mask.reshape([size[1], size[0]]).T
                    # _, mask0 = cv2.threshold(mask, 0.5, 255, cv2.THRESH_BINARY)
                    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    flag_rle = True
                    seg0 = contours
                    continue    # 不画此类
                    # seg0 = np.concatenate(contours, axis=0).reshape(-1)

                bbox = v['bbox'][i]
                cls_ = v['categories'][i]
                if flag_rle:
                    empty = np.ones_like(img) * (98, 9, 11) * (mask[..., None] > 0)
                    img = empty*0.9 + img
                    cv2.imwrite(f'{file.stem}-origin-rle.jpg', img)
                else:
                    for j, seg in enumerate(seg0):
                        seg = np.array(seg).reshape(-1, 2).astype(int)
                        cv2.polylines(img_ori, [seg], isClosed=True, color=colors[(cls_+1) % len(colors)], thickness=2)
                        cv2.fillPoly(img_yuyi, [seg], color=colors[(cls_+1) % len(colors)])
                        #cv2.polylines(img_yuyi, [seg], isClosed=True, color=line_color, thickness=1)
                        cv2.fillPoly(img_shili, [seg], color=colors[(i+1) % len(colors)])
                        cv2.polylines(img_shili, [seg], isClosed=True, color=line_color, thickness=1)
                segm = np.concatenate(seg0, axis=0).astype(int).reshape(-1, 2)
                if len(seg0) >= 2:
                    # 多连通域 需要进行处理
                    if 0:
                        # 凹多边形处理, 暂无处理方法
                        hull = function_abc(segm.copy())
                    else:
                        # 凸多边形
                        hull = cv2.convexHull(segm).reshape(-1, 2)
                else:
                    hull = segm.copy()
                xy2,(an,bn,cn,dn) = gen_curve(hull, terms) #hull[n,2]->xy2[n100,2]
                pts_area = polygon_area(hull)
                assert(pts_area>=0 and pts_area<1000*1000)
                pts_area2 = polygon_area(xy2)
                assert(pts_area2>=0 and pts_area2<1000*1000)
                # 使用 OpenCV 的 boundingRect 函数计算外接矩形
                x, y, w, h = cv2.boundingRect(hull)
                rect_area = w * h
                x2, y2, w2, h2 = cv2.boundingRect(xy2)
                rect_area2 = w2 * h2
                ft_area = np.abs(fft_area_abcd(an,bn,cn,dn))
                assert(ft_area>=0 and ft_area<1000*1000)
                area_group = np.array([pts_area,ft_area,pts_area2,rect_area,rect_area2],dtype=np.float32)
                area_groups.append(area_group)
                cv2.polylines(img_ft, [xy2], isClosed=True, color=colors[(i) % len(colors)], thickness=2)
                cv2.fillPoly(img, [xy2], color=colors[(i) % len(colors)])
                cv2.polylines(img, [xy2], isClosed=True, color=line_color, thickness=1)
                s.append(f'[{name[cls_]} {len(seg0)}] {" ".join([str(b) for b in bbox.tolist()])}')
            if write_img:
                cv2.imwrite(f'{str(show_path)}/origin/{file.stem}-origin.jpg', img_ori)
                cv2.imwrite(f'{str(show_path)}/yuyi/{file.stem}-yuyi.jpg', img_yuyi)
                cv2.imwrite(f'{str(show_path)}/shili/{file.stem}-shili.jpg', img_shili)
                cv2.imwrite(f'{str(show_path)}/ft-seg/{file.stem}-ft-seg.jpg', img)
                cv2.imwrite(f'{str(show_path)}/ft/{file.stem}-ft.jpg', img_ft)
                with open(f'{str(show_path)}/mark/{file.stem}.txt', 'w') as fw:
                    fw.write('\n'.join(s))
    # 将列表转换为二维数组，形状为 (n, 4)
    area_groups = np.array(area_groups)#area_groups[n,5]
    area_groups[:,3] = area_groups[:,0] / area_groups[:,3] #pts0/rect
    area_groups[:,4] = area_groups[:,2] / area_groups[:,4] #pts2/rect
    area_groups[:,1] = (area_groups[:,1] - area_groups[:,0]) / area_groups[:,0]
    area_groups[:,2] = (area_groups[:,2] - area_groups[:,0]) / area_groups[:,0]
    mean_area = area_groups[:,0].mean()
    ft_error = area_groups[:,1].mean()
    xy2_error = area_groups[:,2].mean()
    area_rate = area_groups[:,3].mean()
    area2_rate = area_groups[:,4].mean()
    print(f'mean_area={mean_area}')
    print(f'ft_error={ft_error}')
    print(f'xy2_error={xy2_error}')
    print(f'area_rate={area_rate}')
    print(f'area2_rate={area2_rate}')

def fft_label_status(coco_path, r_dict, name=None, terms=[8,16,24,32],write_img=0):
    ags = [[] for _ in range(len(terms))]
    for id, (k, v) in enumerate(tqdm(r_dict.items())):
        bbox = np.array(v['bbox'])
        if bbox.shape[0] == 0:
            continue
        seg = v['segmentation']
        # 计算宽高乘积
        area = bbox[:, -2] * bbox[:, -1]

        # 根据面积排序索引
        sorted_indices = sorted(range(len(area)), key=lambda i: area[i], reverse=True)

        # 根据排序索引重新排列 bbox 和 seg
        v['bbox'] = [v['bbox'][i] for i in sorted_indices]
        v['segmentation'] = [v['segmentation'][i] for i in sorted_indices]
        v['categories'] = [v['categories'][i] for i in sorted_indices]

        file = coco_path / v['file_name']
        flag = False
        i = 0
        seg0 = None
        mask = None

        if file.exists():
             for i, seg in enumerate(v['segmentation']):
                if isinstance(seg, list):
                    if len(seg) >= 2:
                        seg0 = seg
                    else:
                        seg0 = [seg]
                if isinstance(seg, dict):
                    size = seg['size']
                    counts = seg['counts']
                    mask = np.zeros(size[0]*size[1]).astype(np.uint8)
                    start = 0
                    for j, c in enumerate(counts):
                        mask[start:start + c] = 255 * (j % 2)
                        start += c
                    mask = mask.reshape([size[1], size[0]]).T
                    # _, mask0 = cv2.threshold(mask, 0.5, 255, cv2.THRESH_BINARY)
                    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    flag_rle = True
                    seg0 = contours
                    continue    # 不画此类
                    # seg0 = np.concatenate(contours, axis=0).reshape(-1)

                bbox = v['bbox'][i]
                cls_ = v['categories'][i]
                segm = np.concatenate(seg0, axis=0).astype(int).reshape(-1, 2)
                if len(seg0) >= 2:
                    # 多连通域 需要进行处理
                    if 0:
                        # 凹多边形处理, 暂无处理方法
                        hull = function_abc(segm.copy())
                    else:
                        # 凸多边形
                        hull = cv2.convexHull(segm).reshape(-1, 2)
                else:
                    hull = segm.copy()
                for nterm,term in enumerate(terms):
                    if len(hull) > term:
                        xy2,(an,bn,cn,dn) = gen_curve(hull, term) #hull[n,2]->xy2[n100,2]
                        pts_area = polygon_area(hull)
                        assert(pts_area>=0 and pts_area<1000*1000)
                        pts_area2 = polygon_area(xy2)
                        assert(pts_area2>=0 and pts_area2<1000*1000)
                        # 使用 OpenCV 的 boundingRect 函数计算外接矩形
                        x, y, w, h = cv2.boundingRect(hull)
                        rect_area = w * h
                        x2, y2, w2, h2 = cv2.boundingRect(xy2)
                        rect_area2 = w2 * h2
                        ft_area = np.abs(fft_area_abcd(an,bn,cn,dn))
                        assert(ft_area>=0 and ft_area<1000*1000)
                        area_group = np.array([pts_area,ft_area,pts_area2,rect_area,rect_area2],dtype=np.float32)
                        ags[nterm].append(area_group)

    print(f'term mean_area ft_error xy2_error area_rate area2_rate')
    for ntm,term in enumerate(terms):
        # 将列表转换为二维数组，形状为 (n, 4)
        ags[ntm] = np.array(ags[ntm])#ags[n,5]
        ag = ags[ntm]
        ag[:,3] = ag[:,0] / ag[:,3] #pts0/rect
        ag[:,4] = ag[:,2] / ag[:,4] #pts2/rect
        ag[:,1] = (ag[:,1] - ag[:,0]) / ag[:,0]
        ag[:,2] = (ag[:,2] - ag[:,0]) / ag[:,0]
        mean_area = ag[:,0].mean()
        ft_error = ag[:,1].mean()
        xy2_error = ag[:,2].mean()
        area_rate = ag[:,3].mean()
        area2_rate = ag[:,4].mean()
        print(f'{term} {mean_area} {ft_error} {xy2_error} {area_rate} {area2_rate}')


if __name__ == '__main__':
    # 4090
    # coco_root = '/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/coco2017labels'
    # coco_path = coco_root + '/coco/images'
    # labels_path = coco_root + '/coco/labels'
    # coco_json = coco_root + '/coco/annotations'
    # 4090-2
    # coco_root = '/home/liu/datas/coco2017'
    # coco_path = coco_root + '/train/images'
    # labels_path = coco_root + '/train/labels'
    # coco_json = coco_root + '/annotations'
    # CatBug
    #coco_root = 'E:/datas/coco2017'
    coco_root = Path('/home/liu/datas/coco2017')
    coco_path = coco_root / 'val/images'
    #coco_json = Path('annotations')
    coco_json = coco_root / 'annotations'
    json_file = coco_json / 'instances_val2017.json'
    r_dict, name = read_json(json_file)
    #fft_label_status(coco_path, r_dict, name)
    save_segment_label(coco_path, r_dict, name) #, write_img=True

    print('Done')
