# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Wuqiang Li∗, Huan Li, Biyin Zhang, Yaorong Cen, Zhenfeng Shao",
#     title   = "Group-Normalized Fourier Detection for Arbitrary-Shaped Objects",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }

import matplotlib
import matplotlib.pyplot as plt

matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号 '-' 显示为方块的问题
import pylab as mpl  # import matplotlib as mpl
import platform
if platform.system() == 'Windows':
    mpl.rcParams["font.sans-serif"] = ["FangSong"] # 指定默认字体

import argparse
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import os
from models.yolo import OUT_LAYER

FILE = Path(__file__).absolute()
sys.path.append(FILE.parents[0].as_posix())  # add yolov5/ to path

from models.experimental import attempt_load
from utils.datasets import LoadStreams, LoadImages
from utils.general import check_img_size, check_requirements, check_imshow, colorstr, is_ascii,\
    apply_classifier, scale_coords, xyxy2xywh, strip_optimizer, set_logging, increment_path, save_one_box
from utils.post_process import non_max_suppression, non_max_suppression_dfl,non_max_suppression_ft
from utils.plots import Annotator, colors
from utils.torch_utils import select_device, load_classifier, time_sync
from tools.plotbox import plot_one_box, plot_one_box_with_ft

from utils.general import check_dataset

from utils.ft_utils import scale_coords_ft

feature_maps = []

def forward_hook(module, input, output):
    output.retain_grad()
    feature_maps.append(output)

# def backward_hook(module, grad_input, grad_output):
#     gradients.append(grad_output[0])


def detect(model, im,augment,conf_thres, iou_thres, mname=2,agnostic_nms=False,classes=None,max_det=3000):
    #classes = [targets[targets[:, 0] == i, 1:] for i in range(nb)] if save_hybrid else []  # for autolabelling
    # pred = model(im, augment=0, val=True)[0]
    #pred[2=Detect+Detect2][nl][b,a,H,W,Dectct(4(box)+1(conf)+nc) or Detect2(5=1(p)+2(dir)+2(ab))]
    # if detect_mode == "Detect_pts":
    #     pred = rot_nmsv2(pred, conf_thres, iou_thres, ab_thres=ab_thres, fold_angle=fold_angle, threshs=threshs)
    # else:
    #     pred = post_process(pred, conf_thres, iou_thres, ab_thres=ab_thres, fold_angle=fold_angle, mask_dir=mask_dir,threshs=threshs,multi_label=multi_label)
    #->pred[b][nt,10=4(pts)*2+1(conf)+1(cls)]
    visualize = False
    pred = model(im, augment=augment, visualize=visualize)
    if mname == 2:
        pred, pred_ft, _ = pred
    else:
        pred = pred[0]
    #pred[b=1,ntotal=80*80+40*40+20*20,4(xywh)+1(conf)+cls]
    # imgsz = list(im.shape[-2:])#[im.shape[-2],im.shape[-1]]
    # pred[..., 0] *= imgsz[1]  # x
    # pred[..., 1] *= imgsz[0]  # y
    # pred[..., 2] *= imgsz[1]  # w
    # pred[..., 3] *= imgsz[0]  # h
    if not isinstance(pred,torch.Tensor):
        pred = torch.tensor(pred)

    # NMS
    if mname == 0:# pred[b=1,ntotal,4+1+cls]->pred[b=1,nt_nms,6=4+1+1(cls)] 水平框nms
        pred_, indices = non_max_suppression(pred.clone(), conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det, return_indices=True)
        # pred = non_max_suppression(pred, conf_thres, iou_thres, labels=classes, multi_label=True, agnostic=agnostic_nms,paths=paths if save_nms else None,imgsz=imgsz)
    elif mname in [1, 2]:# 水平框dfl nms
        pred_, indices = non_max_suppression_dfl(pred.clone(), conf_thres, iou_thres, labels=classes, multi_label=True, agnostic=agnostic_nms, return_indices=True) #pred[b,ntotal,4(xywh)+nc]->pred[nt_nms,6=4(xyxy)+1(conf)+1(cls)]
        pFt = [ft[indices] for i, ft in enumerate(pred_ft)]
        pred_ = (pred_, pFt) #->pred[b][n_nms,10=8=4(pts)*2+1(conf)+1(cls)]
    return pred_, indices, pred


# @torch.no_grad()
def run(weights='yolov5s.pt',  # model.pt path(s)
        source='data/images',  # file/dir/URL/glob, 0 for webcam
        imgsz=640,  # inference size (pixels)
        conf_thres=0.25,  # confidence threshold
        thresh_scale=1,
        iou_thres=0.45,  # NMS IOU threshold
        max_det=1000,  # maximum detections per image
        device='',  # cuda device, i.e. 0 or 0,1,2,3 or cpu
        plot_label=True,
        dir_line=True,
        save_txt=False,  # save results to *.txt
        view_img=False,
        save_conf=False,  # save confidences in --save-txt labels
        save_crop=False,  # save cropped prediction boxes
        nosave=False,  # do not save images/videos
        classes=None,  # filter by class: --class 0, or --class 0 2 3
        agnostic_nms=False,  # class-agnostic NMS
        augment=False,  # augmented inference
        visualize=False,  # visualize features
        update=False,  # update all models
        project='runs/heatmap',  # save results to project/name
        name='exp',  # save results to project/name
        exist_ok=False,  # existing project/name ok, do not increment
        line_thickness=3,  # bounding box thickness (pixels)
        hide_labels=False,  # hide labels
        hide_conf=False,  # hide confidences
        half=False,  # use FP16 half-precision inference
        save_img_count=0
        ):
    save_img = not nosave and not source.endswith('.txt')  # save inference images
    webcam = source.isnumeric() or source.endswith('.txt') or source.lower().startswith(
        ('rtsp://', 'rtmp://', 'http://', 'https://'))

    # Directories
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # Initialize
    set_logging()
    device = select_device(device)
    half &= device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    pt = True #, onnx, tflite, pb, saved_model = (suffix == x for x in ['.pt', '.onnx', '.tflite', '.pb', ''])  # backend
    classify = False
    stride, names = 64, [f'class{i}' for i in range(1000)]  # assign defaults
    model = attempt_load(weights, map_location=device, fuse=False)  # load FP32 model
    stride = int(model.stride.max())  # model stride
    names = model.module.names if hasattr(model, 'module') else model.names  # get class names
    if half:
        model.half()  # to FP16
    if classify:  # second-stage classifier
        modelc = load_classifier(name='resnet50', n=2)  # initialize
        modelc.load_state_dict(torch.load('resnet50.pt', map_location=device, weights_only=False)['model']).to(device).eval()
    imgsz = check_img_size(imgsz, s=stride)  # check image size

    # Dataloader
    if webcam:
        view_img = check_imshow()
        cudnn.benchmark = True  # set True to speed up constant image size inference
        dataset = LoadStreams(source, img_size=imgsz, stride=stride, auto=pt)
        bs = len(dataset)  # batch_size
    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=pt)
        bs = 1  # batch_size

    train_path = Path(weights).parent
    if(os.path.exists(train_path / 'threshs.npy')):
        threshs = np.load(train_path / 'threshs.npy')
        threshs = torch.from_numpy(threshs)
    else:
        threshs = torch.ones(len(names)) * conf_thres
    threshs = threshs * thresh_scale
    conf_thres = threshs.to(device)

    # 判断模型类别
    ft, dfl_flag = False, False
    for mname in OUT_LAYER.keys():
        m = model.get_module_byname(mname)
        ft_length = 0
        if m is not None:
            ft_length = m.ft_coef_length if mname in ['DetectDFL_FT'] else 0
            dfl_flag = mname in ['DetectDFL', 'DetectDFL_FT']
            break
        
    mname = OUT_LAYER[mname]

    # Run inference
    # if pt and device.type != 'cpu':
    #     model(torch.zeros(1, 3, *imgsz).to(device).type_as(next(model.parameters())))  # run once
    t0 = time.time()
    write_img_count = 0
    amp_stat = [[0 for i in range((ft_length - 2) // 4 + 1)] for j in range(model.nc)]  # [abcd1~n, num]
    vid_path, vid_writer = [None] * bs, [None] * bs

    block_index = [10, 16, 19, 22] # yolov11s-ft
    for i in block_index:
        target_layer = model.model[i]
        target_layer.register_forward_hook(forward_hook)

    print(f'Save to {save_dir}')
    for path, img, im0s, vid_cap in dataset:
        video_mode = getattr(dataset, 'mode', 'image') != 'image'
        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img = img / 255.0  # 0 - 255 to 0.0 - 1.0
        #img[c=3,h,w]
        if len(img.shape) == 3:
            img = img[None]  # expand for batch dim
        img.requires_grad_(True)
        #img[1,3,H,W]
        # Inference
        t1 = time_sync()
        pred, indices, output = detect(model, img, augment,conf_thres, iou_thres, mname=mname,agnostic_nms=False,classes=None,max_det=3000)
        t2 = time_sync()

        # Second-stage classifier (optional)
        if classify:
            pred = apply_classifier(pred, modelc, img, im0s)

        # Process predictions
        if mname==2 : # FT
            pred, pred_ft = pred
        for i, det in enumerate(pred):#batch
            index = indices[i]
            if webcam:  # batch_size >= 1
                fname, s, im0, frame = path[i], f'{i}: ', im0s[i].copy(), dataset.count
            else:
                fname, s, im0, frame = path, '', im0s.copy(), getattr(dataset, 'frame', 0)
            name = os.path.basename(fname)

            p = Path(fname)  # to Path
            save_path = str(save_dir / p.name)  # img.jpg
            txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # img.txt
            s = name
            s += ' %gx%g ' % img.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            if len(det):  # detections per image
                # Rescale boxes from img_size to im0 size
                # det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()
                if mname==0 or mname==1: #HBox
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape, None)  # native-space pred im0.shape[1]
                elif mname == 2:
                    det_ft = pred_ft[i]
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape, None)  # native-space pred im0.shape[1]
                    det_ft = scale_coords_ft(img.shape[2:], det_ft, im0.shape, None)
                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string
                            
                gain = min(img.shape[2:][0] / im0.shape[0], img.shape[2:][1] / im0.shape[1])  # gain  = old / new
                pad = (img.shape[2:][1] - im0.shape[1] * gain) / 2, (img.shape[2:][0] - im0.shape[0] * gain) / 2  # wh padding
                if mname==0 or mname==1: #HBox
                    for *xyxy, conf, cls in reversed(det):
                        xyxy = [x.detach().cpu() for x in xyxy]
                        #
                        if save_txt:  # Write to file
                            xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                            line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
                            with open(txt_path + '.txt', 'a') as f:
                                f.write(('%g ' * len(line)).rstrip() % line + '\n')
                        #
                        label = '{} {:.2f}'.format(names[int(cls)], conf)
                        if not plot_label:
                            label = None
                        plot_one_box(np.array(xyxy), im0, color=colors(int(cls)%len(colors)), label=label)
                elif mname == 2:
                    im0_ = im0.copy()
                    count = 0
                    stop_count = 3
                    count_flag = True
                    for (*xyxy, conf, cls), pft, ind in zip(det, det_ft, index): # reversed
                        count_flag = count < stop_count
                        xyxy_ = xyxy
                        im0 = im0_.copy()
                        xyxy = [x.detach().cpu() for x in xyxy]
                        #
                        ft_gn = torch.tensor(im0.shape)[[1, 0] + [1, 1, 0, 0] * ((pft.shape[-1] - 2) // 4 )].to(pft.device)
                        if save_txt:  # Write to file
                            xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                            line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
                            with open(txt_path + '.txt', 'a') as f:
                                f.write(('%g ' * len(line)).rstrip() % line + '\n')
                            ft_norm = (pft / ft_gn).view(-1).tolist()
                            line = (cls, *ft_norm, conf) if save_conf else (cls, *ft_norm)  # label format
                            with open(txt_path + '.ft', 'a') as f:
                                f.write(('%g ' * len(line)).rstrip() % line + '\n')
                        #
                        label = '{} {:.2f}'.format(names[int(cls)], conf)
                        if not plot_label:
                            label = None
                        # plot_one_box(np.array(xyxy), im0, color=colors(int(cls)%len(colors)), label=label)
                        
                        ft_label = pft.detach().cpu().numpy()
                        plot_one_box_with_ft(np.array(xyxy), im0, 
                                        color=colors(int(cls)), 
                                        label=label, line_thickness=line_thickness,
                                        ft_label=ft_label,
                                        amp_stat=amp_stat[int(cls)])
                        cv2.imwrite(str(save_dir / f'target_{count}_visual.jpg'), im0)
                        # feature_maps.clear()                        
                        a_xy = model.model[-1].anchor_points[:, ind] * model.model[-1].stride_tensor[:, ind]
                        xywh = output[0, ind, :4].clone()
                        xywh[:2] -= a_xy
                        
                                
                        for fi, fmap in enumerate(feature_maps):
                            avg_map = fmap[0].detach().clone().mean(0).unsqueeze(0).unsqueeze(0)
                            avg_map = torch.nn.functional.interpolate(avg_map, size=(im0.shape[0], im0.shape[1]), mode='nearest')
                            norm_map = ((avg_map - avg_map.min()) / (avg_map.max() - avg_map.min()))[0, 0]
                            colored_img = matplotlib.colormaps['viridis'](norm_map.detach().cpu().numpy())[:, :, :3]
                            colored_img = (colored_img * 255).astype(np.uint8)
                            colored_img = cv2.cvtColor(colored_img, cv2.COLOR_RGB2BGR)
                            cv2.imwrite(str(save_dir / f'target_{count}_feature_block_{block_index[fi]}.jpg'), colored_img)

                        for back_loss, name_ in zip([conf, *xywh], ['conf', 'x', 'y', 'w', 'h']):
                            model.zero_grad()
                            back_loss.backward(retain_graph=count_flag)

                            for fi, fmap in enumerate(feature_maps):
                                grad = fmap.grad
                                weights = grad.mean(dim=(2, 3), keepdim=True)
                                cam = (weights * fmap).sum(dim=1, keepdim=True)
                                cam = torch.relu(cam)

                                cam = cam.squeeze().detach().cpu().numpy()
                                cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
                                cam = cv2.resize(cam, (img.shape[2:][1], img.shape[2:][0]))
                                cam = cam[int(pad[1]):int(640 - pad[1]), int(pad[0]):int(640 - pad[0])]  # 去除 padding
                                cam = cv2.resize(cam, (im0.shape[1], im0.shape[0]))  # 回到原图尺寸

                                heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
                                overlay = cv2.addWeighted(im0_.copy(), 0.5, heatmap, 0.5, 0)

                                cv2.imwrite(str(save_dir / f'target_{count}_heatmap_block_{block_index[fi]}_{name_}.jpg'), overlay)
                        count += 1
                        feature_maps.clear()                        
                        if count_flag:
                            break
                        break
                        # model.zero_grad()
                        # a_xy = model.model[-1].anchor_points[:, ind] * model.model[-1].stride_tensor[:, ind]
                        # output0 = output[0][ind, :4].clone()
                        # output0[:2] -= a_xy
                        # output0.mean().backward()
                        # grad_ = img.grad.data.cpu().numpy()[0]
                        # img.grad.zero_()
                        # heatmap1 =np.mean(grad_, axis=0)#对通道求平均
                        # heatmap1 =np.maximum(heatmap1, 0)#保留正值
                        # heatmap1 /= np.max(heatmap1)#归一化

                        
                        # plt.figure(figsize=(15, 10))  # 调整图形大小以适应 2 行 3 列
                        # plt.subplot(1, 3, 1)  # 2 行 3 列的排列
                        # plt.imshow(im0[:, :, ::-1])
                        # plt.subplot(1, 3, 2)  # 2 行 3 列的排列
                        # plt.imshow(img[0].detach().cpu().numpy().transpose(1, 2, 0))
                        # plt.imshow(heatmap, cmap='jet', alpha=0.5)  # 叠加热力图
                        # plt.subplot(1, 3, 3)  # 2 行 3 列的排列
                        # plt.imshow(img[0].detach().cpu().numpy().transpose(1, 2, 0))
                        # plt.imshow(heatmap1, cmap='jet', alpha=0.5)  # 叠加热力图
                        # plt.axis('off')
                        # plt.title(f'Heatmap for Image ')

                        # plt.tight_layout()
                        # plt.savefig('heatmap_combined.png')

                if not webcam and not video_mode:
                    cv2.imencode(p.suffix, im0)[1].tofile(save_path)                    
                # else:
                #     if vid_path[i] != save_path:  # new video
                #         vid_path[i] = save_path
                #         if isinstance(vid_writer[i], cv2.VideoWriter):
                #             vid_writer[i].release()  # release previous video writer
                #         if vid_cap:  # video
                #             fps = vid_cap.get(cv2.CAP_PROP_FPS)
                #             w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                #             h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                #         else:  # stream
                #             fps, w, h = 30, im0.shape[1], im0.shape[0]
                #         save_path = str(Path(save_path).with_suffix(".mp4"))  # force *.mp4 suffix on results videos
                #         vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                #     vid_writer[i].write(im0)
                # Print time (inference + NMS)
                print(f'{s}Done. ({t2 - t1:.3f}s)')


    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        print(f"Results saved to {colorstr('bold', save_dir)}{s}")

    if update:
        strip_optimizer(weights)  # update model (to fix SourceChangeWarning)

    print(f'Done. ({time.time() - t0:.3f}s)')
    if mname in [2]:
        for i in range(model.nc):
            if amp_stat[i][-1] > 0:
                print(f'{i:02d}: ',' '.join([f"{amp/(amp_stat[i][-1]):.2f}" for amp in amp_stat[i][:-1]]))


def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', nargs='+', type=str, default='./runs/train/exp40/weights/best.pt', help='model.pt path(s)')
    parser.add_argument('--source', type=str, default='E:/datas/coco128/images', help='file/dir/URL/glob, 0 for webcam')
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=[640,640], help='inference size h,w')
    parser.add_argument('--conf-thres', type=float, default=0.25, help='confidence threshold')
    parser.add_argument('--thresh_scale', type=float, default=0.2, help='confidence scale')
    parser.add_argument('--iou-thres', type=float, default=0.45, help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=1000, help='maximum detections per image')
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--view-img', default=False, action='store_true', help='show results')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--save-crop', action='store_true', help='save cropped prediction boxes')
    parser.add_argument('--nosave', action='store_true', help='do not save images/videos')
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --class 0, or --class 0 2 3')
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--visualize', action='store_true', help='visualize features')
    parser.add_argument('--update', action='store_true', help='update all models')
    parser.add_argument('--project', default='runs/heatmap', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--line-thickness', default=3, type=int, help='bounding box thickness (pixels)')
    parser.add_argument('--hide-labels', default=False, action='store_true', help='hide labels')
    parser.add_argument('--hide-conf', default=False, action='store_true', help='hide confidences')
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')
    parser.add_argument('--save_img_count', type=int, default=0, help='save_img_count')
    parser.add_argument('--plot_label',default=True, action='store_true', help='plot labels')
    parser.add_argument('--dir_line',action='store_true', help='dir_line')
    opt = parser.parse_args()
    #hbb coco2017
    # opt.weights = '../runs/s-62.15-43.63-v11s-dfl/weights/best.pt' #dfl
    # opt.weights = '../../yolov5-master/weights/last.pt'
    #dfl coco2017
    opt.weights = 'weights/539.pt'
    
    opt.imgsz = [640,640]
    opt.source = '/data/datas/coco2017/val/images' #'/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/seg_0-1712-640/images'
    if not os.path.exists(opt.source):
        # data = 'data/coco_ft.yaml'
        data = 'data/road_seg_ft.yaml'
        data_dict = check_dataset(data)  # check if None
        assert(os.path.exists(data_dict['val']))
        opt.source = data_dict['val']
    opt.device = '1'
    #obb dota1.5
    # opt.weights = 'runs/train/exp8/weights/best.pt'
    # opt.imgsz = [640,640]
    # # #
    # # #data_path = '/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/DOTA1.5'  #4090
    # # #data_path = /media/liu/f4854541-32b0-4d00-84a6-13d3a5dd30f2/datas/DOTA1.5' #4090-2
    # data_path = '/home/user/datas/dota1.5' #svr 2x4090
    # # #data_path = '/media/liu/a2254a68-9f90-4b44-ab2a-ffc55b361238/datas/dota1.5'  #zh3090
    # # #data_path = '/home/liu/data/home/liu/workspace/darknet/datas/GuGe'  darknet-524
    # # #data_path = 'E:/datas/dota1.5'  #windows
    # opt.source = data_path + '/val/patches/images'
    # if not os.path.exists(opt.source):
    #     data = 'data/dota.yaml'
    #     data_dict = check_dataset(data)  # check if None
    #     assert(os.path.exists(data_dict['val']))
    #     opt.source = data_dict['val']
    
    opt.save_txt = True
    opt.save_img_count = 200
    return opt


def main(opt):
    print(colorstr('heatmap: ') + ', '.join(f'{k}={v}' for k, v in vars(opt).items()))
    run(**vars(opt))


if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
