import numpy as np
from pathlib import Path
from PIL import Image

def xyxy2xywh(x):
    # Convert nx4 boxes from [x1, y1, x2, y2] to [x, y, w, h] where xy1=top-left, xy2=bottom-right
    y = np.copy(x)
    y[:, 0] = (x[:, 0] + x[:, 2]) / 2  # x center
    y[:, 1] = (x[:, 1] + x[:, 3]) / 2  # y center
    y[:, 2] = x[:, 2] - x[:, 0]  # width
    y[:, 3] = x[:, 3] - x[:, 1]  # height
    return y

if __name__ == '__main__':
    dir_path = r'/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/OTCBVS/Dataset01/images'

    dir_path = Path(dir_path)
    lab_path = dir_path.parent / 'labels'
    lab_path.mkdir(exist_ok=True)
    part_name = 'groundTruth'
    for label_path in dir_path.rglob(f'*{part_name}.txt'):
        prefix = label_path.name.split('_')[0] + "_"
        with open(label_path, 'r') as fr:
            text = [x.strip().replace('(', '').replace(')', '').split(' ') for x in fr.read().splitlines() if x.strip() != '']
        for txt in text[4:]:
            image_name = txt[0]
            obj_num = int(txt[1])
            bbox = xyxy2xywh(np.array(txt[2:]).reshape(-1, 4).astype(np.float32))
            assert obj_num == bbox.shape[0]
            imgsz = Image.open(dir_path / f'{prefix}{image_name}').size
            bbox = bbox / np.array([[imgsz[0], imgsz[1], imgsz[0], imgsz[1]]])
            with open(lab_path / f'{prefix}{image_name.split(".")[0]}.txt', 'w') as fw:
                for line in bbox:
                    line = line.tolist()
                    fw.write('0 ' + ('%.6f ' * len(line)).rstrip() % (*line,) + '\n')
            print(label_path, '->', lab_path / f'{prefix}{image_name.split(".")[0]}.txt', f'Done.{imgsz}')