# @article{FourierDetByJinLiu,
#     author  = "Jin Liu; Zhongyuan Lu; Yaorong Cen; Hui Hu; Zhenfeng Shao; Yong Hong, Ming Jiang, Miaozhong Xu",
#     title   = "Enhancing Object Detection With Fourier Series",
#     year    = "January 8, 2025",
#     journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
#     volume  = "47",
#     number  = "4",
#     pages   = "2581 - 2596",
#     doi = 10.1109/TPAMI.2025.3526990,
#     month   = "January",
# }
# @article{FourierDetByJinLiu,
#     author  = "Jin Liu, Wuqiang Li∗, Huan Li, Biyin Zhang, Yaorong Cen, Zhenfeng Shao",
#     title   = "Group-Normalized Fourier Detection for Arbitrary-Shaped Objects",
#     Submit to "IEEE Transactions on Pattern Analysis and Machine Intelligence",
# }
import cv2
import numpy as np
import torch
import math
import csv

def ais_to_pixel(x, y, A23):
    original_vector = np.array([x, y, 1])
    result_vector = A23 @ original_vector
    # 提取变换后的x'和y'
    x_prime = result_vector[0]
    y_prime = result_vector[1]
    # px = (x - min_x) * scale + margin
    # py = (y - min_y) * scale + margin
    return int(round(x_prime)), int(round(y_prime))

def read_csv_points(path, columns=("lon", "lat", "altitude", "speed")):
    # Args:
    #     path (str): CSV 文件路径
    #     columns (tuple/list): 需要读取的列名，顺序即输出顺序
    #                          例如 ("lon","lat","altitude","speed")
    # Returns:
    #     np.ndarray: 形状 [L, len(columns)] 的数组
    ais = []
    with open(path, newline='') as f:
        reader = csv.DictReader(f)
        for r in reader:
            try:
                values = []
                for col in columns:
                    values.append(float(r.get(col, 0.0)))  # 如果列缺失，用0代替
                ais.append(values)
            except Exception:
                continue

    return np.array(ais, dtype=float) if ais else np.zeros((0, len(columns)))

def csv_to_img(csv_path, scale_factor = 500, max_allowed = 300000000):
    ais = read_csv_points(csv_path) #ais[L,6(xytdhv)]
    if ais.shape[0] > 0:
        #ais[L,4(xyhv)]
        aisxy = ais[:,:2] #aisxy[L,2(xy)]
        # ---------- 新增：经纬度归零化 + 缩放 ----------
        center = aisxy.mean(axis=0) #center[2]
        pts = (aisxy - center) * scale_factor #pts[L,2(xy)]
        # --------------------------------------------
        #hv normlize->[0,1]
        eps = 1e-5
        h = ais[:,-1] #h[L]
        h = (h-h.min())/(h.max()-h.min()+eps)
        #v
        v = ais[:,-2] #v[L]
        v = (v-v.min())/(v.max()-v.min()+eps)

        # 坐标范围
        min_x, min_y = pts[:,0].min(), pts[:,1].min()
        max_x, max_y = pts[:,0].max(), pts[:,1].max()
        inner_w = max_x - min_x
        inner_h = max_y - min_y
        if inner_w == 0: inner_w = 1.0
        if inner_h == 0: inner_h = 1.0

        margin = 50
        img_w = int(math.ceil(inner_w + 2*margin))
        img_h = int(math.ceil(inner_h + 2*margin))

        # 限制最大尺寸
        scale = 1.0
        if inner_w + 2*margin > max_allowed or inner_h + 2*margin > max_allowed:
            scale = min((max_allowed - 2*margin)/inner_w,
                        (max_allowed - 2*margin)/inner_h)
            img_w = int(math.ceil(inner_w*scale + 2*margin))
            img_h = int(math.ceil(inner_h*scale + 2*margin))

        # 绘制轨迹
        #puv = scale*[(aisxy - center) * scale_factor - min] + margin = aisxy*(scale*scale_factor) + margin - scale*(center*scale_factor + min)
        k, offset = scale*scale_factor, margin - scale*(center*scale_factor + np.array([min_x,min_y]))
        A23 = np.array([[k, 0, offset[0]],
                        [0, k, offset[1]]],dtype=np.float32)
        #->aisxy = 
        puv = [ais_to_pixel(x,y,A23) for x,y in aisxy]
        assert len(puv)==h.shape[0] and len(puv)==v.shape[0]
        puv = np.array(puv) #puv[N,2]

        img = np.zeros((img_h, img_w, 3), dtype=np.uint8) * 255
        # cv2.puvlines(img, [np.array(puv).reshape((-1,1,2))],
        #             isClosed=False, thickness=3, color=(255,0,0), lineType=cv2.LINE_AA)
        for i in range(len(puv) - 1):
            p1 = tuple(puv[i])
            p2 = tuple(puv[i + 1])
            # 取当前节点的 h,v 值作为颜色（也可以用平均值，看你需求）
            color = (
                int(v[i] * 255),   # B
                int(h[i] * 255),   # G
                255                # R
            )
            cv2.line(img, p1, p2, color=color, thickness=3, lineType=cv2.LINE_AA)
    else:
        img = None
        puv = np.empty((0, 2))
        A23 = None
    return img,ais,puv,A23 #img[H,W,C=3] ais[N,6] puv[N,2(uv)] A23[2,3]

# def find_points_in_quadrilateral_simple(dpts, pts):
#     # 使用OpenCV的pointPolygonTest判断点是否在四边形内
#     # 将四边形点转换为适合OpenCV的格式
#     pts_int32 = pts.astype(np.int32)
    
#     subid = []
#     for i, point in enumerate(dpts):
#         # 判断点是否在多边形内
#         result = cv2.pointPolygonTest(pts_int32, tuple(point.astype(np.int32)), False)
#         if result >= 0:  # 在边界上或内部
#             subid.append(i)
    
#     return subid, track[subid]
def find_points_in_quadrilateral_simple(track, obj_poly,tolance=5.0):
    # 使用OpenCV的pointPolygonTest判断点是否在四边形内
    # 将四边形点转换为适合OpenCV的格式 (必须是整数且形状为 [4, 1, 2])
    poly = obj_poly.astype(np.int32).reshape(-1, 1, 2)
    
    subid = []
    for i, point in enumerate(track): #track[N,2(xy)]
        # 将点转换为整数元组 point[2]
        point_int = (int(point[0]), int(point[1]))
        
        # 判断点是否在多边形内
        dist = cv2.pointPolygonTest(poly, point_int, True)
        if dist >= -tolance:  # 在边界上或内部
            subid.append(i)
    
    return torch.tensor(subid), torch.from_numpy(track[subid]) #[nid] [nid,2(xy)]

def generate_convex_hull(points):
    # 生成凸包顶点
    if len(points) < 3:
        return None
    
    # 计算凸包，需要将点转换为float32类型
    points_float32 = points.astype(np.float32)
    hull = cv2.convexHull(points_float32)
    return hull.reshape(-1, 2)

# 更简洁的版本
def find_continuous_segments_v2(ids,keeps):
    # 简化版本的连续区段查找
    if len(ids) == 0:
        return torch.empty((0, 3), dtype=torch.long)
    
    # 找出所有有效位置
    valid_mask = ids >= 0
    valid_indices = torch.where(valid_mask)[0]
    
    if len(valid_indices) == 0:
        return torch.empty((0, 3), dtype=torch.long)
    
    # 获取有效值
    valid_values = ids[valid_indices]
    
    # 找出变化点（值变化或索引不连续）
    changes = torch.zeros(len(valid_indices) + 1, dtype=torch.bool, device=ids.device)
    changes[0] = True
    changes[1:-1] = (valid_values[1:] != valid_values[:-1]) | (valid_indices[1:] != valid_indices[:-1] + 1)
    changes[-1] = True
    
    change_positions = torch.where(changes)[0]
    
    segments = []
    for i in range(len(change_positions) - 1):
        start = change_positions[i]
        end = change_positions[i + 1] - 1
        kid = valid_values[start]
        start_idx = valid_indices[start]
        end_idx = valid_indices[end]
        obj = keeps[kid]
        segments.append([kid, start_idx, end_idx, obj[-1],obj[-2]])
    
    return torch.tensor(segments, dtype=torch.float32)

# 更高效的版本（避免字典操作）
def find_continuous_segments_v4(ids, keeps, max_gap=6):
    # 高效版本的连续区段查找，支持合并间隔较小的相同kid区段
    if len(ids) == 0:
        return torch.empty((0, 5), dtype=torch.float32)
    
    valid_mask = ids >= 0
    valid_indices = torch.where(valid_mask)[0]
    
    if len(valid_indices) == 0:
        return torch.empty((0, 5), dtype=torch.float32)
    
    valid_values = ids[valid_indices]
    
    # 找出变化点
    changes = torch.zeros(len(valid_indices) + 1, dtype=torch.bool, device=ids.device)
    changes[0] = True
    changes[1:-1] = (valid_values[1:] != valid_values[:-1]) | (valid_indices[1:] != valid_indices[:-1] + 1)
    changes[-1] = True
    
    change_positions = torch.where(changes)[0]
    
    # 收集所有原始区段信息
    seg_kids = []
    seg_starts = []
    seg_ends = []
    seg_cls = []
    seg_conf = []
    
    for i in range(len(change_positions) - 1):
        start_pos = change_positions[i]
        end_pos = change_positions[i + 1] - 1
        kid = valid_values[start_pos]
        start_idx = valid_indices[start_pos]
        end_idx = valid_indices[end_pos]
        obj = keeps[kid]
        
        seg_kids.append(kid)
        seg_starts.append(start_idx)
        seg_ends.append(end_idx)
        seg_cls.append(obj[-1])
        seg_conf.append(obj[-2])
    
    # 合并间隔较小的相同kid区段
    merged_segments = []
    n_segments = len(seg_kids)
    
    if n_segments == 0:
        return torch.empty((0, 5), dtype=torch.float32)
    
    current_kid = seg_kids[0]
    current_start = seg_starts[0]
    current_end = seg_ends[0]
    current_cls = seg_cls[0]
    current_conf = seg_conf[0]
    
    for i in range(1, n_segments):
        if (seg_kids[i] == current_kid and 
            seg_starts[i] - current_end - 1 <= max_gap):
            # 合并区段
            current_end = seg_ends[i]
        else:
            # 保存当前区段
            merged_segments.append([current_kid, current_start, current_end, current_cls, current_conf])
            # 开始新区段
            current_kid = seg_kids[i]
            current_start = seg_starts[i]
            current_end = seg_ends[i]
            current_cls = seg_cls[i]
            current_conf = seg_conf[i]
    
    # 添加最后一个区段
    merged_segments.append([current_kid, current_start, current_end, current_cls, current_conf])
    
    return torch.tensor(merged_segments, dtype=torch.float32)

