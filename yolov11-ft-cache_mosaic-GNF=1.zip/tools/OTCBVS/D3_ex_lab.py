import numpy as np
from pathlib import Path
from PIL import Image
import xml.etree.ElementTree as ET

def lt2center(x):
    # Convert nx4 boxes from [x1, y1, x2, y2] to [x, y, w, h] where xy1=top-left, xy2=bottom-right
    y = np.copy(x)
    y[:, 0] = x[:, 0] + x[:, 2] / 2  # x center
    y[:, 1] = x[:, 1] + x[:, 3] / 2  # y center
    # y[:, 2] = x[:, 2] - x[:, 0]  # width
    # y[:, 3] = x[:, 3] - x[:, 1]  # height
    return y

'''

'''

if __name__ == '__main__':
    dir_path = r'/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/OTCBVS/Dataset03/images'

    dir_path = Path(dir_path)
    lab_path = dir_path.parent / 'labels'
    lab_path.mkdir(exist_ok=True)
    part_name = 'tracks-Leykin_Thermal'
    for label_path in dir_path.rglob(f'{part_name}*.cvml'):
        prefix = label_path.stem.split('_')[-1][-1] + "a_"

        img_list = [img for img in dir_path.rglob(f'{prefix}*.bmp')]
        img_list.sort(key=lambda x: str(x.stem))
        tree = ET.parse(label_path)
        root = tree.getroot()

        for frame in root.iter('frame'):
            image_name = img_list[int(frame.get('number'))-1]
            objs = frame.find('objectlist').findall('object')
            bbox = []
            for obj in objs:
                box = obj.find('box')
                bbox.append([box.get(i) for i in 'xywh'])
            bbox = lt2center(np.array(bbox).reshape(-1, 4).astype(np.float32))
            imgsz = Image.open(dir_path / image_name).size
            bbox = bbox / np.array([[imgsz[0], imgsz[1], imgsz[0], imgsz[1]]])
            lab_file = lab_path / f'{image_name.stem}.txt'
            with open(lab_file, 'w') as fw:
                for line in bbox:
                    if line[-1] == 0 or line[-2] == 0:
                        continue
                    line = line.tolist()
                    fw.write('0 ' + ('%.6f ' * len(line)).rstrip() % (*line,) + '\n')
            print(label_path, '->', lab_file, f'Done.{imgsz}')