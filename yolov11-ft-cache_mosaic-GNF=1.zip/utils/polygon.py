import numpy as np

def polygon_area_batch(polys, mask=None):
    # polys: [nt, m, 2]
    # mask: [nt, m] 有效点为 True
    # 返回: [nt] 面积
    if mask is not None:
        # polys = polys.copy()
        # polys[~mask] = polys[:, :1]  # 无效点复制第一个点，避免污染计算
        first_points = polys[:, :1, :]  # (nt,1,2)
        polys = np.where(mask[..., None], polys, first_points)
    x = polys[..., 0]
    y = polys[..., 1]
    return 0.5 * np.abs(
        np.sum(x * np.roll(y, -1, axis=1) - y * np.roll(x, -1, axis=1), axis=1)
    )

def clip_to_rect_batch(polys, xmin, ymin, xmax, ymax):
    # 批量裁剪多边形到矩形范围，返回裁剪后的多边形和 mask
    # polys: [nt, npts, 2]
    nt, npts, _ = polys.shape
    # 先 clip 坐标到范围
    clipped = polys.copy()
    clipped[..., 0] = np.clip(clipped[..., 0], xmin, xmax)
    clipped[..., 1] = np.clip(clipped[..., 1], ymin, ymax)

    # mask 处理掉那些完全在矩形外且交集为空的
    # 注意这里没有精确裁剪边界相交点（可选优化），但对 IOA 近似足够快
    # mask = np.ones((nt, npts), dtype=bool) #mask[nt, npts]
    mask_x = (polys[..., 0] >= xmin) & (polys[..., 0] <= xmax)
    mask_y = (polys[..., 1] >= ymin) & (polys[..., 1] <= ymax)
    mask = mask_x & mask_y  # [nt, npts], True 表示点在矩形内
    return clipped, mask

def out_range_filt_poly_batch(poly_ptses, shape, iou_thresh=0.2):
    # poly_ptses: [nt, npts*2]
    # shape: (h,w) 或 (x1,y1,x2,y2)
    if len(shape) == 2:
        xmin, ymin, xmax, ymax = 0, 0, shape[1], shape[0]
    else:
        xmin, ymin, xmax, ymax = shape

    nt, _ = poly_ptses.shape
    npts = poly_ptses.shape[1] // 2
    polys = poly_ptses.reshape(nt, npts, 2)

    # 原面积
    obj_area = polygon_area_batch(polys) #polys[nt,npts,2]->obj_area[nt]

    assert np.all(obj_area >= 0)

    # 裁剪后多边形
    inter_poly, mask = clip_to_rect_batch(polys, xmin, ymin, xmax, ymax) #->inter_poly[nt,npts,2] mask[nt,npts]
    assert mask.shape == inter_poly.shape[:2]
    inter_area = polygon_area_batch(inter_poly, None) #mask

    # IOA
    ioa = np.zeros(nt, dtype=np.float32)
    valid = obj_area > 1e-9
    ioa[valid] = inter_area[valid] / obj_area[valid]
    ioa[~valid] = np.count_nonzero(mask[~valid], axis=1) / mask.shape[1] #mask.sum(-1)/mask.shape[-1]

    polys_out_ids = np.where(ioa > iou_thresh)[0]
    return polys_out_ids, ioa
