import os
import numpy as np
from PIL import Image
import cv2

# 输入和输出路径
if 1:#for train
    label_dir = 'annotations/training/'     # 输入分割标注图路径
    output_txt_dir = 'train/labels/'        # YOLO+pol+ft格式
else:#for val
    label_dir = 'annotations/validation/'   # 输入分割标注图路径
    output_txt_dir = 'val/labels/'          # YOLO+pol+ft格式
#
output_pol_dir = output_txt_dir              # 原始轮廓点（.pol）
output_ft_dir = output_txt_dir            # 傅立叶系数（.ft）

os.makedirs(output_txt_dir, exist_ok=True)

def is_valid_cid(cid):
    return 1 <= cid <= 150

def compute_coefficients(x, y, terms=8):
    N = len(x)
    t = np.linspace(0, 2*np.pi, N, endpoint=False)
    
    a0 = 1./N * sum(x)
    c0 = 1./N * sum(y)
    
    an, bn, cn, dn = [a0], [0], [c0], [0]

    npt = len(x)
    assert npt==len(y)
    
    ft_terms = max(min(terms,int(0.8*npt)),4)
    for k in range(1, ft_terms):
        an.append(2./N * sum(x * np.cos(k*t)))
        bn.append(2./N * sum(x * np.sin(k*t)))
        cn.append(2./N * sum(y * np.cos(k*t)))
        dn.append(2./N * sum(y * np.sin(k*t)))
    for k in range(ft_terms, terms):
        an.append(0)
        bn.append(0)
        cn.append(0)
        dn.append(0)
    return [an, bn, cn, dn]
def compute_coefficients_interp(x, y, terms=8, interp=True, return_list=False):
    # x = np.array(xy[0::2])
    # y = np.array(xy[1::2])
    if interp:
        x = np.concatenate([x, [x[0]]], dtype=np.float32)
        y = np.concatenate([y, [y[0]]], dtype=np.float32)
        ori = np.linspace(0, 1, x.shape[0], endpoint=True)
        gap = np.linspace(0, 1, terms*2, endpoint=False)
        x = np.interp(gap, ori, x)
        y = np.interp(gap, ori, y)
    N = len(x)
    t = np.linspace(0, 2*np.pi, N, endpoint=False)  # t = t*2pi/n
    a0 = 1./N * sum(x)
    c0 = 1./N * sum(y)
    
    an, bn, cn, dn = [np.zeros(1 + terms) for i in range(4)]
    
    for k in range(1, (N // 2) + 1):    # 1,2,...,int(N/2)
        if k > terms:
            break
        an[k] = 2./N * sum(x * np.cos(k*t))
        bn[k] = 2./N * sum(x * np.sin(k*t))
        cn[k] = 2./N * sum(y * np.cos(k*t))
        dn[k] = 2./N * sum(y * np.sin(k*t))
    if return_list:
        list_coef = [a0, c0]
        for k in range(1, an.shape[0]):
            list_coef.append(an[k])
            list_coef.append(bn[k])
            list_coef.append(cn[k])
            list_coef.append(dn[k])
        return list_coef    # a0, c0, a1, b1, c1, d1, ... ak, bn, ck, dk
    an[0] = a0
    cn[0] = c0
    return (an,bn,cn,dn), (x,y)

# 保留 N 阶傅立叶系数
def keep_n_fourier(z, n):
    coeffs = np.fft.fft(z)
    k = len(coeffs)
    half = n // 2
    new_coeffs = np.zeros_like(coeffs, dtype=np.complex64)
    new_coeffs[:half] = coeffs[:half]
    new_coeffs[-half:] = coeffs[-half:]
    return new_coeffs

# YOLO格式
def convert_to_yolo(label_img, w, h, n=10):
    results = []
    results_pol = []
    results_ft = []
    for cid in np.unique(label_img):
        if is_valid_cid(cid):
            mask = (label_img == cid).astype(np.uint8)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for cnt in contours:
                x, y, bw, bh = cv2.boundingRect(cnt)
                #
                # segm = np.concatenate(seg, axis=0).astype(int).reshape(-1, 2)            
                # hull = cv2.convexHull(segm).reshape(-1, 2)
                # 将 cnt 展平（这是关键一步），确保为 Nx2 的坐标点数组
                cnt = cnt.reshape(-1, 2)  # 通常 cnt 本身就是 (N, 1, 2)，reshape 即可
                # 计算凸包
                cnt = cv2.convexHull(cnt).reshape(-1, 2)
                #
                if bw >= 5 and bh >= 5: # txt格式
                    x_center = (x + bw / 2) / w
                    y_center = (y + bh / 2) / h
                    results.append(f"{cid-1} {x_center:.6f} {y_center:.6f} {bw/w:.6f} {bh/h:.6f}")

                    # POL格式
                    cnt = cnt.reshape(-1, 2).astype(np.float32)
                    cnt[:, 0] /= w
                    cnt[:, 1] /= h
                    results_pol.append(f"{cid-1} " + ' '.join(f"{v:.6f}" for v in cnt.flatten()))

                    # ft格式
                    if 1:
                        x,y = cnt[:,0],cnt[:,1] #[2,npts]
                        # 计算轮廓的傅立叶系数
                        coefs,_ = compute_coefficients_interp(x, y, n)
                        [an, bn, cn, dn] = coefs
                        coeff = [an[0],cn[0]]
                        for i in range(1, n):
                            coeff.append(an[i])
                            coeff.append(bn[i])
                            coeff.append(cn[i])
                            coeff.append(dn[i])
                    else: # 构造复数轮廓
                        z = cnt[:, 0] + 1j * cnt[:, 1]
                        fz = keep_n_fourier(z, n)

                        # ✅ 按图像宽高归一化系数（实部除w，虚部除h）
                        real_norm = fz.real / w
                        imag_norm = fz.imag / h
                        coeff = np.stack([real_norm, imag_norm], axis=1).flatten()
                    # 类别编号从0开始
                    results_ft.append(f"{cid - 1} " + ' '.join(f"{v:.6f}" for v in coeff))
    return results,results_pol,results_ft

# 批处理
for fname in os.listdir(label_dir):
    if not fname.endswith('.png'):
        continue

    img_path = os.path.join(label_dir, fname)
    label_img = np.array(Image.open(img_path))
    h, w = label_img.shape

    base = fname.replace('.png', '')

    yolo_lines,pol_lines,ft_lines = convert_to_yolo(label_img, w, h, n=10)

    with open(os.path.join(output_txt_dir, base + '.txt'), 'w') as f:
        f.write('\n'.join(yolo_lines))

    with open(os.path.join(output_pol_dir, base + '.pol'), 'w') as f:
        f.write('\n'.join(pol_lines))

    with open(os.path.join(output_ft_dir, base + '.ft'), 'w') as f:
        f.write('\n'.join(ft_lines))

    print(f"✅ Processed {fname}: {len(yolo_lines)} boxes, {len(pol_lines)} contours, {len(ft_lines)} shapes")
