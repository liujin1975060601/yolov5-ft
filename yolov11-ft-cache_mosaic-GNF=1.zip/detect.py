# YOLOv5 ������ by Ultralytics, GPL-3.0 license
"""
Run inference on images, videos, directories, streams, etc.

Usage:
    $ python path/to/detect.py --source path/to/img.jpg --weights yolov5s.pt --img 640
"""

import argparse
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import os
from models.yolo import OUT_LAYER

FILE = Path(__file__).absolute()
sys.path.append(FILE.parents[0].as_posix())  # add yolov5/ to path

from models.experimental import attempt_load
from utils.datasets import LoadStreams, LoadImages
from utils.general import check_img_size, check_requirements, check_imshow, colorstr, is_ascii,\
    apply_classifier, scale_coords, xyxy2xywh, strip_optimizer, set_logging, increment_path, save_one_box,get_source
from utils.post_process import non_max_suppression, non_max_suppression_dfl,non_max_suppression_ft
from utils.plots import Annotator, colors
from utils.torch_utils import select_device, load_classifier, time_sync
from tools.plotbox import plot_one_box, plot_one_box_with_ft,render_fourier_heatmap
from general.MyString import add_suffix_to_filename

from utils.ft_utils import scale_coords_ft,fft_1


def detect(model, im,augment,conf_thres, iou_thres, mname=2,agnostic_nms=False,classes=None,max_det=3000,nms_polygon=1):
    #classes = [targets[targets[:, 0] == i, 1:] for i in range(nb)] if save_hybrid else []  # for autolabelling
    # pred = model(im, augment=0, val=True)[0]
    #pred[2=Detect+Detect2][nl][b,a,H,W,Dectct(4(box)+1(conf)+nc) or Detect2(5=1(p)+2(dir)+2(ab))]
    # if detect_mode == "Detect_pts":
    #     pred = rot_nmsv2(pred, conf_thres, iou_thres, ab_thres=ab_thres, fold_angle=fold_angle, threshs=threshs)
    # else:
    #     pred = post_process(pred, conf_thres, iou_thres, ab_thres=ab_thres, fold_angle=fold_angle, mask_dir=mask_dir,threshs=threshs,multi_label=multi_label)
    #->pred[b][nt,10=4(pts)*2+1(conf)+1(cls)]
    visualize = False
    pred = model(im, augment=augment, visualize=visualize)
    if mname == 2:
        pred, pred_ft, _ = pred #pred[b,ntotal,4+1+cls] pred_ft[b,ntotal,2+nf*4]
    else:
        pred = pred[0]
    #pred[b=1,ntotal=80*80+40*40+20*20,4(xywh)+1(conf)+cls]
    # imgsz = list(im.shape[-2:])#[im.shape[-2],im.shape[-1]]
    # pred[..., 0] *= imgsz[1]  # x
    # pred[..., 1] *= imgsz[0]  # y
    # pred[..., 2] *= imgsz[1]  # w
    # pred[..., 3] *= imgsz[0]  # h
    if not isinstance(pred,torch.Tensor):
        pred = torch.tensor(pred)

    # NMS
    if mname == 0:# pred[b=1,ntotal,4(xyxy)+1(conf)+cls]->pred[b=1,nt_nms,6=4(xyxy)+1(conf)+1(cls)] 水平框nms
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det)
        # pred = non_max_suppression(pred, conf_thres, iou_thres, labels=classes, multi_label=True, agnostic=agnostic_nms,paths=paths if save_nms else None,imgsz=imgsz)
    elif mname in [1, 2]:# 水平框dfl nms
        if nms_polygon != 0:
            # 使用polygon算NMS  pred[B][np,6=4(xyxy)+1(conf)+1(cls)] pred_ft[B,ntotal,2+nf*4]
            pred, pred_ft, indices = non_max_suppression_ft(pred, pred_ft, conf_thres, iou_thres, labels=classes, 
                                                      multi_label=True, 
                                                      agnostic=agnostic_nms, 
                                                      return_indices=True, 
                                                      polygon = nms_polygon==2)
        else:
            pred, indices = non_max_suppression_dfl(pred, conf_thres, iou_thres, labels=classes, multi_label=True, agnostic=agnostic_nms, return_indices=True) #pred[b,ntotal,4(xywh)+nc]->pred[nt_nms,6=4(xyxy)+1(conf)+1(cls)]
            #pred[np2,6(xyxyfc)]
            pred_ft = [ft[indices[i]] if indices[i].shape[0]>0 else torch.zeros([0,ft.shape[-1]],dtype=torch.float32) for i, ft in enumerate(pred_ft)] #->pFt[np2,2+nf*4]
        pred = (pred, pred_ft) #->pred[b][n_nms,10=8=4(pts)*2+1(conf)+1(cls)]
    return pred #pred(pred[b][np,6=(xyxyfc)],pFt[b][np,2+nf*4])


@torch.no_grad()
def run(weights='yolov5s.pt',  # model.pt path(s)
        source='data/images',  # file/dir/URL/glob, 0 for webcam
        imgsz=640,  # inference size (pixels)
        conf_thres=0.25,  # confidence threshold
        thresh_scale=1,
        iou_thres=0.45,  # NMS IOU threshold
        max_det=1000,  # maximum detections per image
        nms_polygon=1, #nms_mode
        device='',  # cuda device, i.e. 0 or 0,1,2,3 or cpu
        plot_label=True,
        dir_line=True,
        save_txt=False,  # save results to *.txt
        view_img=False,
        save_conf=False,  # save confidences in --save-txt labels
        save_crop=False,  # save cropped prediction boxes
        nosave=False,  # do not save images/videos
        classes=None,  # filter by class: --class 0, or --class 0 2 3
        agnostic_nms=False,  # class-agnostic NMS
        augment=False,  # augmented inference
        visualize=False,  # visualize features
        update=False,  # update all models
        project='runs/detect',  # save results to project/name
        name='exp',  # save results to project/name
        exist_ok=False,  # existing project/name ok, do not increment
        line_thickness=3,  # bounding box thickness (pixels)
        hide_labels=False,  # hide labels
        hide_conf=False,  # hide confidences
        half=False,  # use FP16 half-precision inference
        save_img_count=0,
        render_heatmap=0
        ):
    save_img = not nosave and not source.endswith('.txt')  # save inference images
    webcam = source.isnumeric() or source.endswith('.txt') or source.lower().startswith(
        ('rtsp://', 'rtmp://', 'http://', 'https://'))

    # Directories
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # Initialize
    set_logging()
    device = select_device(device)
    half &= device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    pt = True #, onnx, tflite, pb, saved_model = (suffix == x for x in ['.pt', '.onnx', '.tflite', '.pb', ''])  # backend
    classify = False
    stride, names = 64, [f'class{i}' for i in range(1000)]  # assign defaults
    model = attempt_load(weights, map_location=device)  # load FP32 model
    stride = int(model.stride.max())  # model stride
    names = model.module.names if hasattr(model, 'module') else model.names  # get class names
    if half:
        model.half()  # to FP16
    if classify:  # second-stage classifier
        modelc = load_classifier(name='resnet50', n=2)  # initialize
        modelc.load_state_dict(torch.load('resnet50.pt', map_location=device, weights_only=False)['model']).to(device).eval()
    imgsz = check_img_size(imgsz, s=stride)  # check image size

    # Dataloader
    if webcam:
        view_img = check_imshow()
        cudnn.benchmark = True  # set True to speed up constant image size inference
        dataset = LoadStreams(source, img_size=imgsz, stride=stride, auto=pt)
        bs = len(dataset)  # batch_size
    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=pt)
        bs = 1  # batch_size

    train_path = Path(weights).parent
    if(os.path.exists(train_path / 'threshs.npy')):
        threshs = np.load(train_path / 'threshs.npy')
        threshs = torch.from_numpy(threshs)
    else:
        threshs = torch.ones(len(names)) * conf_thres
    threshs = threshs * thresh_scale
    conf_thres = threshs.to(device)

    # 判断模型类别
    ft, dfl_flag = False, False
    for mname in OUT_LAYER.keys():
        m = model.get_module_byname(mname)
        ft_length = 0
        if m is not None:
            ft_length = m.ft_coef_length if mname in ['DetectDFL_FT'] else 0
            dfl_flag = mname in ['DetectDFL', 'DetectDFL_FT']
            break
        
    mname = OUT_LAYER[mname]

    # Run inference
    # if pt and device.type != 'cpu':
    #     model(torch.zeros(1, 3, *imgsz).to(device).type_as(next(model.parameters())))  # run once
    t0 = time.time()
    write_img_count = 0
    amp_stat = [[0 for i in range((ft_length - 2) // 4 + 1)] for j in range(model.nc)]  # [abcd1~n, num]
    vid_path, vid_writer = [None] * bs, [None] * bs
    cost_list=[]
    for path, img, im0s, vid_cap in dataset:
        write_img_count += 1
        # if write_img_count > 50:
        #     break
        video_mode = getattr(dataset, 'mode', 'image') != 'image'
        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img = img / 255.0  # 0 - 255 to 0.0 - 1.0
        #img[c=3,h,w]
        if len(img.shape) == 3:
            img = img[None]  # expand for batch dim
        #img[1,3,H,W]

        # Inference
        t1 = time_sync()
        pred = detect(model, img, augment,conf_thres, iou_thres, mname=mname,agnostic_nms=False,classes=None, max_det=3000,nms_polygon=nms_polygon)
        #pred(pred[b][np,6(xyxyfc)],pFt[b][np,2+nf*4])
        t2 = time_sync()

        # Second-stage classifier (optional)
        if classify:
            pred = apply_classifier(pred, modelc, img, im0s)

        # Process predictions
        if mname==2 : # FT
            pred, pred_ft = pred #pred[b][np,6=],pFt[b][np,2+nf*4]
        for i, det in enumerate(pred):#batch
            if webcam:  # batch_size >= 1
                fname, s, im0, frame = path[i], f'{i}: ', im0s[i].copy(), dataset.count
            else:
                fname, s, im0, frame = path, '', im0s.copy(), getattr(dataset, 'frame', 0)
            name = os.path.basename(fname)

            p = Path(fname)  # to Path
            save_path = str(save_dir / p.name)  # img.jpg
            txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # img.txt
            s = name
            s += ' %gx%g ' % img.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            if len(det):  # detections per image
                # Rescale boxes from img_size to im0 size
                # det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()
                if mname==0 or mname==1: #HBox
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape, None)  # native-space pred im0.shape[1]
                elif mname == 2:
                    det_ft = pred_ft[i]
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape, None)  # native-space pred im0.shape[1]
                    det_ft = scale_coords_ft(img.shape[2:], det_ft, im0.shape, None)
                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string
                    
                if mname==0 or mname==1: #HBox
                    for *xyxy, conf, cls in reversed(det):
                        xyxy = [x.cpu() for x in xyxy]
                        #
                        if save_txt:  # Write to file
                            xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                            line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
                            with open(txt_path + '.txt', 'a') as f:
                                f.write(('%g ' * len(line)).rstrip() % line + '\n')
                        #
                        label = '{} {:.2f}'.format(names[int(cls)], conf)
                        if not plot_label:
                            label = None
                        plot_one_box(np.array(xyxy), im0, color=colors(int(cls)%len(colors)), label=label)
                elif mname == 2:
                    if render_heatmap:
                        im0_heat = render_fourier_heatmap(im0.copy(),det_ft) #im0_heat[H,W,C=3]
                        cv2.imencode(p.suffix, im0_heat)[1].tofile(add_suffix_to_filename(save_path,'heat')) 
                    for (*xyxy, conf, cls), pft in zip(reversed(det), reversed(det_ft)):
                        xyxy = [x.cpu() for x in xyxy]
                        #
                        # 1. 转换 cls 为 Python 中的纯 int
                        cls_int = int(cls.item())  # 先转换为 float，再用 int()
                        ft_gn = torch.tensor(im0.shape)[[1, 0] + [1, 1, 0, 0] * ((pft.shape[-1] - 2) // 4 )].to(pft.device)
                        if save_txt:  # Write to file
                            xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                            #
                            line = (cls_int, *xywh, conf) if save_conf else (cls_int, *xywh)  # label format
                            with open(txt_path + '.txt', 'a') as f:
                                f.write(('%g ' * len(line)).rstrip() % line + '\n')
                            ft_norm = (pft / ft_gn).view(-1).tolist()
                            line = (cls_int, *ft_norm, conf) if save_conf else (cls_int, *ft_norm)  # label format
                            with open(txt_path + '.ft', 'a') as f:
                                f.write(('%g ' * len(line)).rstrip() % line + '\n')
                            #->.pol
                            npts = 256
                            x, y = fft_1(ft_norm,npts) #->x[npts],y[npts]
                            # 2. 组装数据行：cls, x0, y0, ..., xn-1, yn-1, 'a'
                            pol_line = [str(cls_int)]
                            for xi, yi in zip(x, y):
                                pol_line.extend([f"{xi}", f"{yi}"])
                                # 3. 写入文件（假设文件名为 output.txt）
                            with open(txt_path + '.pol', 'a') as f:
                                f.write(' '.join(pol_line) + '\n')
                        #
                        label = '{} {:.2f}'.format(names[cls_int], conf)
                        if not plot_label:
                            label = None
                        # plot_one_box(np.array(xyxy), im0, color=colors(cls_int%len(colors)), label=label)
                        
                        ft_label = pft.cpu().numpy()
                        plot_one_box_with_ft(np.array(xyxy), im0, 
                                        color=colors(cls_int), 
                                        label=label, line_thickness=line_thickness,
                                        ft_label=ft_label,
                                        amp_stat=amp_stat[cls_int],
                                        show_amp=0)
                if not webcam and not video_mode:
                    cv2.imencode(p.suffix, im0)[1].tofile(save_path)
                
                else:
                    if vid_path[i] != save_path:  # new video
                        vid_path[i] = save_path
                        if isinstance(vid_writer[i], cv2.VideoWriter):
                            vid_writer[i].release()  # release previous video writer
                        if vid_cap:  # video
                            fps = vid_cap.get(cv2.CAP_PROP_FPS)
                            w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        else:  # stream
                            fps, w, h = 30, im0.shape[1], im0.shape[0]
                        save_path = str(Path(save_path).with_suffix(".mp4"))  # force *.mp4 suffix on results videos
                        vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                    vid_writer[i].write(im0)
                # Print time (inference + NMS)
                cost_time = 1000*(t2 - t1)
                cost_list.append(cost_time)
                print(f'{s}Done. ({cost_time:.3f}ms)')


    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        print(f"Results saved to {colorstr('bold', save_dir)}{s}")

    if update:
        strip_optimizer(weights)  # update model (to fix SourceChangeWarning)

    print(f'Done. ({time.time() - t0:.3f}s)')
    #
    dt = sum(cost_list) / len(cost_list)
    print(f'\033[32mSpeed: {dt:.3f}ms per image. {1000.0/dt:.3f}fps at shape {(1, 3, *imgsz)}\033[0m')
    #
    if mname in [2]:
        for i in range(model.nc):
            if amp_stat[i][-1] > 0:
                print(f'{i:02d}: ',' '.join([f"{amp/(amp_stat[i][-1]):.2f}" for amp in amp_stat[i][:-1]]))
    
def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', nargs='+', type=str, default='./runs/train/exp40/weights/best.pt', help='model.pt path(s)')
    parser.add_argument('--source', type=str, default='E:/datas/coco128/images', help='file/dir/URL/glob, 0 for webcam')
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=[640,640], help='inference size h,w')
    parser.add_argument('--conf-thres', type=float, default=0.25, help='confidence threshold')
    parser.add_argument('--thresh_scale', type=float, default=0.2, help='confidence scale')
    parser.add_argument('--iou-thres', type=float, default=0.45, help='NMS IoU threshold')
    parser.add_argument('--nms_polygon', type=int, default=1, help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=1000, help='maximum detections per image')
    parser.add_argument('--device', default='0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--view-img', default=False, action='store_true', help='show results')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--save-crop', action='store_true', help='save cropped prediction boxes')
    parser.add_argument('--nosave', action='store_true', help='do not save images/videos')
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --class 0, or --class 0 2 3')
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--visualize', action='store_true', help='visualize features')
    parser.add_argument('--update', action='store_true', help='update all models')
    parser.add_argument('--project', default='runs/detect', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--line-thickness', default=3, type=int, help='bounding box thickness (pixels)')
    parser.add_argument('--hide-labels', default=False, action='store_true', help='hide labels')
    parser.add_argument('--hide-conf', default=False, action='store_true', help='hide confidences')
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')
    parser.add_argument('--save_img_count', type=int, default=0, help='save_img_count')
    parser.add_argument('--plot_label',default=True, action='store_true', help='plot labels')
    parser.add_argument('--dir_line',action='store_true', help='dir_line')
    parser.add_argument('--render_heatmap',default=0, help='render_heatmap')
    opt = parser.parse_args()
    #hbb coco2017
    # opt.weights = '../runs/s-62.15-43.63-v11s-dfl/weights/best.pt' #dfl
    # opt.weights = '../../yolov5-master/weights/last.pt'
    #dfl coco2017
    opt.weights = 'runs/train/exp37/weights/best.pt'
    
    #road_seg_ft
    # opt.imgsz = [640,640]
    # opt.source = '' #'/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/seg_0-1712-640/images'
    # opt.source = get_source('','data/road_seg_ft.yaml')
    # opt.device = '1'
    #obb dota1.5
    # opt.weights = 'runs/train/exp8/weights/best.pt'
    # opt.imgsz = [640,640]
    #cityscapes
    # opt.weights = r'runs/train/exp_city_e200_ft_coef_hist7/weights/best.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source('','data/cityscapes_ft.yaml')
    #coco2017
    # opt.weights='../models/coco_ft/coco_ft-yolov11m-ft-bs16-61.63-27.05-epo99-640x640/weights/best.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source('','data/coco_ft.yaml')
    # opt.render_heatmap = 1
    #voc_segment
    # opt.weights = r'../models/voc_segment/voc_segment_ft-yolov11l-ft-bs16-71.23-39.62-epo99-21-896x640/weights/best.pt'
    # opt.weights = 'runs/train/voc_segment_ft-yolov11s-ft-bs16-68.92-42.89-epo62-2-640x640/weights/best.pt'
    # opt.imgsz = [640,896]
    # opt.source = get_source('','data/voc_segment_ft.yaml')

    #track-345
    # opt.weights = '../models/track-345/track-345-yolov11s-obb-bs16-99.36-93.26-epo99-640x640-11/weights/best.pt'
    opt.weights = 'runs/train/exp2/weights/best.pt'
    opt.imgsz = [896,896]
    opt.source = get_source('','data/track-345.yaml') #get_source('','data/track-345.yaml')
    opt.nms_polygon = 1

    #hrsid
    # opt.weights = r'../models/hrsid/hrsid_ft-yolov11s-ft-bs16-85.10-46.99-800x800-KS-5均匀keys/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [800,800]
    # opt.source = get_source(r'','data/hrsid_ft.yaml')

    #mstar
    # opt.weights = r'../models/mstar/mstar_ft-yolov11l-ft-bs16-78.62-58.88-epo149-640x640/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source(r'','data/mstar_ft.yaml')

    #isAID
    # opt.weights = r'../models/isAID/isAID-hull_ft-yolov11s-ft-bs16-71.98-40.54-epo99-640x640/weights/best.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source('','data/isAID-hull_ft.yaml')
    # opt.render_heatmap = 0

    #rsdd
    # opt.weights = r'../models/rsdd/rsdd_ft-yolov11s-ft-bs16-93.29-48.75/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source(r'','data/rsdd_ft.yaml')

    #OTCBVS-D1
    # opt.weights = r'../models/OTCBVS-D1/OTCBVS_D1_ft-yolov11m-ft-bs16-95.02-50.28/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source(r'','data/OTCBVS_D1_ft.yaml')

    #hrsc2016
    # opt.weights = r'../models/hrsc2016/hrsc2016_ft-yolov11s-ft12-bs16-89.43-50.13-epo299/weights/best.pt' 
    # opt.source = get_source('','data/hrsc2016_ft.yaml')

    #cars-vs-seg
    # opt.weights = r'../models/cars-vs-seg/cars-vs-seg-yolov11s-ft-bs2-95.24-56.48-epo999-5-640x640/weights/best.pt' 
    # opt.source = get_source('','data/cars-vs-seg.yaml')

    #road_line
    # opt.weights = r'../models/road_lines/road_lines-90.58-62.18/weights/best.pt' 
    # opt.source = get_source('','data/road_lines.yaml')

    # # #
    # # #data_path = '/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/DOTA1.5'  #4090
    # # #data_path = /media/liu/f4854541-32b0-4d00-84a6-13d3a5dd30f2/datas/DOTA1.5' #4090-2
    # data_path = '/home/user/datas/dota1.5' #svr 2x4090
    # # #data_path = '/media/liu/a2254a68-9f90-4b44-ab2a-ffc55b361238/datas/dota1.5'  #zh3090
    # # #data_path = '/home/liu/data/home/liu/workspace/darknet/datas/GuGe'  darknet-524
    # # #data_path = 'E:/datas/dota1.5'  #windows
    # opt.source = data_path + '/val/patches/images'
    # if not os.path.exists(opt.source):
    #     data = 'data/dota.yaml'
    #     data_dict = check_dataset(data)  # check if None
    #     assert(os.path.exists(data_dict['val']))
    #     opt.source = data_dict['val']
    
    opt.save_txt = True
    opt.save_img_count = 200
    return opt


def main(opt):
    print(colorstr('detect: ') + ', '.join(f'{k}={v}' for k, v in vars(opt).items()))
    run(**vars(opt))


if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
