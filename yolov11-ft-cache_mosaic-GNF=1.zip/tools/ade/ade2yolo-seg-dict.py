import os
import pickle
from PIL import Image
import cv2
from tqdm import tqdm
import numpy as np


# 根目录：你ADE20K数据集所在目录，包含 images/ 和 index_ade20k.pkl
ADE_ROOT = r'E:\datas\ADE20K_2021_17_01'

# pkl索引文件路径
PKL_PATH = os.path.join(ADE_ROOT, 'index_ade20k.pkl')

# 输出目录
OUTPUT_DIR = os.path.join(ADE_ROOT, 'ade20k_yolo_output4')

# 需要保留的类别列表（示例：只保留这几个）
# 如果你想保留全部类别，这里留空即可
# KEEP_CLASSES = []  # 按需修改或者设为空 []
KEEP_CLASSES =["building","tree","bed","windowpane","grass","cabinet","person","door","table","mountain","plant","curtain","chair","car","sofa","shelf","house","mirror","rug","armchair","seat","fence","desk","rock","wardrobe","lamp","bathtub","railing","cushion","base","box","column","signboard","chest","counter","sand","sink","skyscraper","fireplace","refrigerator","grandstand","path","stairs","runway","case","pool","pillow","screen","stairway","river","bridge","bookcase","blind","coffee","toilet","flower","book","hill","bench","countertop","stove","palm","kitchen","computer","swivel","boat","bar","arcade","hovel","bus","towel","light","truck","tower","chandelier","awning","streetlight","booth","television","airplane","dirt","apparel","pole","land","bannister","escalator","ottoman","bottle","buffet","poster","stage","van","ship","fountain","conveyer","canopy","washer","stool","barrel","basket"]
# 加载类别对应的索引
def build_name2id(objectnames):
    name2id = {name: idx for idx, name in enumerate(objectnames)}
    return name2id

def convert_bbox_to_yolo(xmin, ymin, xmax, ymax, img_w, img_h):
    # 归一化中心点坐标和宽高
    x_center = (xmin + xmax) / 2.0 / img_w
    y_center = (ymin + ymax) / 2.0 / img_h
    width = (xmax - xmin) / img_w
    height = (ymax - ymin) / img_h
    return x_center, y_center, width, height

def extract_bboxes_from_seg(seg_img, keep_class_ids):
    # seg_img 是读取的分割图，假设R和G通道编码类别ID（例如ADE20K标准）
    # 这里简化示例：seg_img是二维类别ID图（只提取R通道即可示范）
    
    # ADE20K中，类别ID存储在红色通道
    class_map = np.array(seg_img)  # 转成numpy array，灰度图或R通道

    bboxes = []
    for class_id in keep_class_ids:
        if class_id < 256:
            # 找到对应类别的所有像素坐标
            ys, xs = np.where(class_map == class_id)
            if len(xs) > 0:
                xmin, xmax = xs.min(), xs.max()
                ymin, ymax = ys.min(), ys.max()
                bboxes.append((class_id, xmin, ymin, xmax, ymax))
    return bboxes
# 傅里叶计算
def compute_coefficients_interp(xy, terms=2, interp=True, return_list=False):
    x = np.array(xy[0::2])
    y = np.array(xy[1::2])
    if interp:
        x = np.concatenate([x, [x[0]]], dtype=np.float32)
        y = np.concatenate([y, [y[0]]], dtype=np.float32)
        ori = np.linspace(0, 1, x.shape[0], endpoint=True)
        gap = np.linspace(0, 1, terms * 2, endpoint=False)
        x = np.interp(gap, ori, x)
        y = np.interp(gap, ori, y)
    N = len(x)
    t = np.linspace(0, 2 * np.pi, N, endpoint=False)
    a0 = 1. / N * sum(x)
    c0 = 1. / N * sum(y)

    an, bn, cn, dn = [np.zeros(1 + terms) for _ in range(4)]

    for k in range(1, (N // 2) + 1):
        if k > terms:
            break
        an[k] = 2. / N * sum(x * np.cos(k * t))
        bn[k] = 2. / N * sum(x * np.sin(k * t))
        cn[k] = 2. / N * sum(y * np.cos(k * t))
        dn[k] = 2. / N * sum(y * np.sin(k * t))

    if return_list:
        list_coef = [a0, c0]
        for k in range(1, an.shape[0]):
            list_coef.append(an[k])
            list_coef.append(bn[k])
            list_coef.append(cn[k])
            list_coef.append(dn[k])
        return list_coef

    an[0] = a0
    cn[0] = c0
    return (an, bn, cn, dn), (x, y)

def extract_contours_from_seg(seg_img, keep_class_ids,min_area=40,ft_terms=12):
    # seg_img: 2D numpy array，其中每个像素值是类别ID
    # keep_class_ids: 要提取轮廓的类别ID列表

    class_map = np.array(seg_img, dtype=np.uint8)  # 确保是uint8类型
    contours_per_class = []
    bboxes = []
    fourier_coeffs = []

    for class_id in keep_class_ids:
        if True: # class_id < 256:
            # 构造mask图像：当前class为255，其他为0
            mask = np.where(class_map == class_id, 255, 0).astype(np.uint8)

            # 提取轮廓
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area >= min_area:
                    cnt = cnt.reshape(-1, 2)  # 转换成[n, 2]的点集 (x, y)
                    # 计算凸包
                    cnt = cv2.convexHull(cnt).reshape(-1, 2)
                    #
                    contours_per_class.append((class_id, cnt))

                    # 提取矩形框坐标
                    xmin = np.min(cnt[:, 0])
                    xmax = np.max(cnt[:, 0])
                    ymin = np.min(cnt[:, 1])
                    ymax = np.max(cnt[:, 1])
                    bboxes.append((class_id, xmin, ymin, xmax, ymax))

                    #ft
                    # 扁平化 xy 顺序拼接成一维数组 [x0, y0, x1, y1, ...]
                    flat_xy = cnt.flatten().tolist()
                    ft = compute_coefficients_interp(flat_xy, terms=ft_terms, return_list=True)
                    fourier_coeffs.append((class_id, ft))

    return contours_per_class, bboxes, fourier_coeffs  # 两个列表

def main():
    with open(PKL_PATH, 'rb') as f:
        data_index = pickle.load(f)
 
    if isinstance(data_index, dict):
        print("Keys in data_index:", list(data_index.keys()))
    else:
        print("data_index is not a dict:", data_index)
    # 解析data_index结构
    filenames = data_index['filename']
    folders = data_index['folder']
    objectPresence = data_index['objectPresence']
    objectnames = data_index['objectnames']
    # 类别映射
    name2id = build_name2id(objectnames)

    # 建立过滤列表的类别ID集合
    if KEEP_CLASSES:
        keep_class_ids = set(name2id[name] for name in KEEP_CLASSES if name in name2id)
    else:
        keep_class_ids = set(range(len(objectnames)))  # 全保留
     # 建立保留类名、原始ID、连续ID映射
    keep_class_list = [name for name in KEEP_CLASSES if name in name2id]
    keep_class_ids = [name2id[name] for name in keep_class_list]  # 原始ADE类ID
    class_id_remap = {orig_id: new_id for new_id, orig_id in enumerate(keep_class_ids)}

    print(f"总图像数量: {len(filenames)}")
    print(f"保留类别数: {len(keep_class_ids)}")

    # 创建输出文件夹
    os.makedirs(os.path.join(OUTPUT_DIR, 'train/images'), exist_ok=True)
    os.makedirs(os.path.join(OUTPUT_DIR, 'train/labels'), exist_ok=True)
    os.makedirs(os.path.join(OUTPUT_DIR, 'val/images'), exist_ok=True)
    os.makedirs(os.path.join(OUTPUT_DIR, 'val/labels'), exist_ok=True)

    # 简单划分，前80%训练，后20%验证
    split_index = int(len(filenames) * 0.8)

    terms = 12

    for idx in tqdm(range(len(filenames))):
        filename = filenames[idx]
        folder = folders[idx]
        # 拼接图片路径
        prefix = "ADE20K_2021_17_01/"
        if folder.startswith(prefix):
            folder = os.path.join(ADE_ROOT,folder[len(prefix):])
        img_path = os.path.join(folder, filename)
        seg_filename = os.path.splitext(filename)[0] + '_seg.png'
        seg_path = os.path.join(folder, seg_filename)

        if not os.path.exists(img_path):
            print(f"图片不存在，跳过: {img_path}")
            continue
        if not os.path.exists(seg_path):
            print(f"分割图不存在，跳过: {seg_path}")
            continue

        # 打开图片获取宽高
        with Image.open(img_path) as img:
            img_w, img_h = img.size
        with Image.open(seg_path) as seg_img:
            seg_img = seg_img.convert('L')  # 转灰度图（类别ID一般在R通道）

        # bboxes = extract_bboxes_from_seg(seg_img, keep_class_ids)
        cnts, bboxes,fourier_coeffs = extract_contours_from_seg(seg_img, keep_class_ids,ft_terms=terms)

        # 选择train/val目录
        if idx < split_index:
            img_out_dir = os.path.join(OUTPUT_DIR, 'train/images')
            label_out_dir = os.path.join(OUTPUT_DIR, 'train/labels')
        else:
            img_out_dir = os.path.join(OUTPUT_DIR, 'val/images')
            label_out_dir = os.path.join(OUTPUT_DIR, 'val/labels')

        # 复制图片（如果需要）
        out_img_path = os.path.join(img_out_dir, filename)
        if not os.path.exists(out_img_path):
            # 这里简单复制，如果需要你可以用shutil.copy
            from shutil import copyfile
            copyfile(img_path, out_img_path)

        # 生成标签文件路径
        label_filename = os.path.splitext(filename)[0] + '.txt'
        label_path = os.path.join(label_out_dir, label_filename)

        # 生成YOLO标签：每行格式 <class_id> <x_center> <y_center> <width> <height>
        # ADE20K没有官方bbox，需要用 objectPresence 中信息转换（这里是简化版，具体bbox需要自己解析分割掩码）

        # 这里 objectPresence 是 [C,N]，计数，没具体bbox数据，所以只能做无bbox的标签或忽略
        # 你需要额外的代码去解析 _seg.png 获得bbox或mask，这里只示范生成空文件
        with open(label_path, 'w') as f:
            # 这个示例不生成bbox，实际项目请用掩码提取bbox
            # 这里只写存在的类别id，0 bbox，方便后续补充
            for class_id, xmin, ymin, xmax, ymax in bboxes:
                # 归一化
                x_c = (xmin + xmax) / 2 / img_w
                y_c = (ymin + ymax) / 2 / img_h
                w = (xmax - xmin) / img_w
                h = (ymax - ymin) / img_h
                new_id = class_id_remap[class_id] #class_id_remap
                assert new_id>=0 and new_id<len(KEEP_CLASSES)
                f.write(f"{new_id} {x_c:.6f} {y_c:.6f} {w:.6f} {h:.6f}\n")
        
        ft_filename = os.path.splitext(filename)[0] + '.ft'
        ft_path = os.path.join(label_out_dir, ft_filename)
        with open(ft_path, 'w') as f:
            # 这个示例不生成bbox，实际项目请用掩码提取bbox
            # 这里只写存在的类别id，0 bbox，方便后续补充
            for class_id, ft in fourier_coeffs:
                # 归一化
                ft[0]/=img_w
                ft[1]/=img_h
                new_id = class_id_remap[class_id] #class_id_remap
                assert new_id>=0 and new_id<len(KEEP_CLASSES)
                s = f'{new_id} {ft[0]} {ft[1]}'
                for i in range(terms):
                    ft[2+4*i] /= img_w
                    ft[2+4*i + 1] /= img_w
                    ft[2+4*i + 2] /= img_h
                    ft[2+4*i + 3] /= img_h
                    s+=f' {ft[2+4*i]} {ft[2+4*i + 1]} {ft[2+4*i + 2]} {ft[2+4*i + 3]}'
                f.write(s + '\n')

    print("转换完成，输出路径:", OUTPUT_DIR)

if __name__ == '__main__':
    main()
