import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F
from scipy.stats import gaussian_kde
from scipy.interpolate import interp1d

# 用 softmax(keys) 输出估计值
def softmax_keys_output(true_val, keys, sharpness=20):
    logits = -sharpness * (keys - true_val) ** 2
    weights = F.softmax(torch.tensor(logits, dtype=torch.float32), dim=0).numpy()
    return np.dot(weights, keys)

# 生成非均匀 key 值（等概率密度划分）
def generate_nonuniform_keys(y_vals, num_keys, vrange=(-1.0,1.0)):
    kde = gaussian_kde(y_vals)
    y_grid = np.linspace(vrange[0], vrange[1], 2048)
    pdf = kde(y_grid)
    pdf /= pdf.sum()  # 确保归一化（虽然后面 cumsum 也归一化）
    cdf = np.cumsum(pdf)
    cdf = cdf / cdf[-1]
    
    # 目标分布在 [eps, 1-eps] 区间，防止越界
    eps = 1e-5
    target_probs = np.linspace(eps, 1 - eps, num_keys)
    
    inv_cdf_func = interp1d(cdf, y_grid, kind='linear', bounds_error=False, fill_value="extrapolate")
    keys = inv_cdf_func(target_probs)

    range_size = vrange[1] - vrange[0]

    keys[0]-=0.05*range_size
    keys[-1]+=0.05*range_size
    
    return keys

if __name__ == "__main__":
    # Step 1: 模拟目标函数 sin(x)
    x = np.linspace(0, 2 * np.pi, 500)

    if 1:
        y_true = np.sin(x)
        key_min = -1.0
        key_max = 1.0
        # Step 2: 均匀 key 值
        keys_uniform = np.linspace(-1.0, 1.0, 11)
    else:
        y_true = (x - np.pi) ** 2 - 1  # 目标值分布在 [-1, ~9.87]，偏斜分布
        # Step 2: 调整 key 值范围以适配新的函数输出范围
        key_min = np.min(y_true)
        key_max = np.max(y_true)
        keys_uniform = np.linspace(key_min, key_max, 11)

    # Step 3: 非均匀 key 值
    keys_nonuniform = generate_nonuniform_keys(y_true, 11,(key_min, key_max))

    # Step 4: 用 softmax(keys) 方法进行拟合
    y_pred_uniform = np.array([softmax_keys_output(y, keys_uniform) for y in y_true])
    y_pred_nonuniform = np.array([softmax_keys_output(y, keys_nonuniform) for y in y_true])

    # Step 5: 计算误差
    mse_uniform = np.mean((y_pred_uniform - y_true) ** 2)
    mse_nonuniform = np.mean((y_pred_nonuniform - y_true) ** 2)

    # Step 6: 可视化
    fig = plt.figure(figsize=(8, 6))
    if 0:
        plt.plot(x, y_true, label="gt func(x)", color="black", linewidth=2)
        plt.plot(x, y_pred_uniform, label=f"Uniform Keys (MSE={mse_uniform:.4f})", linestyle="--")
        plt.plot(x, y_pred_nonuniform, label=f"Non-uniform Keys (MSE={mse_nonuniform:.4f})", linestyle=":")
        plt.scatter([2*np.pi] * len(keys_uniform), keys_uniform, color='red', s=40, label='Uniform Keys', zorder=3)
        plt.scatter([2*np.pi+0.2] * len(keys_nonuniform), keys_nonuniform, color='green', s=40, label='Non-uniform Keys', zorder=3)
        for k in keys_uniform:
            plt.axhline(y=k, color='red', alpha=0.08, linestyle='--')
        for k in keys_nonuniform:
            plt.axhline(y=k, color='green', alpha=0.08, linestyle='--')
        plt.title("Softmax(keys) Regression with Uniform vs Non-uniform Keys")
        plt.xlabel("x")
        plt.ylabel("y")
        plt.legend()
        plt.grid(True)
    else:
        import matplotlib.gridspec as gridspec
        # 创建两个子图：左侧主图，右侧直方图
        gs = gridspec.GridSpec(1, 2, width_ratios=[4, 1], wspace=0.05)

        ax_main = plt.subplot(gs[0])
        ax_hist = plt.subplot(gs[1], sharey=ax_main)

        # 主图：函数拟合结果
        ax_main.plot(x, y_true, label="gt func(x)", color="black", linewidth=2)
        ax_main.plot(x, y_pred_uniform, label=f"Uniform Keys (MSE={mse_uniform:.4f})", color='green', linestyle="--")
        ax_main.scatter([2*np.pi] * len(keys_uniform), keys_uniform, color='green', s=40, label='Uniform Keys', zorder=3)
        ax_main.plot(x, y_pred_nonuniform, label=f"Non-uniform Keys (MSE={mse_nonuniform:.4f})", color='red', linestyle=":")
        ax_main.scatter([2*np.pi+0.2] * len(keys_nonuniform), keys_nonuniform, color='red', s=40, label='Non-uniform Keys', zorder=3)

        # for k in keys_uniform:
        #     ax_main.axhline(y=k, color='red', alpha=0.08, linestyle='--')
        # for k in keys_nonuniform:
        #     ax_main.axhline(y=k, color='green', alpha=0.08, linestyle='--')

        ax_main.set_title("Softmax(keys) Regression")
        ax_main.set_xlabel("x")
        ax_main.set_ylabel("y")
        ax_main.legend(loc="lower left")
        ax_main.grid(True)

        # 右侧直方图：y_true 的密度分布
        ax_hist.hist(y_true, bins=50, density=True, orientation='horizontal', color='gray', alpha=0.5)
        ax_hist.set_title("y density")
        ax_hist.set_xticks([])
        ax_hist.set_xlabel("Density")
        plt.setp(ax_hist.get_yticklabels(), visible=False)  # 共享y轴，所以右边不重复标注
    #
    plt.tight_layout()
    plt.show()
