# YOLOv5 ������ by Ultralytics, GPL-3.0 license
"""
Run inference on images, videos, directories, streams, etc.

Usage:
    $ python path/to/detect.py --source path/to/img.jpg --weights yolov5s.pt --img 640
"""
import warnings
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
# matplotlib.cbook._warn_external = lambda *args, **kwargs: None  # 彻底禁止 warning

warnings.simplefilter("ignore", UserWarning)
warnings.filterwarnings(
    "ignore",
    category=UserWarning,
    message="Using categorical units to plot a list of strings*"
)

import argparse
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import os
from models.yolo import OUT_LAYER

FILE = Path(__file__).absolute()
sys.path.append(FILE.parents[0].as_posix())  # add yolov5/ to path

from models.experimental import attempt_load
from utils.datasets import LoadStreams, LoadImages
from utils.general import check_img_size, check_requirements, check_imshow, colorstr, is_ascii,\
    apply_classifier, scale_coords, xyxy2xywh, strip_optimizer, set_logging, increment_path, save_one_box
from utils.post_process import non_max_suppression, non_max_suppression_dfl
from utils.plots import Annotator, colors
from utils.torch_utils import select_device, load_classifier, time_sync
from tools.plotbox import plot_one_box, plot_one_box_with_ft

from utils.general import check_dataset,get_source
from matplotlib import cm
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

from utils.ft_utils import scale_coords_ft

def save_unique_fig(path, base_name='output.png'):
    name = base_name
    base, ext = os.path.splitext(base_name)
    counter = 1
    while (path / name).exists():
        name = f"{base}_{counter}{ext}"
        counter += 1
    return str(path / name)

def create_okds_image(val_, width=320, height=320):
    # 将 [4n+2, 16] 的 val_ 可视化为 RGB 热力图，采用红-绿-蓝三色渐变：
    # - 0.0 → 纯蓝 [0,0,1]
    # - 0.5 → 纯绿 [0,1,0]
    # - 1.0 → 纯红 [1,0,0]
    # - 中间值为渐变过渡色
    val_ = np.sqrt(val_.copy())
    h, w = val_.shape
    assert w == 16, "列数必须为16"
    
    val_norm = np.clip(val_, 0, 1)

    # 创建 RGB 分量：分段线性插值
    R = np.where(val_norm <= 0.5, 0, 2 * (val_norm - 0.5))       # 0→0, 0.5→0, 1→1
    G = np.where(val_norm <= 0.5, 2 * val_norm, 2 * (1 - val_norm))  # 0→0, 0.5→1, 1→0
    B = np.where(val_norm <= 0.5, 1 - 2 * val_norm, 0)           # 0→1, 0.5→0, 1→0

    # 拼成 RGB 图像
    val_color = np.stack([R, G, B], axis=-1)  # [h, w, 3]

    # 每行/列像素数
    row_scale = height // h
    col_scale = width // w

    # 扩展为完整图像
    image = np.repeat(np.repeat(val_color, row_scale, axis=0), col_scale, axis=1)  # [H, W, 3]

    if image.shape[0]!=height:
        from skimage.transform import resize
        image = resize(image, (height, image.shape[1]), preserve_range=True, anti_aliasing=True)
        image = np.clip(image, 0, 1)  # 确保 RGB 不越界

    return image

def draw_val_pred_curve(val_, ft_keys, width=160, height=320, normalize_by='max', show_ticks=True):
    # 改进版 val_pred 垂直曲线图：
    # - 支持 val_pred = (val_ * ft_keys).sum(-1)
    # - 添加灰色水平参考线
    # - 添加底部水平刻度（数值标尺，支持 0~1 或自动最大归一化）
    # - 输出为 numpy RGB 图像
    assert val_.shape == ft_keys.shape, "val_ 和 ft_keys 形状必须一致"
    val_pred = (val_ * ft_keys).sum(-1)  # shape: [4n+2]

    # 归一化
    if normalize_by == 'max':
        vmax = val_pred.max()
        val_pred = val_pred / vmax if vmax > 0 else np.zeros_like(val_pred)

    y = np.arange(len(val_pred))

    x = val_pred  # 原始值（不是像素）
    x_min = x.min()
    x_max = x.max()
    # 防止所有值相同导致异常
    if x_max - x_min < 1e-6:
        x_min -= 0.1
        x_max += 0.1
    # 步骤 2：计算每个 val_pred 的长度（以像素计）和零点偏移
    x_range = x_max - x_min
    x_zero_pixel = -x_min / x_range * width  # val=0 在图像中的位置（像素）
    x_plot = (x - 0) / x_range * width       # 每个条的像素长度（可正可负）

    # 步骤 3：颜色渐变
    x_scaled = (x - x_min) / x_range
    R = np.where(x_scaled <= 0.5, 0, 2 * (x_scaled - 0.5))
    G = np.where(x_scaled <= 0.5, 2 * x_scaled, 2 * (1 - x_scaled))
    B = np.where(x_scaled <= 0.5, 1 - 2 * x_scaled, 0)
    colors = np.stack([R, G, B], axis=1)

    # 创建图像
    fig, ax = plt.subplots(figsize=(width / 100, height / 100), dpi=100)
    fig.subplots_adjust(0.05, 0.05, 0.95, 0.95)  # 留边显示刻度

    # 步骤 4：绘制 barh，从 x=0 对应的像素位置开始，向右（正值）或左（负值）延展
    for yi, xi, ci in zip(y, x_plot, colors):
        ax.barh(yi, width=abs(xi), left=x_zero_pixel if xi >= 0 else x_zero_pixel + xi,
                height=1.0, color=ci, edgecolor='none')


    # 设置坐标轴方向
    ax.set_xlim(0, width)
    ax.set_ylim(len(val_pred), 0)
    
    if show_ticks:
        # 显示真实刻度值（例如 [0.2, 0.4, ..., 1.0]）
        xticks = np.linspace(x_min, x_max, 6)
        ax.set_xticks((xticks - x_min) / (x_max - x_min) * width)
        ax.set_xticklabels([f"{v:.2f}" for v in xticks], fontsize=8)
        ax.tick_params(axis='x', length=3, labelbottom=True)
    else:
        ax.set_xticks([])

    ax.set_yticks([])  # 不显示 Y 轴刻度

    # 渲染为图像
    canvas = FigureCanvas(fig)
    canvas.draw()
    img = np.frombuffer(canvas.tostring_rgb(), dtype='uint8').reshape((int(height), int(width), 3))

    plt.close(fig)
    return img

from skimage.transform import resize
def resize_image_keep_aspect(img, target_height):
    # 保持原图宽高比，将图像缩放到 target_height 高度
    h, w = img.shape[:2]
    # ✅ RGB → BGR：翻转最后一维通道顺序
    if img.shape[-1] == 3:
        img = img[..., ::-1]  # RGB to BGR
    scale = target_height / h
    new_w = int(w * scale)
    resized = resize(img, (target_height, new_w), anti_aliasing=True)
    
    # 如果图像是浮点类型，确保在 [0,1]
    if resized.dtype != np.uint8:
        resized = np.clip(resized, 0, 1)
    return resized


def detect(model, im,augment,conf_thres, iou_thres, mname=2,agnostic_nms=False,classes=None,max_det=3000):
    #classes = [targets[targets[:, 0] == i, 1:] for i in range(nb)] if save_hybrid else []  # for autolabelling
    # pred = model(im, augment=0, val=True)[0]
    #pred[2=Detect+Detect2][nl][b,a,H,W,Dectct(4(box)+1(conf)+nc) or Detect2(5=1(p)+2(dir)+2(ab))]
    # if detect_mode == "Detect_pts":
    #     pred = rot_nmsv2(pred, conf_thres, iou_thres, ab_thres=ab_thres, fold_angle=fold_angle, threshs=threshs)
    # else:
    #     pred = post_process(pred, conf_thres, iou_thres, ab_thres=ab_thres, fold_angle=fold_angle, mask_dir=mask_dir,threshs=threshs,multi_label=multi_label)
    #->pred[b][nt,10=4(pts)*2+1(conf)+1(cls)]
    visualize = False
    pred = model(im, augment=augment, visualize=visualize)
    if mname == 2:
        pred, pred_ft, train_out = pred
        train_out = train_out[-1].permute(0, 2, 1)
    else:
        pred = pred[0]
    #pred[b=1,ntotal=80*80+40*40+20*20,4(xywh)+1(conf)+cls]
    # imgsz = list(im.shape[-2:])#[im.shape[-2],im.shape[-1]]
    # pred[..., 0] *= imgsz[1]  # x
    # pred[..., 1] *= imgsz[0]  # y
    # pred[..., 2] *= imgsz[1]  # w
    # pred[..., 3] *= imgsz[0]  # h
    if not isinstance(pred,torch.Tensor):
        pred = torch.tensor(pred)

    # NMS
    if mname == 0:# pred[b=1,ntotal,4+1+cls]->pred[b=1,nt_nms,6=4+1+1(cls)] 水平框nms
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det)
        # pred = non_max_suppression(pred, conf_thres, iou_thres, labels=classes, multi_label=True, agnostic=agnostic_nms,paths=paths if save_nms else None,imgsz=imgsz)
    elif mname in [1, 2]:# 水平框dfl nms
        pred, indices = non_max_suppression_dfl(pred, conf_thres, iou_thres, labels=classes, multi_label=True, agnostic=agnostic_nms, return_indices=True) #pred[b,ntotal,4(xywh)+nc]->pred[nt_nms,6=4(xyxy)+1(conf)+1(cls)]
        pFt = [ft[indices] for i, ft in enumerate(pred_ft)]
        train_out = [out[indices] for i, out in enumerate(train_out)]
        pred = (pred, pFt) #->pred[b][n_nms,10=8=4(pts)*2+1(conf)+1(cls)]
    return pred, train_out


@torch.no_grad()
def run(weights='yolov5s.pt',  # model.pt path(s)
        source='data/images',  # file/dir/URL/glob, 0 for webcam
        imgsz=640,  # inference size (pixels)
        conf_thres=0.25,  # confidence threshold
        thresh_scale=1,
        iou_thres=0.45,  # NMS IOU threshold
        max_det=1000,  # maximum detections per image
        device='',  # cuda device, i.e. 0 or 0,1,2,3 or cpu
        plot_label=True,
        dir_line=True,
        save_txt=False,  # save results to *.txt
        view_img=False,
        save_conf=False,  # save confidences in --save-txt labels
        save_crop=False,  # save cropped prediction boxes
        nosave=False,  # do not save images/videos
        classes=None,  # filter by class: --class 0, or --class 0 2 3
        agnostic_nms=False,  # class-agnostic NMS
        augment=False,  # augmented inference
        visualize=False,  # visualize features
        update=False,  # update all models
        project='runs/detect',  # save results to project/name
        name='exp',  # save results to project/name
        exist_ok=False,  # existing project/name ok, do not increment
        line_thickness=3,  # bounding box thickness (pixels)
        hide_labels=False,  # hide labels
        hide_conf=False,  # hide confidences
        half=False,  # use FP16 half-precision inference
        save_count_per_cls=0
        ):
    save_img = not nosave and not source.endswith('.txt')  # save inference images
    webcam = source.isnumeric() or source.endswith('.txt') or source.lower().startswith(
        ('rtsp://', 'rtmp://', 'http://', 'https://'))

    # Directories
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # Initialize
    set_logging()
    device = select_device(device)
    half &= device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    pt = True #, onnx, tflite, pb, saved_model = (suffix == x for x in ['.pt', '.onnx', '.tflite', '.pb', ''])  # backend
    classify = False
    stride, names = 64, [f'class{i}' for i in range(1000)]  # assign defaults
    model = attempt_load(weights, map_location=device)  # load FP32 model
    stride = int(model.stride.max())  # model stride
    names = model.module.names if hasattr(model, 'module') else model.names  # get class names
    if half:
        model.half()  # to FP16
    if classify:  # second-stage classifier
        modelc = load_classifier(name='resnet50', n=2)  # initialize
        modelc.load_state_dict(torch.load('resnet50.pt', map_location=device, weights_only=False)['model']).to(device).eval()
    imgsz = check_img_size(imgsz, s=stride)  # check image size

    # Dataloader
    if webcam:
        view_img = check_imshow()
        cudnn.benchmark = True  # set True to speed up constant image size inference
        dataset = LoadStreams(source, img_size=imgsz, stride=stride, auto=pt)
        bs = len(dataset)  # batch_size
    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=pt)
        bs = 1  # batch_size

    train_path = Path(weights).parent
    if(os.path.exists(train_path / 'threshs.npy')):
        threshs = np.load(train_path / 'threshs.npy')
        threshs = torch.from_numpy(threshs)
    else:
        threshs = torch.ones(len(names)) * conf_thres
    threshs = threshs * thresh_scale
    conf_thres = threshs.to(device)

    # 判断模型类别
    ft, dfl_flag = False, False
    for mname in OUT_LAYER.keys():
        m = model.get_module_byname(mname)
        ft_length = 0
        if m is not None:
            ft_length = m.ft_coef_length if mname in ['DetectDFL_FT'] else 0
            dfl_flag = mname in ['DetectDFL', 'DetectDFL_FT']
            break
        
    mname = OUT_LAYER[mname]

    # Run inference
    # if pt and device.type != 'cpu':
    #     model(torch.zeros(1, 3, *imgsz).to(device).type_as(next(model.parameters())))  # run once
    t0 = time.time()
    amp_stat = [[0 for i in range((ft_length - 2) // 4 + 1)] for j in range(model.nc)]  # [abcd1~n, num]
    ft_keys = m.proj_ft.cpu().numpy()
    ft_names = ['a0', 'c0']
    [ft_names.extend([f'{x}{i}' for x in 'abcd']) for i in range(1, (ft_keys.shape[0] - 2) // 4 + 1)]
    vid_path, vid_writer = [None] * bs, [None] * bs
    write_counter = np.zeros((len(names),), dtype=np.int32)
    for path, img, im0s, vid_cap in dataset:
        video_mode = getattr(dataset, 'mode', 'image') != 'image'
        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img = img / 255.0  # 0 - 255 to 0.0 - 1.0
        #img[c=3,h,w]
        if len(img.shape) == 3:
            img = img[None]  # expand for batch dim
        #img[1,3,H,W]
        if write_counter.sum() < save_count_per_cls * len(names):
            # Inference
            t1 = time_sync()
            pred, pred_hist = detect(model, img, augment,conf_thres, iou_thres, mname=mname,agnostic_nms=False,classes=None,max_det=3000)
            t2 = time_sync()

            # Second-stage classifier (optional)
            if classify:
                pred = apply_classifier(pred, modelc, img, im0s)

            # Process predictions
            if mname==2 : # FT
                pred, pred_ft = pred
            for i, det in enumerate(pred):#batch
                if webcam:  # batch_size >= 1
                    fname, s, im0, frame = path[i], f'{i}: ', im0s[i].copy(), dataset.count
                else:
                    fname, s, im0, frame = path, '', im0s.copy(), getattr(dataset, 'frame', 0)
                name = os.path.basename(fname)

                p = Path(fname)  # to Path
                save_path = str(save_dir / p.name)  # img.jpg
                txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # img.txt
                s = name
                s += ' %gx%g ' % img.shape[2:]  # print string
                gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
                if len(det):  # detections per image
                    # Rescale boxes from img_size to im0 size
                    # det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()
                    if mname==0 or mname==1: #HBox
                        det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape, None)  # native-space pred im0.shape[1]
                    elif mname == 2:
                        det_ft = pred_ft[i]
                        det_hist = pred_hist[i]
                        det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape, None)  # native-space pred im0.shape[1]
                        det_ft = scale_coords_ft(img.shape[2:], det_ft, im0.shape, None)
                    # Print results
                    for c in det[:, -1].unique():
                        n = (det[:, -1] == c).sum()  # detections per class
                        s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string
                        
                    if mname==0 or mname==1: #HBox
                        for *xyxy, conf, cls in det:
                            xyxy = [x.cpu() for x in xyxy]
                            #
                            if save_txt:  # Write to file
                                xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                                line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
                                with open(txt_path + '.txt', 'a') as f:
                                    f.write(('%g ' * len(line)).rstrip() % line + '\n')
                            #
                            label = '{} {:.2f}'.format(names[int(cls)], conf)
                            if not plot_label:
                                label = None
                            plot_one_box(np.array(xyxy), im0, color=colors(int(cls)%len(colors)), label=label)
                    elif mname == 2:
                        for obj_id, ((*xyxy, conf, cls), pft, phist) in enumerate(zip(det, det_ft, det_hist)):
                            xyxy = [x.cpu() for x in xyxy]
                            cls_int = int(cls)
                            #
                            ft_gn = torch.tensor(im0.shape)[[1, 0] + [1, 1, 0, 0] * ((pft.shape[-1] - 2) // 4 )].to(pft.device)
                            if save_txt:  # Write to file
                                xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                                line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
                                with open(txt_path + '.txt', 'a') as f:
                                    f.write(('%g ' * len(line)).rstrip() % line + '\n')
                                ft_norm = (pft / ft_gn).view(-1).tolist()
                                line = (cls, *ft_norm, conf) if save_conf else (cls, *ft_norm)  # label format
                                with open(txt_path + '.ft', 'a') as f:
                                    f.write(('%g ' * len(line)).rstrip() % line + '\n')
                            #
                            label = '{} {:.2f}'.format(names[cls_int], conf)
                            if not plot_label:
                                label = None
                            # plot_one_box(np.array(xyxy), im0, color=colors(cls_int%len(colors)), label=label)
                            im0_ = im0.copy()
                            ft_label = pft.cpu().numpy()
                            plot_one_box_with_ft(np.array(xyxy), im0_, 
                                            color=colors(cls_int), 
                                            label='', line_thickness=line_thickness,
                                            ft_label=ft_label,
                                            amp_stat=None)#amp_stat[cls_int]
                            x1, y1, x2, y2 = [int(a_) for a_ in xyxy]
                            x1, x2 = [min(max(x_, 0), im0_.shape[1]) for x_ in [x1, x2]]
                            y1, y2 = [min(max(y_, 0), im0_.shape[0]) for y_ in [y1, y2]]
                            cut_img = im0_[y1:y2, x1:x2, :].copy()
                             
                            #####################################################################
                            if write_counter[cls_int] < save_count_per_cls:
                                with warnings.catch_warnings():
                                    warnings.simplefilter("ignore")

                                    fig = plt.figure(figsize=(10, 1.1 * 11))  # 总共 11 行高

                                    # 顶部 6 行直方图 + 1 行中间省略号 + 4 行底部直方图
                                    outer_gs = gridspec.GridSpec(2, 2, width_ratios=[6, 2.5], height_ratios=[6, 4], hspace=0.2)  # 注意比例适当拉开
                                    hspace = 1
                                    # === 顶部 6 个直方图 ===
                                    top_gs = gridspec.GridSpecFromSubplotSpec(6, 1, subplot_spec=outer_gs[0, 0], hspace=hspace)
                                    val_ = phist.reshape(ft_keys.shape).softmax(-1).cpu().numpy() #val_[4n+2,reg_max=16]
                                    if 0: #fig
                                        for i_hist in range(6):
                                            ax = fig.add_subplot(top_gs[i_hist])
                                            x_label = ['%.3g' % a_ for a_ in ft_keys[i_hist].tolist()]
                                            ax.bar(x_label, val_[i_hist].tolist(), color='skyblue')
                                            ax.set_xticklabels(x_label, rotation=45)
                                            ax.set_ylabel(f'{ft_names[i_hist]}')
                                            ax.set_ylim(0, max(max(v) for v in val_) * 1.1)
                                            val_pred = (val_[i_hist] * ft_keys[i_hist]).sum()
                                            ind = np.searchsorted(ft_keys[i_hist], val_pred) - 1
                                            if ind >=0  and ind < ft_keys[i_hist].shape[-1]:
                                                offset = (val_pred - ft_keys[i_hist][ind]) / (ft_keys[i_hist][ind+1] - ft_keys[i_hist][ind])
                                                ind = ind + offset
                                            else:
                                                ind = max(min(ind, ft_keys[i_hist].shape[-1]), 0)
                                            ax.text(ind, 0.90, f'{val_pred:.4g}', ha='left', va='center', fontsize=10, color='red')


                                        # === 中间省略号 ===
                                        # ax_middle = fig.add_subplot(outer_gs[1, 0])
                                        # ax_middle.axis('off')
                                        fig.text(0.352, 0.42, '...', ha='center', va='center', fontsize=16)
                                        # .\n.\n.

                                        # === 底部 4 个直方图 ===
                                        bottom_gs = gridspec.GridSpecFromSubplotSpec(4, 1, subplot_spec=outer_gs[1, 0], hspace=hspace)
                                        for i_hist_bias in range(4):
                                            i_hist = ft_keys.shape[0] - (4 - i_hist_bias)
                                            ax = fig.add_subplot(bottom_gs[i_hist_bias])
                                            x_label = ['%.3g' % a_ for a_ in ft_keys[i_hist].tolist()]
                                            ax.bar(x_label, val_[i_hist].tolist(), color='skyblue')
                                            ax.set_xticklabels(x_label, rotation=45)
                                            ax.set_ylabel(f'{ft_names[i_hist]}')
                                            ax.set_ylim(0, max(max(v) for v in val_) * 1.1)
                                            val_pred = (val_[i_hist] * ft_keys[i_hist]).sum()
                                            ind = np.searchsorted(ft_keys[i_hist], val_pred) - 1
                                            if ind >=0  and ind < ft_keys[i_hist].shape[-1]:
                                                offset = (val_pred - ft_keys[i_hist][ind]) / (ft_keys[i_hist][ind+1] - ft_keys[i_hist][ind])
                                                ind = ind + offset
                                            else:
                                                ind = max(min(ind, ft_keys[i_hist].shape[-1]), 0)
                                            ax.text(ind, 0.90, f'{val_pred:.4g}', ha='left', va='center', fontsize=10, color='red')
                                            # if i_hist_bias == 0:
                                            #     ax.set_title('...', fontsize=16, pad=10, loc='center')
                                        # === 右侧图像 ===
                                        img_ax = fig.add_subplot(outer_gs[:, 1])
                                        img_ax.imshow(cut_img)
                                        img_ax.axis('off')
                                        img_ax.set_title(names[cls_int], fontsize=16, pad=10, loc='center')

                                        # === 布局优化 ===
                                        fig.subplots_adjust(top=0.98, bottom=0.06, left=0.1, right=0.9)

                                        # 保存
                                        output_name = save_unique_fig(save_dir, f'{p.stem}.png')
                                        plt.savefig(output_name, dpi=100)
                                    else: #OKDS
                                        # 生成热力图图像
                                        height = 420
                                        okds_image = create_okds_image(val_, width=340, height=height)
                                        sp_curve = draw_val_pred_curve(val_, ft_keys, width=340, height=height, normalize_by='')
                                        assert sp_curve.shape[0]==okds_image.shape[0]==height
                                        cut_img_resized = resize_image_keep_aspect(cut_img, target_height=height)
                                        assert cut_img_resized.shape[0]==okds_image.shape[0]==height

                                        # ✅ 2. 如果 cut_img_resized 是 float，转 uint8
                                        if cut_img_resized.dtype != np.uint8:
                                            cut_img_resized = (cut_img_resized * 255).astype(np.uint8)

                                        # ✅ 3. 三图像宽度可能不同，统一转 uint8
                                        okds_image_uint8 = (okds_image * 255).astype(np.uint8) if okds_image.dtype != np.uint8 else okds_image
                                        sp_curve_uint8 = sp_curve.astype(np.uint8)

                                        # ✅ 4. 拼接三张图像：cut_img | okds_image | sp_curve
                                        combined_image = np.concatenate([cut_img_resized, okds_image_uint8, sp_curve_uint8], axis=1)  # 横向拼接

                                        plt.imsave(save_dir / f'{names[cls_int]}-{p.stem}-{obj_id}.png', combined_image)
                                        # 显示图像
                                        if 0:
                                            plt.imshow(okds_image)
                                            plt.title("OKDS Heatmap (Blue → Red)")
                                            plt.axis('off')
                                            plt.show()
                                        
                                    plt.close()
                                    write_counter[cls_int] += 1


                # if not webcam and not video_mode:
                #     cv2.imencode(p.suffix, im0)[1].tofile(save_path)                    
                # else:
                #     if vid_path[i] != save_path:  # new video
                #         vid_path[i] = save_path
                #         if isinstance(vid_writer[i], cv2.VideoWriter):
                #             vid_writer[i].release()  # release previous video writer
                #         if vid_cap:  # video
                #             fps = vid_cap.get(cv2.CAP_PROP_FPS)
                #             w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                #             h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                #         else:  # stream
                #             fps, w, h = 30, im0.shape[1], im0.shape[0]
                #         save_path = str(Path(save_path).with_suffix(".mp4"))  # force *.mp4 suffix on results videos
                #         vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                #     vid_writer[i].write(im0)
                # Print time (inference + NMS)
                print(f'{s}Done. Save {cls_int}:{write_counter[cls_int]} imgs now({t2 - t1:.3f}s)')
        else:
            break


    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        print(f"Results saved to {colorstr('bold', save_dir)}{s}")

    if update:
        strip_optimizer(weights)  # update model (to fix SourceChangeWarning)

    print(f'Done. ({time.time() - t0:.3f}s)')
    if mname in [2]:
        for i in range(model.nc):
            if amp_stat[i][-1] > 0:
                print(f'{i:02d}: ',' '.join([f"{amp/(amp_stat[i][-1]):.2f}" for amp in amp_stat[i][:-1]]))
    
def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', nargs='+', type=str, default='./runs/train/exp40/weights/best.pt', help='model.pt path(s)')
    parser.add_argument('--source', type=str, default='E:/datas/coco128/images', help='file/dir/URL/glob, 0 for webcam')
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=[640,640], help='inference size h,w')
    parser.add_argument('--conf-thres', type=float, default=0.25, help='confidence threshold')
    parser.add_argument('--thresh_scale', type=float, default=0.2, help='confidence scale')
    parser.add_argument('--iou-thres', type=float, default=0.45, help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=1000, help='maximum detections per image')
    parser.add_argument('--device', default='0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--view-img', default=False, action='store_true', help='show results')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--save-crop', action='store_true', help='save cropped prediction boxes')
    parser.add_argument('--nosave', action='store_true', help='do not save images/videos')
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --class 0, or --class 0 2 3')
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--visualize', action='store_true', help='visualize features')
    parser.add_argument('--update', action='store_true', help='update all models')
    parser.add_argument('--project', default='runs/detect_obj_hist', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--line-thickness', default=3, type=int, help='bounding box thickness (pixels)')
    parser.add_argument('--hide-labels', default=False, action='store_true', help='hide labels')
    parser.add_argument('--hide-conf', default=False, action='store_true', help='hide confidences')
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')
    parser.add_argument('--save_count_per_cls', type=int, default=8, help='save_count_per_cls')
    parser.add_argument('--plot_label',default=True, action='store_true', help='plot labels')
    parser.add_argument('--dir_line',action='store_true', help='dir_line')
    opt = parser.parse_args()
    #hbb coco2017
    # opt.weights = '../runs/s-62.15-43.63-v11s-dfl/weights/best.pt' #dfl
    # opt.weights = '../models/coco_ft/coco_ft-yolov11m-ft-bs16-63.24-36.31-a0c0+coef/weights/best_map50.pt' 
    # opt.imgsz = [640,640]
    # opt.source = get_source('','data/coco_ft.yaml')

    #cityscapes
    # opt.weights = '../models/cityscapes/cityscapes_ft-yolov11l-ft-bs16-53.24-22.36/weights/best_map50.pt' 
    # opt.imgsz = [640,640]
    # opt.source = get_source('','data/cityscapes_ft.yaml')

    #dota
    # opt.weights = '../models/dota/dota_ft-yolov11s-ft-bs16-73.57-38.91-epo99-640x640/weights/best.pt' 
    # opt.imgsz = [640,640]
    # opt.source = get_source('','data/dota_ft.yaml')

    #hrsc2016
    # opt.weights = '../models/hrsc2016/hrsc2016_ft-yolov11l-ft-bs16-92.5-43.58-epo299/weights/best.pt'
    opt.weights = '../models/hrsc2016/hrsc2016_ft-yolov11s-ft12-bs16-89.43-50.13-epo299/weights/best.pt'
    opt.source = get_source('','data/hrsc2016_ft.yaml')

    #isAID
    # opt.weights = '../models/isAID/isAID-hull_ft-yolov11s-ft-bs16-71.85-39.12-gauss8/weights/best.pt' 
    # opt.imgsz = [640,640]
    # opt.source = get_source('','data/isAID-hull_ft.yaml')

    #voc_segment
    # opt.weights = r'../models/voc_segment/voc_segment_ft-yolov11l-ft-bs16-71.23-39.62-epo99-21-896x640/weights/best.pt'
    # opt.imgsz = [640,896]
    # opt.source = get_source('','data/voc_segment_ft.yaml')

    #obb dota1.5
    # opt.weights = 'runs/train/exp8/weights/best.pt'
    # opt.imgsz = [640,640]
    # # #
    # # #data_path = '/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/DOTA1.5'  #4090
    # # #data_path = /media/liu/f4854541-32b0-4d00-84a6-13d3a5dd30f2/datas/DOTA1.5' #4090-2
    # data_path = '/home/user/datas/dota1.5' #svr 2x4090
    # # #data_path = '/media/liu/a2254a68-9f90-4b44-ab2a-ffc55b361238/datas/dota1.5'  #zh3090
    # # #data_path = '/home/liu/data/home/liu/workspace/darknet/datas/GuGe'  darknet-524
    # # #data_path = 'E:/datas/dota1.5'  #windows
    # opt.source = data_path + '/val/patches/images'
    # if not os.path.exists(opt.source):
    #     data = 'data/dota.yaml'
    #     data_dict = check_dataset(data)  # check if None
    #     assert(os.path.exists(data_dict['val']))
    #     opt.source = data_dict['val']

    #hrsid
    # opt.weights = r'../models/hrsid/hrsid_ft-yolov11s-ft-bs16-85.10-46.99-800x800-KS-5均匀keys/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [800,800]
    # opt.source = get_source(r'','data/hrsid_ft.yaml')

    #mstar
    # opt.weights = r'../models/mstar/mstar_ft-yolov11l-ft-bs16-78.62-58.88-epo149-640x640/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source(r'','data/mstar_ft.yaml')

    #rsdd
    # opt.weights = r'../models/rsdd/rsdd_ft-yolov11s-ft-bs16-93.29-48.75/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source(r'','data/rsdd_ft.yaml')

    #OTCBVS-D1
    # opt.weights = r'../models/OTCBVS-D1/OTCBVS_D1_ft-yolov11m-ft-bs16-95.02-50.28/weights/best_map50.pt' #'yolov11s.pt'#'weights/yolov5m.pt'
    # opt.imgsz = [640,640]
    # opt.source = get_source(r'','data/OTCBVS_D1_ft.yaml')
    
    opt.save_txt = True
    opt.save_count_per_cls = 10
    return opt


def main(opt):
    print(colorstr('detect: ') + ', '.join(f'{k}={v}' for k, v in vars(opt).items()))
    run(**vars(opt))


if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
