import os
import shutil
from pathlib import Path

def process_directory(base_path):
    """处理主目录下的所有子目录"""
    base_path = Path(base_path)
    
    # 验证基础路径是否存在
    if not base_path.exists():
        print(f"错误: 目录 {base_path} 不存在")
        return
    if not base_path.is_dir():
        print(f"错误: {base_path} 不是目录")
        return
    
    # 遍历所有子目录
    for subdir in base_path.iterdir():
        if subdir.is_dir():
            process_subdirectory(subdir)

def process_subdirectory(subdir_path):
    """处理单个子目录：创建images文件夹并重命名移动文件"""
    # 创建images子目录
    images_dir = subdir_path.parent / "images"
    if not images_dir.exists():
        images_dir.mkdir()
    
    # 获取子目录名称作为前缀
    prefix = subdir_path.name + "_"
    
    print(f"处理目录: {subdir_path}")
    print(f"  使用前缀: {prefix}")
    print(f"  目标目录: {images_dir}")
    
    # 计数器
    moved_count = 0
    
    # 遍历子目录中的所有文件和子目录
    for item in subdir_path.iterdir():
        # 跳过images目录本身
        if item == images_dir:
            continue
            
        # 跳过目录（只处理文件）
        if item.is_dir():
            print(f"  跳过目录: {item.name}")
            continue
            
        # 获取新的文件名（添加前缀）
        new_name = prefix + item.name
        new_path = images_dir / new_name
        
        # 移动文件
        try:
            shutil.move(str(item), str(new_path))
            moved_count += 1
            print(f"  移动: {item.name} -> {new_name}")
        except Exception as e:
            print(f"  错误: 无法移动 {item.name} - {str(e)}")
    
    print(f"  完成: 移动了 {moved_count} 个文件\n")

if __name__ == "__main__":
    import sys
    
    # 获取用户输入的目录路径
    # if len(sys.argv) != 2:
    #     print("使用方法: python script.py <目标目录>")
    #     sys.exit(1)
    
    # target_dir = sys.argv[1]
    target_dir = '/media/liu/088d8f6e-fca3-4aed-871f-243ad962413b/datas/OTCBVS/Dataset03'
    
    print(f"开始处理目录: {target_dir}")
    print("=" * 50)
    
    try:
        process_directory(target_dir)
    except Exception as e:
        print(f"处理过程中发生错误: {str(e)}")
        sys.exit(1)
    
    print("=" * 50)
    print("所有目录处理完成！")
