from pathlib import Path
import sys
import subprocess
import yaml
from tqdm import tqdm

import warnings
warnings.filterwarnings("ignore", module="shapely")

if __name__ == '__main__':
    
    model_dir = Path('/home/user/workspace/yolov5/yolov5-dfl-ft/models-all')
    tasks = [task for task in model_dir.glob('*') if task.is_dir()]


    # 直接获取 Python 解释器的绝对路径
    python_path = sys.executable
    task_bar = tqdm(tasks)
    for task in task_bar:
        if task.name not in ['hrsc2016', 'coco2017']:
            continue
        task_bar.set_description(f'Task[{task.name}]')
        models = [model for model in task.glob('*') if model.is_dir()]
        model_bar = tqdm(models)
        for model in model_bar:
            weights = ['best.pt', 'best_map50.pt']
            if (model / 'opt.yaml').exists():
                with open(model / 'opt.yaml') as f:
                    data_yaml = yaml.safe_load(f)['data']
                for weight in weights:
                    m_file = model / 'weights' / weight
                    if m_file.exists():
                        for i in range(2):
                            polygon = i == 1
                            model_bar.set_description(f'Task[{model.name}] {m_file.name} | polygon: {polygon}')
                            cmd_op = f'{python_path} val.py --weights {m_file} --data {data_yaml} --device 1'
                            exp = task.name + '/' + model.name + ('_AP50' if 'map50' in weight else '')
                            if polygon:
                                cmd_op += ' --polygon'
                                exp += '_polygon'
                            cmd_op += f' --name {exp}'
                            process = subprocess.Popen(f'{cmd_op}', bufsize=0, shell=True) # , stdout=subprocess.PIPE
                            print() 
                            return_ = process.wait()
                            print(exp, f'Return: {return_}', 'Done.', sep='\t')
                    
            

