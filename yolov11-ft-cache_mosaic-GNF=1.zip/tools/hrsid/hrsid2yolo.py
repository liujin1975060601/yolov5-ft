import os
import json
import numpy as np
import cv2
from glob import glob
from tqdm import tqdm

# ==== 核心函数 ====
def compute_coefficients_interp(xy, terms=12, interp=True, return_list=False):
    x = np.array(xy[0::2])
    y = np.array(xy[1::2])
    if interp:
        x = np.concatenate([x, [x[0]]], dtype=np.float32)
        y = np.concatenate([y, [y[0]]], dtype=np.float32)
        ori = np.linspace(0, 1, x.shape[0], endpoint=True)
        gap = np.linspace(0, 1, terms * 2, endpoint=False)
        x = np.interp(gap, ori, x)
        y = np.interp(gap, ori, y)
    N = len(x)
    t = np.linspace(0, 2 * np.pi, N, endpoint=False)
    a0 = 1. / N * np.sum(x)
    c0 = 1. / N * np.sum(y)
    an, bn, cn, dn = [np.zeros(terms + 1) for _ in range(4)]
    for k in range(1, (N // 2) + 1):
        if k > terms:
            break
        an[k] = 2. / N * np.sum(x * np.cos(k * t))
        bn[k] = 2. / N * np.sum(x * np.sin(k * t))
        cn[k] = 2. / N * np.sum(y * np.cos(k * t))
        dn[k] = 2. / N * np.sum(y * np.sin(k * t))
    if return_list:
        list_coef = [a0, c0]
        for k in range(1, terms + 1):
            list_coef.extend([an[k], bn[k], cn[k], dn[k]])
        return list_coef
    an[0] = a0
    cn[0] = c0
    return (an, bn, cn, dn), (x, y)

def ft_scale(ft, scale):
    assert ((len(ft)-2) % 4) == 0
    scalex, scaley = scale
    ft[0] *= scalex
    ft[1] *= scaley
    ft[2::4] *= scalex
    ft[3::4] *= scalex
    ft[4::4] *= scaley
    ft[5::4] *= scaley

def fft_1(coeffs, npts):
    n = (len(coeffs) - 2) // 4
    t = np.linspace(0, 1, npts, endpoint=False)
    x = np.ones_like(t) * coeffs[0]
    y = np.ones_like(t) * coeffs[1]
    offset = 2
    for i in range(n):
        a, b, c, d = coeffs[offset : offset + 4]
        x += a * np.cos(2*np.pi*(i+1)*t) + b * np.sin(2*np.pi*(i+1)*t)
        y += c * np.cos(2*np.pi*(i+1)*t) + d * np.sin(2*np.pi*(i+1)*t)
        offset += 4
    return x, y

# ==== 主函数 ====
def convert_hrsid_to_yolo(data_path, json_path, image_dir, output_dir, ft_terms=12, hull=1, vis_count=10):
    output_dir = os.path.join(data_path, output_dir)
    os.makedirs(f"{output_dir}/images", exist_ok=True)
    os.makedirs(f"{output_dir}/labels", exist_ok=True)

    with open(os.path.join(data_path, json_path), 'r') as f:
        data = json.load(f)

    img_id_to_name = {img['id']: img['file_name'] for img in data['images']}
    img_id_to_hw = {img['id']: (img['width'], img['height']) for img in data['images']}
    image_id_to_annotations = {}
    for ann in data['annotations']:
        image_id_to_annotations.setdefault(ann['image_id'], []).append(ann)
    
    # 写入 names.txt
    cat_id_to_name = {cat['id']: cat['name'] for cat in data['categories']}

    # 构建 names 列表：id==0 放第1行，id==1放第2行....
    names_list=[]
    names_dict={}
    max_cls_id = max(cat_id_to_name.keys())
    for i in range(max_cls_id + 1):
        if i in cat_id_to_name:
            names_dict[i] = len(names_list)
            names_list.append(cat_id_to_name[i])
    # names_list = [cat_id_to_name.get(i, f"class_{i}") for i in range(max_cls_id + 1)]

    # 写入到 output_dir/names.txt
    with open(os.path.join(output_dir, 'names.txt'), 'w') as f:
        f.write("\n".join(names_list))

    for idx, (img_id, anns) in enumerate(tqdm(image_id_to_annotations.items(), desc="Processing images")):
        img_name = img_id_to_name[img_id]
        W, H = img_id_to_hw[img_id]
        base_name = os.path.splitext(os.path.basename(img_name))[0]

        image_path = os.path.join(data_path, image_dir, img_name)
        if os.path.exists(image_path):
            dst_image_path = os.path.join(output_dir, "images", os.path.basename(img_name))
            if not os.path.exists(dst_image_path):
                os.system(f'cp "{image_path}" "{dst_image_path}"')

            txt_lines, ft_lines, pol_lines = [], [], []
            img = cv2.imread(image_path) if idx < vis_count else None

            for ann in anns:#objs loop
                cls = names_dict[ann['category_id']]
                seg = ann['segmentation'][0]
                pts = [[seg[i], seg[i+1]] for i in range(0, len(seg), 2)]

                # YOLO 格式
                poly = np.array(pts, dtype=np.float32)
                x_min, y_min = poly[:,0].min(), poly[:,1].min()
                x_max, y_max = poly[:,0].max(), poly[:,1].max()
                cx = (x_min + x_max) / 2 / W
                cy = (y_min + y_max) / 2 / H
                bw = (x_max - x_min) / W
                bh = (y_max - y_min) / H
                txt_lines.append(f"{cls} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}")

                # FT格式
                xy = [v for p in pts for v in p]
                if hull:
                    xy = np.array(xy, dtype=np.float32).reshape(-1, 2)        # [n, 2]               
                    xy = cv2.convexHull(xy).reshape(-1, 2).flatten().tolist()
                ft_lst = compute_coefficients_interp(xy, terms=ft_terms, return_list=True)
                ft = np.array(ft_lst, dtype=np.float32)
                ft_scale(ft, (1.0 / W, 1.0 / H))
                ft_line = f"{cls} " + " ".join([f"{x:.6f}" for x in ft])
                ft_lines.append(ft_line)

                # POL格式
                # 归一化 pts 中每个点
                pts_norm = [[x / W, y / H] for x, y in pts]
                pol_line = " ".join([f"{v:.6f}" for p in pts_norm for v in p])
                pol_lines.append(f"{cls} {pol_line}")

                # 可视化绘图
                if img is not None:
                    assert img.shape[0]==H and img.shape[1]==W
                    ft_pixel = ft.copy()
                    ft_scale(ft_pixel, (W, H))
                    x, y = fft_1(ft_pixel, 200)
                    contour = np.stack([x, y], axis=1).astype(np.int32)
                    cv2.polylines(img, [contour], isClosed=True, color=(0,255,0), thickness=1)

            # 写文件
            with open(f"{output_dir}/labels/{base_name}.txt", 'w') as f:
                f.write("\n".join(txt_lines))
            with open(f"{output_dir}/labels/{base_name}.ft", 'w') as f:
                f.write("\n".join(ft_lines))
            with open(f"{output_dir}/labels/{base_name}.pol", 'w') as f:
                f.write("\n".join(pol_lines))
            if img is not None:
                cv2.imwrite(f"{output_dir}/{base_name}_vis.jpg", img)

if __name__ == "__main__":
    # 示例调用（路径按需修改）
    data_path = '/home/yyy/zhou/datas/HRSID/HRSID_jpg/HRSID_JPG'
    convert_hrsid_to_yolo(data_path,"annotations/train2017.json", "JPEGImages", "train2", ft_terms=12, hull=1, vis_count=10)
    convert_hrsid_to_yolo(data_path,"annotations/test2017.json", "JPEGImages", "val2", ft_terms=12, hull=1, vis_count=10)
