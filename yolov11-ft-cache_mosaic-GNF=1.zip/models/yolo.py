# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
YOLO-specific modules

Usage:
    $ python path/to/models/yolo.py --cfg yolov5s.yaml
"""

import argparse
import sys
from copy import deepcopy
from pathlib import Path

FILE = Path(__file__).absolute()
sys.path.append(FILE.parents[1].as_posix())  # add yolov5/ to path

from models.common import *
from models.experimental import *
from utils.autoanchor import check_anchor_order
from utils.general import check_version, make_divisible, check_file, set_logging, dist2bbox
from utils.plots import feature_visualization
from utils.torch_utils import time_sync, fuse_conv_and_bn, model_info, scale_img, initialize_weights, \
    select_device, copy_attr

from .LocAtt import LocAtt,LocAttGrouped
from .DSA import *

try:
    import thop  # for FLOPs computation
except ImportError:
    thop = None

LOGGER = logging.getLogger(__name__)

OUT_LAYER = {
    'Detect': 0,
    'DetectDFL': 1,
    'DetectDFL_FT': 2,
}

class Detect(nn.Module):
    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter

    def __init__(self, nc=80, anchors=(), stride=(), ch=(), inplace=True):  # detection layer
        super().__init__()
        self.nc = nc  # number of classes
        self.no = nc + 5  # number of outputs per anchor
        self.nl = len(anchors)  # number of detection layers
        self.na = len(anchors[0]) // 2  # number of anchors
        self.grid = [torch.zeros(1)] * self.nl  # init grid
        self.anchor_grid = [torch.zeros(1)] * self.nl  # init anchor grid
        a = torch.tensor(anchors).float().view(self.nl, -1, 2)
        self.register_buffer('anchors', a)  # shape(nl,na,2)
        # self.register_buffer('anchor_grid', a.clone().view(self.nl, 1, -1, 1, 1, 2))  # shape(nl,1,na,1,1,2)
        self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in ch)  # output conv
        self.inplace = inplace  # use in-place ops (e.g. slice assignment)
        self.stride = torch.tensor(stride, requires_grad=False)  # strides computed during build

    def forward(self, x):
        z = []  # inference output
        for i in range(self.nl):#遍历本层输出的所有anchors
            x[i] = self.m[i](x[i])  # conv
            bs, _, ny, nx = x[i].shape  # x(bs,255,20,20) to x(bs,3,20,20,85)
            #x[i][b=1,na,(no==4+1+nc),ny,nx]
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()
            #x[i][b=1,na*(no==4+1+nc),ny,nx]-->x[i][b=1,na,ny,nx,no]
            if not self.training:  # inference
                if self.grid[i].shape[2:4] != x[i].shape[2:4] or self.onnx_dynamic:
                    self.grid[i], self.anchor_grid[i] = self._make_grid(nx, ny, i)
                #grid[i][b=1,1,ny,nx,2]

                y = x[i].sigmoid()
                #y[b=1,na,ny,nx,no]
                if self.inplace:
                    y[..., 0:2] = (y[..., 0:2] * 2. - 0.5 + self.grid[i]) * self.stride[i]  # xy
                    y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                else:  # for YOLOv5 on AWS Inferentia https://github.com/ultralytics/yolov5/pull/2953
                    xy = (y[..., 0:2] * 2. - 0.5 + self.grid[i]) * self.stride[i]  # xy
                    wh = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i].view(1, self.na, 1, 1, 2)  # wh
                    y = torch.cat((xy, wh, y[..., 4:]), -1)
                # y.view(bs, -1, self.no)的shape是[b=1,[na*ny*nx],(no==4+1+nc)]
                z.append(y.view(bs, -1, self.no))
                # 所有anchors全部一股脑丢给z集合

        return x if self.training else (torch.cat(z, 1), x)


    def _make_grid(self, nx=20, ny=20, i=0):
        d = self.anchors[i].device
        if check_version(torch.__version__, '1.10.0'):  # torch>=1.10.0 meshgrid workaround for torch>=0.7 compatibility
            yv, xv = torch.meshgrid([torch.arange(ny).to(d), torch.arange(nx).to(d)], indexing='ij')
        else:
            yv, xv = torch.meshgrid([torch.arange(ny).to(d), torch.arange(nx).to(d)])
        #yv[ny,nx]  xv[ny,nx]
        #torch.stack((xv, yv), 2)-->[ny,nx,2]-->[1,na,ny,nx,2]
        grid = torch.stack((xv, yv), 2).expand((1, self.na, ny, nx, 2)).float() #返回grid网格左上角编号
        anchor_grid = (self.anchors[i].clone() * self.stride[i]) \
            .view((1, self.na, 1, 1, 2)).expand((1, self.na, ny, nx, 2)).float() #返回目标anchors的像素数量
        #self.anchors[3,3,2]-->anchor_grid[1,self.na=3,ny, nx,2]
        return grid, anchor_grid


class Model(nn.Module):
    def __init__(self, cfg='yolov5s.yaml', ch=3, nc=None, anchors=None, ft_coef=1):  # model, input channels, number of classes
        super().__init__()
        if isinstance(cfg, dict):
            self.yaml = cfg  # model dict
        else:  # is *.yaml
            import yaml  # for torch hub
            self.yaml_file = Path(cfg).name
            with open(cfg) as f:
                self.yaml = yaml.safe_load(f)  # model dict

        # Define model
        ch = self.yaml['ch'] = self.yaml.get('ch', ch)  # input channels
        if nc and nc != self.yaml['nc']:
            LOGGER.info(f"Overriding model.yaml nc={self.yaml['nc']} with nc={nc}")
            self.yaml['nc'] = nc  # override yaml value
        if anchors:
            LOGGER.info(f'Overriding model.yaml anchors with anchors={anchors}')
            self.yaml['anchors'] = round(anchors)  # override yaml value
        self.model, self.save = parse_model(deepcopy(self.yaml), ch=[ch], ft_coef=ft_coef)  # model, savelist
        self.names = [str(i) for i in range(self.yaml['nc'])]  # default names
        self.inplace = self.yaml.get('inplace', True)
        # LOGGER.info([x.shape for x in self.forward(torch.zeros(1, ch, 64, 64))])

        # Build strides, anchors
        s = 256  # 2x min stride
        m = self.get_module_byname('Detect')  # Detect()水平框输出层
        
        with torch.no_grad():
            if isinstance(m, Detect):
                # stride = torch.tensor([s / x.shape[-2] for x in self.forward(torch.zeros(1, ch, s, s))])[:3]  # forward
                m.inplace = self.inplace
                self.stride = m.stride
                check_anchor_order(m)
                m.anchors /= m.stride.view(-1, 1, 1)
                self._initialize_biases()  # only run once
                # LOGGER.info('Strides: %s' % m.stride.tolist())
            
            for mname in ['DetectDFL', 'DetectDFL_FT']:
                m = self.get_module_byname(mname)  # Detect()
                if m is not None:
                    m.inplace = self.inplace
                    self.stride = m.stride
                    self._initialize_biases_dfl(m) #only run once 针对水平框的1(obj)+nc输出做了特殊的bias初始化
                    break
            
            # Init weights, biases
            initialize_weights(self)
            self.eval()
            self.info()
            self.train()
        # LOGGER.info('')

    def forward(self, x, augment=False, profile=False, visualize=False):
        if augment:
            return self.forward_augment(x)  # augmented inference, None
        return self.forward_once(x, profile, visualize)  # single-scale inference, train

    def forward_augment(self, x):
        img_size = x.shape[-2:]  # height, width
        s = [1, 0.83, 0.67]  # scales
        f = [None, 3, None]  # flips (2-ud, 3-lr)
        y = []  # outputs
        for si, fi in zip(s, f):
            xi = scale_img(x.flip(fi) if fi else x, si, gs=int(self.stride.max()))
            yi = self.forward_once(xi)[0]  # forward
            # cv2.imwrite(f'img_{si}.jpg', 255 * xi[0].cpu().numpy().transpose((1, 2, 0))[:, :, ::-1])  # save
            yi = self._descale_pred(yi, fi, si, img_size)
            y.append(yi)
        return torch.cat(y, 1), None  # augmented inference, train

    def forward_once(self, x, profile=False, visualize=False):
        y, dt = [], []  # outputs
        for m in self.model:
            if m.f != -1:  # if not from previous layer
                x = y[m.f] if isinstance(m.f, int) else [x if j == -1 else y[j] for j in m.f]  # from earlier layers

            if profile:
                c = isinstance(m, (Detect, DetectDFL, DetectDFL_9D, DetectDFL_9DDFL))  # copy input as inplace fix
                o = thop.profile(m, inputs=(x.copy() if c else x,), verbose=False)[0] / 1E9 * 2 if thop else 0  # FLOPs
                t = time_sync()
                for _ in range(10):
                    m(x.copy() if c else x)
                dt.append((time_sync() - t) * 100)
                if m == self.model[0]:
                    LOGGER.info(f"{'time (ms)':>10s} {'GFLOPs':>10s} {'params':>10s}  {'module'}")
                LOGGER.info(f'{dt[-1]:10.2f} {o:10.2f} {m.np:10.0f}  {m.type}')

            x = m(x)  # run
            y.append(x if m.i in self.save else None)  # save output

            if visualize:
                feature_visualization(x, m.type, m.i, save_dir=visualize)

        if profile:
            LOGGER.info('%.1fms total' % sum(dt))
        return x

    def _descale_pred(self, p, flips, scale, img_size):
        # de-scale predictions following augmented inference (inverse operation)
        if self.inplace:
            p[..., :4] /= scale  # de-scale
            if flips == 2:
                p[..., 1] = img_size[0] - p[..., 1]  # de-flip ud
            elif flips == 3:
                p[..., 0] = img_size[1] - p[..., 0]  # de-flip lr
        else:
            x, y, wh = p[..., 0:1] / scale, p[..., 1:2] / scale, p[..., 2:4] / scale  # de-scale
            if flips == 2:
                y = img_size[0] - y  # de-flip ud
            elif flips == 3:
                x = img_size[1] - x  # de-flip lr
            p = torch.cat((x, y, wh, p[..., 4:]), -1)
        return p

    def _initialize_biases(self, cf=None):  # initialize biases into Detect(), cf is class frequency
        # https://arxiv.org/abs/1708.02002 section 3.3
        # cf = torch.bincount(torch.tensor(np.concatenate(dataset.labels, 0)[:, 0]).long(), minlength=nc) + 1.
        m = self.model[-1]  # Detect() module
        for mi, s in zip(m.m, m.stride):  # from
            b = mi.bias.view(m.na, -1)  # conv.bias(255) to (3,85)
            b.data[:, 4] += math.log(8 / (640 / s) ** 2)  # obj (8 objects per 640 image)
            b.data[:, 5:] += math.log(0.6 / (m.nc - 0.99)) if cf is None else torch.log(cf / cf.sum())  # cls
            mi.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)

    def _initialize_biases_dfl(self, m):
        for a, b, s in zip(m.cv2, m.cv3, m.stride):
            if isinstance(a[-1], DFLExt):  # from
                dfl_bias_ = a[-1].conv_expand.bias
            else:
                dfl_bias_ = a[-1].bias
            dfl_bias_.data[:] = 1.0
            b[-1].bias.data[: m.nc] = math.log(5 / m.nc / (640 / s) ** 2)  # cls (.01 objects, 80 classes, 640 img)

    def _print_biases(self):
        m = self.model[-1]  # Detect() module
        for mi in m.m:  # from
            b = mi.bias.detach().view(m.na, -1).T  # conv.bias(255) to (3,85)
            LOGGER.info(
                ('%6g Conv2d.bias:' + '%10.3g' * 6) % (mi.weight.shape[1], *b[:5].mean(1).tolist(), b[5:].mean()))

    # def _print_weights(self):
    #     for m in self.model.modules():
    #         if type(m) is Bottleneck:
    #             LOGGER.info('%10.3g' % (m.w.detach().sigmoid() * 2))  # shortcut weights

    def fuse(self):  # fuse model Conv2d() + BatchNorm2d() layers
        LOGGER.info('Fusing layers... ')
        for m in self.model.modules():
            if isinstance(m, (Conv, DWConv)) and hasattr(m, 'bn'):
                m.conv = fuse_conv_and_bn(m.conv, m.bn)  # update conv
                delattr(m, 'bn')  # remove batchnorm
                m.forward = m.forward_fuse  # update forward
        self.info()
        return self

    def autoshape(self):  # add AutoShape module
        LOGGER.info('Adding AutoShape... ')
        m = AutoShape(self)  # wrap model
        copy_attr(m, self, include=('yaml', 'nc', 'hyp', 'names', 'stride'), exclude=())  # copy attributes
        return m

    def info(self, verbose=False, img_size=640):  # print model information
        model_info(self, verbose, img_size)
    
    def get_module_byname(self, name:str):
        if not hasattr(self, 'module_idx'):
            self.module_idx = {
            }
            for i, h in enumerate(self.yaml['head']):
                if h[2] in OUT_LAYER:
                    self.module_idx[h[2]] = i + len(self.yaml['backbone'])
        idx = self.module_idx.get(name, -1)
        return self.model[idx] if idx != -1 else None
    
    def _apply(self, fn):
        self = super()._apply(fn)        
        if getattr(self, 'mask_line', None) is not None:
            self.mask_line = fn(self.mask_line)
        m = self.get_module_byname('Detect')  # Detect()
        if isinstance(m, Detect):
            m.stride = fn(m.stride)
            m.grid = list(map(fn, m.grid))
            if isinstance(m.anchor_grid, list):
                m.anchor_grid = list(map(fn, m.anchor_grid))
        for mname in ['DetectDFL', 'DetectDFL_FT']:
            m = self.get_module_byname(mname)  # Detect()
            if m is not None:
                m.stride = fn(m.stride)
                m.anchor_points = fn(m.anchor_points)
                m.stride_tensor = fn(m.stride_tensor)
                m.keys = fn(m.keys)
                if mname in ['DetectDFL_FT']:
                    m.proj_ft = fn(m.proj_ft)
        return self


def parse_model(d, ch, ft_coef):  # model_dict, input_channels(3)
    LOGGER.info('\n%3s%18s%3s%10s  %-40s%-30s' % ('', 'from', 'n', 'params', 'module', 'arguments'))
    nc, gd, gw = d['nc'], d['depth_multiple'], d['width_multiple']
    anchors = d.get('anchors', None)
    mc = d.get('max_channels', 10240)

    if anchors is None:
        na = 1
        no = na * (nc + 4)
    else:
        na = (len(anchors[0]) // 2) if isinstance(anchors, list) else anchors  # number of anchors
        no = na * (nc + 5)  # number of outputs = anchors * (classes + 5)

    layers, save, c2 = [], [], ch[-1]  # layers, savelist, ch out
    strides = [1]
    for i, (f, n, m, args) in enumerate(d['backbone'] + d['head']):  # from, number, module, args
        now_stride = strides[-1]
        m = eval(m) if isinstance(m, str) else m  # eval strings
        for j, a in enumerate(args):
            try:
                args[j] = d.get(a, None) or eval(a)  if isinstance(a, str) else a  # eval strings
            except:
                pass

        n = n_ = max(round(n * gd), 1) if n > 1 else n  # depth gain
        if m in [Conv, GhostConv, Bottleneck, GhostBottleneck, SPP, SPPF, DWConv, MixConv2d, Focus, CrossConv,
                 BottleneckCSP, C3, C3TR, C3SPP, C3Ghost, C3k2, C2PSA, C2f, C3k,LocAtt]:#, A2C2f]:
            c1, c2 = ch[f], args[0]
            if c2 != no:  # if not output
                # c2 = make_divisible(c2 * gw, 8)
                c2 = make_divisible(min(c2, mc) * gw, 8)

            args = [c1, c2, *args[1:]]            
            if m in [Focus, Conv, GhostConv, DWConv, GhostBottleneck, MixConv2d, CrossConv]:
                now_stride = strides[f] * args[3]
            if m in [BottleneckCSP, C3, C3TR, C3Ghost, C3k2, C2PSA, C2f, C3k]:#], A2C2f]:
                args.insert(2, n)  # number of repeats
                n = 1
                # if m is C3k2: #for M/L/X sizes
                #     if gw >= 1:
                #         args[3] = True
        elif m is nn.Upsample:
            now_stride = int(strides[f] / args[1])
            c2 = ch[f]
        elif m is nn.BatchNorm2d:
            args = [ch[f]]
        elif m is Concat:
            c2 = sum([ch[x] for x in f])
        elif m in [Detect, DetectDFL, DetectDFL_FT]:
            if m in [DetectDFL_FT]:
                if len(args)==2:
                    args.append(16) #reg_max_ft
                args.append(ft_coef)
                assert len(args)==4
            args.append([ch[x] for x in f])
            if m not in [DetectDFL, DetectDFL_FT]:
                if isinstance(args[1], int):  # number of anchors
                    args[1] = [list(range(args[1] * 2))] * len(f)
            else:
                assert args[0] == nc
            args.append([strides[x] for x in f])
        elif m is Contract:
            c2 = ch[f] * args[0] ** 2
        elif m is Expand:
            c2 = ch[f] // args[0] ** 2
        elif m in [DSA]:
            args = [ch[f], *args]    
        else:
            c2 = ch[f]
        strides.append(now_stride)

        m_ = nn.Sequential(*[m(*args) for _ in range(n)]) if n > 1 else m(*args)  # module
        t = str(m)[8:-2].replace('__main__.', '')  # module type
        np = sum([x.numel() for x in m_.parameters()])  # number params
        m_.i, m_.f, m_.type, m_.np = i, f, t, np  # attach index, 'from' index, type, number params
        LOGGER.info('%3s%18s%3s%10.0f  %-40s%-30s' % (i, f, n_, np, t, args))  # print
        save.extend(x % i for x in ([f] if isinstance(f, int) else f) if x != -1)  # append to savelist
        layers.append(m_)
        if i == 0:
            ch = []
        ch.append(c2)
    return nn.Sequential(*layers), sorted(save)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg', type=str, default='yolov5s.yaml', help='model.yaml')
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--profile', action='store_true', help='profile model speed')
    opt = parser.parse_args()
    opt.cfg = check_file(opt.cfg)  # check file
    set_logging()
    device = select_device(opt.device)

    # Create model
    model = Model(opt.cfg).to(device)
    model.train()

    # Profile
    if opt.profile:
        img = torch.rand(8 if torch.cuda.is_available() else 1, 3, 640, 640).to(device)
        y = model(img, profile=True)

    # Tensorboard (not working https://github.com/ultralytics/yolov5/issues/2898)
    # from torch.utils.tensorboard import SummaryWriter
    # tb_writer = SummaryWriter('.')
    # LOGGER.info("Run 'tensorboard --logdir=models' to view tensorboard at http://localhost:6006/")
    # tb_writer.add_graph(torch.jit.trace(model, img, strict=False), [])  # add model graph



class DetectDFL(nn.Module):
    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter
    export = False

    def __init__(self, nc=80, legacy=True, ch=(), stride=(), inplace=True):  # detection layer
        super().__init__()        
        self.nc = nc  # number of classes
        self.nl = len(ch)  # number of detection layers
        self.reg_max = 16  # DFL channels (ch[0] // 16 to scale 4/8/12/16/20 for n/s/m/l/x)
        self.extra_no = 0
        self.no = nc + self.reg_max * (4 + self.extra_no)  # number of outputs per anchor
        self.stride = torch.tensor(stride, requires_grad=False)  # strides computed during build
        c2, c3 = max((16, ch[0] // 4, self.reg_max * 4)), max(ch[0], min(self.nc, 100))  # channels
        # self.cv2 = nn.ModuleList( #box branch->4(box) * self.reg_max
        #     nn.Sequential(Conv(x, c2, 3), Conv(c2, c2, 3), nn.Conv2d(c2, 4 * self.reg_max, 1)) for x in ch
        # )
        self.keys = torch.arange(0, self.reg_max, requires_grad=False).view(1, -1).repeat((4 + self.extra_no, 1)).float()
        self.anchor_points = torch.zeros(1, requires_grad=False)  # init grid
        self.stride_tensor = torch.zeros(1, requires_grad=False)  # init grid
        self.cv2 = nn.ModuleList( #box branch->4(box) * self.reg_max
            nn.Sequential(Conv(x, c2, 3), Conv(c2, c2, 3), 
                          nn.Conv2d(c2, 4 * (self.reg_max + self.extra_no), 1),
                          )for x in ch
        )

        self.legacy = legacy
        self.cv3 = ( #class branch->nc
            nn.ModuleList(nn.Sequential(Conv(x, c3, 3), Conv(c3, c3, 3), nn.Conv2d(c3, self.nc, 1)) for x in ch)
            if self.legacy
            else nn.ModuleList(
                nn.Sequential(
                    nn.Sequential(DWConv(x, x, 3), Conv(x, c3, 1)),
                    nn.Sequential(DWConv(c3, c3, 3), Conv(c3, c3, 1)),
                    nn.Conv2d(c3, self.nc, 1),
                )
                for x in ch
            )
        )
        self.init_flag = False
        self.register_buffer('proj', torch.arange(self.reg_max, dtype=torch.float))

    def dfl(self, x):
        b, c, a = x.shape  # batch, channels, anchors
        # x = x.view(b, 4, c // 4, a).transpose(2, 1).softmax(1).matmul(self.proj.type(x.dtype)).view(b, 4, a)
        if getattr(self, 'proj', None) is None:
            self.proj = torch.arange(self.reg_max, dtype=x.dtype).to(x.device)
        x = F.conv2d(x.view(b, 4, c // 4, a).transpose(2, 1).softmax(1), self.proj.view(1, -1, 1, 1)).view(b, 4, a)
        return x

    def forward(self, x):
        for i in range(self.nl):
            x[i] = torch.cat((self.cv2[i](x[i]), self.cv3[i](x[i])), 1)
        if self.training:  # Training path
            return x
        shape = x[0].shape  # BCHW
        self.anchor_points, self.stride_tensor = (x.transpose(0, 1) for x in make_anchors(x, self.stride, 0.5))
        x_cat = torch.cat([xi.view(shape[0], self.no, -1) for xi in x], 2)
        box, clses = x_cat.split((self.reg_max * 4, self.nc), 1)
        dbox = dist2bbox(self.dfl(box), self.anchor_points.unsqueeze(0), xywh=True, dim=1) * self.stride_tensor
        return (torch.cat((dbox, clses.sigmoid()), 1).transpose(2, 1), x)
    
    def update_dfl_keys_base(self, keys:list): #keys[rgmax]
        with torch.no_grad():
            self.proj = torch.tensor(keys, device=self.proj.device)


def make_anchors(feats, strides, grid_cell_offset=0.5):
    """Generate anchors from features."""
    anchor_points, stride_tensor = [], []
    assert feats is not None
    dtype, device = feats[0].dtype, feats[0].device
    for i, stride in enumerate(strides):
        _, _, h, w = feats[i].shape
        sx = torch.arange(end=w, device=device, dtype=dtype) + grid_cell_offset  # shift x
        sy = torch.arange(end=h, device=device, dtype=dtype) + grid_cell_offset  # shift y
        if check_version(torch.__version__, '1.10.0'):  # torch>=1.10.0 meshgrid workaround for torch>=0.7 compatibility
            sy, sx = torch.meshgrid(sy, sx, indexing='ij')
        else:
            sy, sx = torch.meshgrid(sy, sx)
        anchor_points.append(torch.stack((sx, sy), -1).view(-1, 2))
        stride_tensor.append(torch.full((h * w, 1), stride, dtype=dtype, device=device))
    return torch.cat(anchor_points), torch.cat(stride_tensor)

class DetectDFL_FT(DetectDFL):
    """YOLO 9D detection head for detection with 9d pose models."""

    def __init__(self, nc=80, legacy=True, reg_max_ft=16, ft_coef=1, ch=(), stride=(), inplace=True):
        """Initialize OBB with number of classes `nc` and layer channels `ch`."""
        super().__init__(nc, legacy, ch, stride)
        self.ft_coef_length = 2 + ft_coef * 4
        self.reg_max_ft = reg_max_ft
        self.ne_ft = int(self.ft_coef_length * self.reg_max_ft)
        c4 = max(ch[0] // 4, self.ne_ft)
        self.cv4 = nn.ModuleList(nn.Sequential(Conv(x, c4, 3), Conv(c4, c4, 3), nn.Conv2d(c4, self.ne_ft, 1)) for x in ch) 
        self.proj_ft = ((torch.arange(self.reg_max_ft, requires_grad=False) / (self.reg_max_ft - 1) * 2 - 1) * (self.reg_max_ft // 2))[None].repeat(self.ft_coef_length, 1)
        with torch.no_grad():
            for i in range(len(self.cv4)):
                self.cv4[i][-1].bias[:] = 1.0

    def forward(self, x):
        """Concatenates and returns predicted bounding boxes and class probabilities."""
        bs = x[0].shape[0]  # batch size
        if not hasattr(self,'ne_ft'):
            self.ne_ft = self.ne
        pft_ =torch.cat([self.cv4[i](x[i]).view(bs, self.ne_ft, -1) for i in range(self.nl)], -1)
        # pft_[b,reg_max_ft(4n+2),ntotal]
        # angle = angle.sigmoid() * math.pi / 2  # [0, pi/2]
        for i in range(self.nl):
            pbox,pcls = self.cv2[i](x[i]),self.cv3[i](x[i]) #pbox[b,reg_max*4,H,W] pcls[b,nc,H,W]
            x[i] = torch.cat((pbox, pcls), 1) #x[i][b,no=reg_max*4(box) + nc,H,W]
        if self.training:  # Training path
            return x, pft_ #pft_[b,reg_max_ft(4n+2),ntotal]
        shape = x[0].shape  # BCHW
        self.anchor_points, self.stride_tensor = (x.transpose(0, 1) for x in make_anchors(x, self.stride, 0.5))
        x_cat = torch.cat([xi.view(shape[0], self.no, -1) for xi in x], 2) #-->x_cat[b,no=reg_max*4(box) + nc, ntotal]
        box, clses = x_cat.split((self.reg_max * 4, self.nc), 1) #box[b,reg_max*4(box), ntotal] clses[b, nc, ntotal]
        dbox = dist2bbox(self.dfl(box), self.anchor_points.unsqueeze(0), xywh=True, dim=1) * self.stride_tensor #box[b,reg_max*4(box), ntotal]->dfl->dbox[b,4(box), ntotal]
        pft = self.dfl_ft(pft_) #pft_[b,reg_max_ft(4n+2),ntotal]->pft_[b,4n+2,ntotal]
        pft[:, :2, :] = (pft[:, :2, :] + self.anchor_points)# * self.stride_tensor
        pft = pft * self.stride_tensor #pft[grid coords]-->pft[pixel coords]
        return (torch.cat((dbox, clses.sigmoid()), 1).transpose(2, 1), pft.transpose(2, 1), (x, pft_)) #[b,4+nc,ntotal]->[b,ntotal,4+nc], pft[b,ntotal,4n+2]
    

    def dfl_ft(self, x):
        b, _, a = x.shape  # batch, channels, anchors
        # x = x.view(b, 4, c // 4, a).transpose(2, 1).softmax(1).matmul(self.proj.type(x.dtype)).view(b, 4, a)
        x = F.conv2d(x.view(b, -1, self.reg_max_ft, a).softmax(2).view(b, -1, 1, a), self.proj_ft.view(self.ft_coef_length, -1, 1, 1), groups=self.ft_coef_length).view(b, -1, a)
        return x

    def update_dfl_keys(self, keys:list): #keys[4n,rgmax]
        with torch.no_grad():
            length = set([len(k) for k in keys])
            assert len(keys) == self.ft_coef_length - 2, f'增加keys和数目不匹配, {len(keys)} != {self.ft_coef_length - 2}, 不需要a0, c0'
            assert len(set(length)) == 1 and length.pop() == self.reg_max_ft
            for i, k in enumerate(keys):
                self.proj_ft[i+2] = torch.tensor(k, device=self.proj_ft.device)

    def update_dfl_keys_ft_a0c0(self, keys:list): #keys[4n,rgmax]
        with torch.no_grad():
            length = set([len(k) for k in keys])
            assert len(keys) == 2, f'增加keys和数目, 只需要a0, c0'
            assert len(set(length)) == 1 and length.pop() == self.reg_max_ft
            for i, k in enumerate(keys):
                self.proj_ft[i] = torch.tensor(k, device=self.proj_ft.device)
    

